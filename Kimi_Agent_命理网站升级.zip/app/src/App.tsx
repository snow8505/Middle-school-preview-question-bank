import { useState } from 'react';
import { BookOpen, Calculator, Languages, Trophy, Star, Clock, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { MathModule } from '@/components/MathModule';
import { ChineseModule } from '@/components/ChineseModule';
import { EnglishModule } from '@/components/EnglishModule';
import './App.css';

export type Subject = 'home' | 'math' | 'chinese' | 'english';

interface SubjectCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  onClick: () => void;
  stats: {
    questions: number;
    completed: number;
    accuracy: number;
  };
}

function SubjectCard({ title, description, icon, color, onClick, stats }: SubjectCardProps) {
  return (
    <Card 
      className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-[1.02] border-2 border-transparent hover:border-opacity-50"
      style={{ '--hover-color': color } as React.CSSProperties}
      onClick={onClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div 
            className="w-14 h-14 rounded-xl flex items-center justify-center text-white"
            style={{ backgroundColor: color }}
          >
            {icon}
          </div>
          <Badge variant="secondary" className="text-sm">
            {stats.questions}题
          </Badge>
        </div>
        <CardTitle className="text-xl mt-3">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground text-sm mb-4">{description}</p>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">已完成</span>
            <span className="font-medium">{stats.completed} 题</span>
          </div>
          <Progress value={(stats.completed / stats.questions) * 100} className="h-2" />
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">正确率</span>
            <span className="font-medium text-green-600">{stats.accuracy}%</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function HomePage({ onSelectSubject }: { onSelectSubject: (subject: Subject) => void }) {
  const subjects = [
    {
      id: 'math' as Subject,
      title: '数学',
      description: '有理数运算、代数基础、几何初步、应用题',
      icon: <Calculator className="w-7 h-7" />,
      color: '#3b82f6',
      stats: { questions: 500, completed: 0, accuracy: 0 }
    },
    {
      id: 'chinese' as Subject,
      title: '语文',
      description: '古诗词、阅读理解、基础知识',
      icon: <BookOpen className="w-7 h-7" />,
      color: '#ef4444',
      stats: { questions: 100, completed: 0, accuracy: 0 }
    },
    {
      id: 'english' as Subject,
      title: '英语',
      description: '单词背诵、语法练习、阅读理解',
      icon: <Languages className="w-7 h-7" />,
      color: '#10b981',
      stats: { questions: 200, completed: 0, accuracy: 0 }
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">北京小升初学习平台</h1>
              <p className="text-xs text-gray-500">小升初分班考试备考神器</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm text-gray-600">今日学习</p>
              <p className="text-lg font-bold text-blue-600">0 题</p>
            </div>
            <Button variant="outline" size="sm">
              <Star className="w-4 h-4 mr-1" />
              我的收藏
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900 mb-3">
            欢迎来到小升初学习平台
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            专为北京小学升初中学生打造，涵盖数学、语文、英语三大科目，
            题库超过2000道精选题目，助你轻松应对分班考试！
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <Card className="text-center">
            <CardContent className="pt-6">
              <p className="text-3xl font-bold text-blue-600">800+</p>
              <p className="text-sm text-gray-500 mt-1">数学题库</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <p className="text-3xl font-bold text-red-600">100+</p>
              <p className="text-sm text-gray-500 mt-1">语文题库</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <p className="text-3xl font-bold text-green-600">200+</p>
              <p className="text-sm text-gray-500 mt-1">英语题库</p>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <p className="text-3xl font-bold text-purple-600">2000+</p>
              <p className="text-sm text-gray-500 mt-1">总题库</p>
            </CardContent>
          </Card>
        </div>

        {/* Subject Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {subjects.map((subject) => (
            <SubjectCard
              key={subject.id}
              title={subject.title}
              description={subject.description}
              icon={subject.icon}
              color={subject.color}
              stats={subject.stats}
              onClick={() => onSelectSubject(subject.id)}
            />
          ))}
        </div>

        {/* Features */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Clock className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">智能计时</h3>
              <p className="text-sm text-gray-500 mt-1">每道题限时作答，培养时间管理能力</p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Trophy className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">错题本</h3>
              <p className="text-sm text-gray-500 mt-1">自动记录错题，方便复习巩固</p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Target className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">随机抽题</h3>
              <p className="text-sm text-gray-500 mt-1">每次8道随机题目，全面覆盖知识点</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function App() {
  const [currentSubject, setCurrentSubject] = useState<Subject>('home');

  return (
    <div className="App">
      {currentSubject === 'home' && <HomePage onSelectSubject={setCurrentSubject} />}
      {currentSubject === 'math' && <MathModule onProgressUpdate={() => {}} />}
      {currentSubject === 'chinese' && <ChineseModule onProgressUpdate={() => {}} />}
      {currentSubject === 'english' && <EnglishModule onProgressUpdate={() => {}} />}
    </div>
  );
}

export default App;
