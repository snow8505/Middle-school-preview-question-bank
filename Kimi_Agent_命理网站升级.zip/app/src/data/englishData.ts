import type { Word, GrammarQuestion, EnglishReading } from '@/types';

// 初中英语单词
export const words: Word[] = [
  // 学校生活
  {
    id: 'w1',
    word: 'subject',
    phonetic: '/ˈsʌbdʒɪkt/',
    meaning: 'n. 科目；学科',
    example: 'My favorite subject is English.',
    exampleTranslation: '我最喜欢的科目是英语。',
    category: '学校生活'
  },
  {
    id: 'w2',
    word: 'homework',
    phonetic: '/ˈhəʊmwɜːk/',
    meaning: 'n. 家庭作业',
    example: 'I have a lot of homework to do today.',
    exampleTranslation: '我今天有很多家庭作业要做。',
    category: '学校生活'
  },
  {
    id: 'w3',
    word: 'examination',
    phonetic: '/ɪɡˌzæmɪˈneɪʃn/',
    meaning: 'n. 考试；检查',
    example: 'The final examination is next week.',
    exampleTranslation: '期末考试在下周。',
    category: '学校生活'
  },
  {
    id: 'w4',
    word: 'knowledge',
    phonetic: '/ˈnɒlɪdʒ/',
    meaning: 'n. 知识；学问',
    example: 'Reading can increase your knowledge.',
    exampleTranslation: '阅读可以增长你的知识。',
    category: '学校生活'
  },
  // 日常生活
  {
    id: 'w5',
    word: 'hobby',
    phonetic: '/ˈhɒbi/',
    meaning: 'n. 爱好',
    example: 'My hobby is playing basketball.',
    exampleTranslation: '我的爱好是打篮球。',
    category: '日常生活'
  },
  {
    id: 'w6',
    word: 'journey',
    phonetic: '/ˈdʒɜːni/',
    meaning: 'n. 旅行；旅程',
    example: 'Have a good journey!',
    exampleTranslation: '祝你旅途愉快！',
    category: '日常生活'
  },
  {
    id: 'w7',
    word: 'neighborhood',
    phonetic: '/ˈneɪbəhʊd/',
    meaning: 'n. 街区；附近',
    example: 'I live in a quiet neighborhood.',
    exampleTranslation: '我住在一个安静的街区。',
    category: '日常生活'
  },
  {
    id: 'w8',
    word: 'conversation',
    phonetic: '/ˌkɒnvəˈseɪʃn/',
    meaning: 'n. 对话；交谈',
    example: 'I had a long conversation with my friend.',
    exampleTranslation: '我和朋友进行了长时间的交谈。',
    category: '日常生活'
  },
  // 人物描述
  {
    id: 'w9',
    word: 'brave',
    phonetic: '/breɪv/',
    meaning: 'adj. 勇敢的',
    example: 'He is a brave firefighter.',
    exampleTranslation: '他是一位勇敢的消防员。',
    category: '人物描述'
  },
  {
    id: 'w10',
    word: 'generous',
    phonetic: '/ˈdʒenərəs/',
    meaning: 'adj. 慷慨的；大方的',
    example: 'She is very generous to her friends.',
    exampleTranslation: '她对朋友非常慷慨。',
    category: '人物描述'
  },
  {
    id: 'w11',
    word: 'confident',
    phonetic: '/ˈkɒnfɪdənt/',
    meaning: 'adj. 自信的',
    example: 'Be confident when you speak English.',
    exampleTranslation: '说英语时要自信。',
    category: '人物描述'
  },
  {
    id: 'w12',
    word: 'creative',
    phonetic: '/kriˈeɪtɪv/',
    meaning: 'adj. 有创造力的',
    example: 'Children are very creative.',
    exampleTranslation: '孩子们很有创造力。',
    category: '人物描述'
  },
  // 自然与环境
  {
    id: 'w13',
    word: 'environment',
    phonetic: '/ɪnˈvaɪrənmənt/',
    meaning: 'n. 环境',
    example: 'We should protect the environment.',
    exampleTranslation: '我们应该保护环境。',
    category: '自然与环境'
  },
  {
    id: 'w14',
    word: 'pollution',
    phonetic: '/pəˈluːʃn/',
    meaning: 'n. 污染',
    example: 'Air pollution is a serious problem.',
    exampleTranslation: '空气污染是一个严重的问题。',
    category: '自然与环境'
  },
  {
    id: 'w15',
    word: 'recycle',
    phonetic: '/ˌriːˈsaɪkl/',
    meaning: 'v. 回收利用',
    example: 'We should recycle paper and plastic.',
    exampleTranslation: '我们应该回收纸张和塑料。',
    category: '自然与环境'
  },
  {
    id: 'w16',
    word: 'wildlife',
    phonetic: '/ˈwaɪldlaɪf/',
    meaning: 'n. 野生动物',
    example: 'We must protect wildlife.',
    exampleTranslation: '我们必须保护野生动物。',
    category: '自然与环境'
  },
  // 健康
  {
    id: 'w17',
    word: 'exercise',
    phonetic: '/ˈeksəsaɪz/',
    meaning: 'n./v. 锻炼；运动',
    example: 'Regular exercise is good for health.',
    exampleTranslation: '经常锻炼对健康有益。',
    category: '健康'
  },
  {
    id: 'w18',
    word: 'balanced',
    phonetic: '/ˈbælənst/',
    meaning: 'adj. 均衡的',
    example: 'We need a balanced diet.',
    exampleTranslation: '我们需要均衡的饮食。',
    category: '健康'
  },
  {
    id: 'w19',
    word: 'energy',
    phonetic: '/ˈenədʒi/',
    meaning: 'n. 能量；精力',
    example: 'I have a lot of energy today.',
    exampleTranslation: '我今天精力充沛。',
    category: '健康'
  },
  {
    id: 'w20',
    word: 'disease',
    phonetic: '/dɪˈziːz/',
    meaning: 'n. 疾病',
    example: 'Smoking can cause many diseases.',
    exampleTranslation: '吸烟会导致许多疾病。',
    category: '健康'
  },
  // 科技
  {
    id: 'w21',
    word: 'technology',
    phonetic: '/tekˈnɒlədʒi/',
    meaning: 'n. 技术；科技',
    example: 'Modern technology changes our life.',
    exampleTranslation: '现代科技改变了我们的生活。',
    category: '科技'
  },
  {
    id: 'w22',
    word: 'invention',
    phonetic: '/ɪnˈvenʃn/',
    meaning: 'n. 发明',
    example: 'The computer is a great invention.',
    exampleTranslation: '计算机是一项伟大的发明。',
    category: '科技'
  },
  {
    id: 'w23',
    word: 'internet',
    phonetic: '/ˈɪntənet/',
    meaning: 'n. 互联网',
    example: 'We can learn a lot from the internet.',
    exampleTranslation: '我们可以从互联网上学到很多东西。',
    category: '科技'
  },
  {
    id: 'w24',
    word: 'communication',
    phonetic: '/kəˌmjuːnɪˈkeɪʃn/',
    meaning: 'n. 交流；通信',
    example: 'Mobile phones make communication easier.',
    exampleTranslation: '手机使交流更便捷。',
    category: '科技'
  },
  // 情感
  {
    id: 'w25',
    word: 'proud',
    phonetic: '/praʊd/',
    meaning: 'adj. 骄傲的；自豪的',
    example: 'I am proud of my country.',
    exampleTranslation: '我为我的国家感到骄傲。',
    category: '情感'
  },
  {
    id: 'w26',
    word: 'embarrassed',
    phonetic: '/ɪmˈbærəst/',
    meaning: 'adj. 尴尬的；窘迫的',
    example: 'I felt embarrassed when I made a mistake.',
    exampleTranslation: '我犯错时感到很尴尬。',
    category: '情感'
  },
  {
    id: 'w27',
    word: 'grateful',
    phonetic: '/ˈɡreɪtfl/',
    meaning: 'adj. 感激的',
    example: 'I am grateful for your help.',
    exampleTranslation: '我感谢你的帮助。',
    category: '情感'
  },
  {
    id: 'w28',
    word: 'disappointed',
    phonetic: '/ˌdɪsəˈpɔɪntɪd/',
    meaning: 'adj. 失望的',
    example: 'She was disappointed with the result.',
    exampleTranslation: '她对结果感到失望。',
    category: '情感'
  },
  // 社会
  {
    id: 'w29',
    word: 'volunteer',
    phonetic: '/ˌvɒlənˈtɪə(r)/',
    meaning: 'n./v. 志愿者；自愿做',
    example: 'I want to be a volunteer to help others.',
    exampleTranslation: '我想成为志愿者帮助他人。',
    category: '社会'
  },
  {
    id: 'w30',
    word: 'responsibility',
    phonetic: '/rɪˌspɒnsəˈbɪləti/',
    meaning: 'n. 责任；职责',
    example: 'Everyone has the responsibility to protect the environment.',
    exampleTranslation: '每个人都有责任保护环境。',
    category: '社会'
  },
  // 扩充词汇（31-100）
  { id: 'w31', word: 'achievement', phonetic: '/əˈtʃiːvmənt/', meaning: 'n. 成就；成绩', example: 'Winning the competition was a great achievement.', exampleTranslation: '赢得比赛是一个伟大的成就。', category: '学校生活' },
  { id: 'w32', word: 'attitude', phonetic: '/ˈætɪtjuːd/', meaning: 'n. 态度；看法', example: 'Your attitude determines your success.', exampleTranslation: '你的态度决定你的成功。', category: '学校生活' },
  { id: 'w33', word: 'challenge', phonetic: '/ˈtʃælɪndʒ/', meaning: 'n. 挑战', example: 'Learning a new language is a challenge.', exampleTranslation: '学习一门新语言是一个挑战。', category: '学校生活' },
  { id: 'w34', word: 'concentrate', phonetic: '/ˈkɒnsntreɪt/', meaning: 'v. 集中；专心', example: 'You need to concentrate on your study.', exampleTranslation: '你需要专心学习。', category: '学校生活' },
  { id: 'w35', word: 'curious', phonetic: '/ˈkjʊəriəs/', meaning: 'adj. 好奇的', example: 'Children are naturally curious.', exampleTranslation: '孩子天生好奇。', category: '学校生活' },
  { id: 'w36', word: 'determination', phonetic: '/dɪˌtɜːmɪˈneɪʃn/', meaning: 'n. 决心；决定', example: 'Success requires determination and hard work.', exampleTranslation: '成功需要决心和努力。', category: '学校生活' },
  { id: 'w37', word: 'effort', phonetic: '/ˈefət/', meaning: 'n. 努力', example: 'Your effort will be rewarded.', exampleTranslation: '你的努力会得到回报的。', category: '学校生活' },
  { id: 'w38', word: 'experience', phonetic: '/ɪkˈspɪəriəns/', meaning: 'n. 经验；经历', example: 'She has rich teaching experience.', exampleTranslation: '她有丰富的教学经验。', category: '学校生活' },
  { id: 'w39', word: 'failure', phonetic: '/ˈfeɪljə(r)/', meaning: 'n. 失败', example: 'Failure is the mother of success.', exampleTranslation: '失败是成功之母。', category: '学校生活' },
  { id: 'w40', word: 'goal', phonetic: '/ɡəʊl/', meaning: 'n. 目标', example: 'My goal is to enter a good university.', exampleTranslation: '我的目标是进入一所好大学。', category: '学校生活' },
  { id: 'w41', word: 'habit', phonetic: '/ˈhæbɪt/', meaning: 'n. 习惯', example: 'Reading is a good habit.', exampleTranslation: '阅读是一个好习惯。', category: '日常生活' },
  { id: 'w42', word: 'improve', phonetic: '/ɪmˈpruːv/', meaning: 'v. 提高；改善', example: 'You need to improve your English.', exampleTranslation: '你需要提高你的英语。', category: '日常生活' },
  { id: 'w43', word: 'jogging', phonetic: '/ˈdʒɒɡɪŋ/', meaning: 'n. 慢跑', example: 'I go jogging every morning.', exampleTranslation: '我每天早上慢跑。', category: '日常生活' },
  { id: 'w44', word: 'leisure', phonetic: '/ˈleʒə(r)/', meaning: 'n. 休闲；空闲', example: 'I like to read in my leisure time.', exampleTranslation: '我喜欢在空闲时间阅读。', category: '日常生活' },
  { id: 'w45', word: 'memory', phonetic: '/ˈmeməri/', meaning: 'n. 记忆；回忆', example: 'I have a good memory.', exampleTranslation: '我记忆力很好。', category: '日常生活' },
  { id: 'w46', word: 'necessary', phonetic: '/ˈnesəsəri/', meaning: 'adj. 必要的', example: 'Sleep is necessary for health.', exampleTranslation: '睡眠对健康是必要的。', category: '日常生活' },
  { id: 'w47', word: 'opinion', phonetic: '/əˈpɪnjən/', meaning: 'n. 意见；看法', example: 'In my opinion, you are right.', exampleTranslation: '在我看来，你是对的。', category: '日常生活' },
  { id: 'w48', word: 'preference', phonetic: '/ˈprefrəns/', meaning: 'n. 偏爱；偏好', example: 'My preference is for tea rather than coffee.', exampleTranslation: '比起咖啡，我更喜欢茶。', category: '日常生活' },
  { id: 'w49', word: 'quality', phonetic: '/ˈkwɒləti/', meaning: 'n. 质量；品质', example: 'This product is of high quality.', exampleTranslation: '这个产品质量很高。', category: '日常生活' },
  { id: 'w50', word: 'relax', phonetic: '/rɪˈlæks/', meaning: 'v. 放松', example: 'I like to relax by listening to music.', exampleTranslation: '我喜欢通过听音乐来放松。', category: '日常生活' },
  { id: 'w51', word: 'ambitious', phonetic: '/æmˈbɪʃəs/', meaning: 'adj. 有雄心的', example: 'He is an ambitious young man.', exampleTranslation: '他是一个有雄心的年轻人。', category: '人物描述' },
  { id: 'w52', word: 'cheerful', phonetic: '/ˈtʃɪəfl/', meaning: 'adj. 快乐的；开朗的', example: 'She has a cheerful personality.', exampleTranslation: '她性格开朗。', category: '人物描述' },
  { id: 'w53', word: 'diligent', phonetic: '/ˈdɪlɪdʒənt/', meaning: 'adj. 勤奋的', example: 'He is a diligent student.', exampleTranslation: '他是一个勤奋的学生。', category: '人物描述' },
  { id: 'w54', word: 'enthusiastic', phonetic: '/ɪnˌθjuːziˈæstɪk/', meaning: 'adj. 热情的', example: 'The audience was enthusiastic.', exampleTranslation: '观众很热情。', category: '人物描述' },
  { id: 'w55', word: 'friendly', phonetic: '/ˈfrendli/', meaning: 'adj. 友好的', example: 'The people here are very friendly.', exampleTranslation: '这里的人很友好。', category: '人物描述' },
  { id: 'w56', word: 'honest', phonetic: '/ˈɒnɪst/', meaning: 'adj. 诚实的', example: 'Honesty is the best policy.', exampleTranslation: '诚实是上策。', category: '人物描述' },
  { id: 'w57', word: 'intelligent', phonetic: '/ɪnˈtelɪdʒənt/', meaning: 'adj. 聪明的', example: 'She is an intelligent girl.', exampleTranslation: '她是一个聪明的女孩。', category: '人物描述' },
  { id: 'w58', word: 'kind', phonetic: '/kaɪnd/', meaning: 'adj. 善良的', example: 'She is very kind to animals.', exampleTranslation: '她对动物很善良。', category: '人物描述' },
  { id: 'w59', word: 'modest', phonetic: '/ˈmɒdɪst/', meaning: 'adj. 谦虚的', example: 'He is modest about his achievements.', exampleTranslation: '他对自己的成就很谦虚。', category: '人物描述' },
  { id: 'w60', word: 'optimistic', phonetic: '/ˌɒptɪˈmɪstɪk/', meaning: 'adj. 乐观的', example: 'She remains optimistic despite difficulties.', exampleTranslation: '尽管有困难，她仍然乐观。', category: '人物描述' },
  { id: 'w61', word: 'climate', phonetic: '/ˈklaɪmət/', meaning: 'n. 气候', example: 'The climate here is mild.', exampleTranslation: '这里的气候温和。', category: '自然与环境' },
  { id: 'w62', word: 'disaster', phonetic: '/dɪˈzɑːstə(r)/', meaning: 'n. 灾难', example: 'The earthquake was a terrible disaster.', exampleTranslation: '地震是一场可怕的灾难。', category: '自然与环境' },
  { id: 'w63', word: 'earthquake', phonetic: '/ˈɜːθkweɪk/', meaning: 'n. 地震', example: 'Japan is prone to earthquakes.', exampleTranslation: '日本容易发生地震。', category: '自然与环境' },
  { id: 'w64', word: 'flood', phonetic: '/flʌd/', meaning: 'n. 洪水', example: 'The flood destroyed many houses.', exampleTranslation: '洪水摧毁了许多房屋。', category: '自然与环境' },
  { id: 'w65', word: 'natural', phonetic: '/ˈnætʃrəl/', meaning: 'adj. 自然的', example: 'We should protect natural resources.', exampleTranslation: '我们应该保护自然资源。', category: '自然与环境' },
  { id: 'w66', word: 'resource', phonetic: '/rɪˈsɔːs/', meaning: 'n. 资源', example: 'Water is a precious resource.', exampleTranslation: '水是宝贵的资源。', category: '自然与环境' },
  { id: 'w67', word: 'sustainable', phonetic: '/səˈsteɪnəbl/', meaning: 'adj. 可持续的', example: 'We need sustainable development.', exampleTranslation: '我们需要可持续发展。', category: '自然与环境' },
  { id: 'w68', word: 'waste', phonetic: '/weɪst/', meaning: 'n. 废物；v. 浪费', example: 'We should reduce waste.', exampleTranslation: '我们应该减少浪费。', category: '自然与环境' },
  { id: 'w69', word: 'weather', phonetic: '/ˈweðə(r)/', meaning: 'n. 天气', example: 'The weather is nice today.', exampleTranslation: '今天天气很好。', category: '自然与环境' },
  { id: 'w70', word: 'active', phonetic: '/ˈæktɪv/', meaning: 'adj. 积极的；活跃的', example: 'He leads an active lifestyle.', exampleTranslation: '他过着积极的生活方式。', category: '健康' },
  { id: 'w71', word: 'appoint', phonetic: '/əˈpɔɪnt/', meaning: 'v. 任命；约定', example: 'He was appointed as manager.', exampleTranslation: '他被任命为经理。', category: '健康' },
  { id: 'w72', word: 'benefit', phonetic: '/ˈbenɪfɪt/', meaning: 'n. 好处；益处', example: 'Exercise has many benefits.', exampleTranslation: '运动有很多好处。', category: '健康' },
  { id: 'w73', word: 'condition', phonetic: '/kənˈdɪʃn/', meaning: 'n. 条件；状况', example: 'His health condition is improving.', exampleTranslation: '他的健康状况正在改善。', category: '健康' },
  { id: 'w74', word: 'fitness', phonetic: '/ˈfɪtnəs/', meaning: 'n. 健康；适合', example: 'Physical fitness is important.', exampleTranslation: '身体健康很重要。', category: '健康' },
  { id: 'w75', word: 'nutrition', phonetic: '/njuˈtrɪʃn/', meaning: 'n. 营养', example: 'Good nutrition is essential for health.', exampleTranslation: '良好的营养对健康至关重要。', category: '健康' },
  { id: 'w76', word: 'stress', phonetic: '/stres/', meaning: 'n. 压力', example: 'Stress can cause health problems.', exampleTranslation: '压力会导致健康问题。', category: '健康' },
  { id: 'w77', word: 'treatment', phonetic: '/ˈtriːtmənt/', meaning: 'n. 治疗', example: 'He is receiving medical treatment.', exampleTranslation: '他正在接受医疗治疗。', category: '健康' },
  { id: 'w78', word: 'advance', phonetic: '/ədˈvɑːns/', meaning: 'v. 进步；前进', example: 'Technology has advanced rapidly.', exampleTranslation: '技术发展迅速。', category: '科技' },
  { id: 'w79', word: 'artificial', phonetic: '/ˌɑːtɪˈfɪʃl/', meaning: 'adj. 人造的', example: 'Artificial intelligence is developing fast.', exampleTranslation: '人工智能发展迅速。', category: '科技' },
  { id: 'w80', word: 'digital', phonetic: '/ˈdɪdʒɪtl/', meaning: 'adj. 数字的', example: 'We live in a digital age.', exampleTranslation: '我们生活在数字时代。', category: '科技' },
  { id: 'w81', word: 'electronic', phonetic: '/ɪˌlekˈtrɒnɪk/', meaning: 'adj. 电子的', example: 'Electronic devices are everywhere.', exampleTranslation: '电子设备无处不在。', category: '科技' },
  { id: 'w82', word: 'information', phonetic: '/ˌɪnfəˈmeɪʃn/', meaning: 'n. 信息', example: 'The Internet provides much information.', exampleTranslation: '互联网提供了很多信息。', category: '科技' },
  { id: 'w83', word: 'program', phonetic: '/ˈprəʊɡræm/', meaning: 'n. 程序；节目', example: 'I am learning computer programming.', exampleTranslation: '我正在学习计算机编程。', category: '科技' },
  { id: 'w84', word: 'robot', phonetic: '/ˈrəʊbɒt/', meaning: 'n. 机器人', example: 'Robots can do many tasks.', exampleTranslation: '机器人可以做很多任务。', category: '科技' },
  { id: 'w85', word: 'software', phonetic: '/ˈsɒftweə(r)/', meaning: 'n. 软件', example: 'This software is very useful.', exampleTranslation: '这个软件非常有用。', category: '科技' },
  { id: 'w86', word: 'anxious', phonetic: '/ˈæŋkʃəs/', meaning: 'adj. 焦虑的', example: 'She felt anxious about the exam.', exampleTranslation: '她对考试感到焦虑。', category: '情感' },
  { id: 'w87', word: 'delighted', phonetic: '/dɪˈlaɪtɪd/', meaning: 'adj. 高兴的', example: 'I am delighted to meet you.', exampleTranslation: '很高兴见到你。', category: '情感' },
  { id: 'w88', word: 'excited', phonetic: '/ɪkˈsaɪtɪd/', meaning: 'adj. 兴奋的', example: 'The children are excited about the trip.', exampleTranslation: '孩子们对旅行感到兴奋。', category: '情感' },
  { id: 'w89', word: 'frightened', phonetic: '/ˈfraɪtnd/', meaning: 'adj. 害怕的', example: 'The dog was frightened of thunder.', exampleTranslation: '狗害怕雷声。', category: '情感' },
  { id: 'w90', word: 'jealous', phonetic: '/ˈdʒeləs/', meaning: 'adj. 嫉妒的', example: 'He was jealous of his brother.', exampleTranslation: '他嫉妒他的兄弟。', category: '情感' },
  { id: 'w91', word: 'lonely', phonetic: '/ˈləʊnli/', meaning: 'adj. 孤独的', example: 'She felt lonely in the new city.', exampleTranslation: '她在新城市感到孤独。', category: '情感' },
  { id: 'w92', word: 'nervous', phonetic: '/ˈnɜːvəs/', meaning: 'adj. 紧张的', example: 'I feel nervous before exams.', exampleTranslation: '考试前我感到紧张。', category: '情感' },
  { id: 'w93', word: 'relieved', phonetic: '/rɪˈliːvd/', meaning: 'adj. 放心的', example: 'I was relieved to hear the good news.', exampleTranslation: '听到好消息我放心了。', category: '情感' },
  { id: 'w94', word: 'worried', phonetic: '/ˈwʌrid/', meaning: 'adj. 担心的', example: 'My mother is worried about me.', exampleTranslation: '我妈妈担心我。', category: '情感' },
  { id: 'w95', word: 'charity', phonetic: '/ˈtʃærəti/', meaning: 'n. 慈善', example: 'They donate money to charity.', exampleTranslation: '他们向慈善机构捐款。', category: '社会' },
  { id: 'w96', word: 'community', phonetic: '/kəˈmjuːnəti/', meaning: 'n. 社区', example: 'I love my community.', exampleTranslation: '我爱我的社区。', category: '社会' },
  { id: 'w97', word: 'culture', phonetic: '/ˈkʌltʃə(r)/', meaning: 'n. 文化', example: 'We should respect different cultures.', exampleTranslation: '我们应该尊重不同的文化。', category: '社会' },
  { id: 'w98', word: 'equality', phonetic: '/iˈkwɒləti/', meaning: 'n. 平等', example: 'Everyone deserves equality.', exampleTranslation: '每个人都应该得到平等。', category: '社会' },
  { id: 'w99', word: 'freedom', phonetic: '/ˈfriːdəm/', meaning: 'n. 自由', example: 'Freedom is precious.', exampleTranslation: '自由是宝贵的。', category: '社会' },
  { id: 'w100', word: 'justice', phonetic: '/ˈdʒʌstɪs/', meaning: 'n. 正义；公正', example: 'We should fight for justice.', exampleTranslation: '我们应该为正义而战。', category: '社会' },
  // ========== 扩充单词至300个 ==========
  // 学校生活（101-130）
  { id: 'w101', word: 'semester', phonetic: '/sɪˈmestə(r)/', meaning: 'n. 学期', example: 'The new semester starts in September.', exampleTranslation: '新学期九月开始。', category: '学校生活' },
  { id: 'w102', word: 'curriculum', phonetic: '/kəˈrɪkjələm/', meaning: 'n. 课程', example: 'The school offers a wide curriculum.', exampleTranslation: '学校提供广泛的课程。', category: '学校生活' },
  { id: 'w103', word: 'textbook', phonetic: '/ˈtekstbʊk/', meaning: 'n. 教科书', example: 'Please bring your textbook to class.', exampleTranslation: '请带教科书来上课。', category: '学校生活' },
  { id: 'w104', word: 'notebook', phonetic: '/ˈnəʊtbʊk/', meaning: 'n. 笔记本', example: 'I write notes in my notebook.', exampleTranslation: '我在笔记本上做笔记。', category: '学校生活' },
  { id: 'w105', word: 'dictionary', phonetic: '/ˈdɪkʃənri/', meaning: 'n. 字典', example: 'Look up the word in the dictionary.', exampleTranslation: '在字典里查这个单词。', category: '学校生活' },
  { id: 'w106', word: 'eraser', phonetic: '/ɪˈreɪzə(r)/', meaning: 'n. 橡皮', example: 'I need an eraser to correct my mistake.', exampleTranslation: '我需要橡皮来改正错误。', category: '学校生活' },
  { id: 'w107', word: 'ruler', phonetic: '/ˈruːlə(r)/', meaning: 'n. 尺子', example: 'Use a ruler to draw a straight line.', exampleTranslation: '用尺子画直线。', category: '学校生活' },
  { id: 'w108', word: 'scissors', phonetic: '/ˈsɪzəz/', meaning: 'n. 剪刀', example: 'Cut the paper with scissors.', exampleTranslation: '用剪刀剪纸。', category: '学校生活' },
  { id: 'w109', word: 'glue', phonetic: '/ɡluː/', meaning: 'n. 胶水', example: 'Stick the pictures with glue.', exampleTranslation: '用胶水贴图片。', category: '学校生活' },
  { id: 'w110', word: 'calculator', phonetic: '/ˈkælkjuleɪtə(r)/', meaning: 'n. 计算器', example: 'You can use a calculator in the math exam.', exampleTranslation: '数学考试可以使用计算器。', category: '学校生活' },
  { id: 'w111', word: 'library', phonetic: '/ˈlaɪbrəri/', meaning: 'n. 图书馆', example: 'I often study in the library.', exampleTranslation: '我经常在图书馆学习。', category: '学校生活' },
  { id: 'w112', word: 'laboratory', phonetic: '/ləˈbɒrətri/', meaning: 'n. 实验室', example: 'We do experiments in the laboratory.', exampleTranslation: '我们在实验室做实验。', category: '学校生活' },
  { id: 'w113', word: 'playground', phonetic: '/ˈpleɪɡraʊnd/', meaning: 'n. 操场', example: 'Students play on the playground.', exampleTranslation: '学生们在操场上玩耍。', category: '学校生活' },
  { id: 'w114', word: 'canteen', phonetic: '/kænˈtiːn/', meaning: 'n. 食堂', example: 'We have lunch in the canteen.', exampleTranslation: '我们在食堂吃午饭。', category: '学校生活' },
  { id: 'w115', word: 'dormitory', phonetic: '/ˈdɔːmətri/', meaning: 'n. 宿舍', example: 'I live in the school dormitory.', exampleTranslation: '我住在学校宿舍。', category: '学校生活' },
  { id: 'w116', word: 'scholarship', phonetic: '/ˈskɒləʃɪp/', meaning: 'n. 奖学金', example: 'She won a scholarship to study abroad.', exampleTranslation: '她获得了出国留学的奖学金。', category: '学校生活' },
  { id: 'w117', word: 'graduation', phonetic: '/ˌɡrædʒuˈeɪʃn/', meaning: 'n. 毕业', example: 'The graduation ceremony is in June.', exampleTranslation: '毕业典礼在六月举行。', category: '学校生活' },
  { id: 'w118', word: 'degree', phonetic: '/dɪˈɡriː/', meaning: 'n. 学位；程度', example: 'He has a master\'s degree.', exampleTranslation: '他有硕士学位。', category: '学校生活' },
  { id: 'w119', word: 'lecture', phonetic: '/ˈlektʃə(r)/', meaning: 'n. 讲座；讲课', example: 'The professor gave an interesting lecture.', exampleTranslation: '教授做了一场有趣的讲座。', category: '学校生活' },
  { id: 'w120', word: 'seminar', phonetic: '/ˈsemɪnɑː(r)/', meaning: 'n. 研讨会', example: 'I attended a seminar on environmental protection.', exampleTranslation: '我参加了一个关于环境保护的研讨会。', category: '学校生活' },
  { id: 'w121', word: 'assignment', phonetic: '/əˈsaɪnmənt/', meaning: 'n. 作业；任务', example: 'The teacher gave us a writing assignment.', exampleTranslation: '老师给我们布置了写作作业。', category: '学校生活' },
  { id: 'w122', word: 'presentation', phonetic: '/ˌpreznˈteɪʃn/', meaning: 'n. 演讲；展示', example: 'I have to give a presentation tomorrow.', exampleTranslation: '我明天要做演讲。', category: '学校生活' },
  { id: 'w123', word: 'research', phonetic: '/rɪˈsɜːtʃ/', meaning: 'n./v. 研究', example: 'Scientific research takes time.', exampleTranslation: '科学研究需要时间。', category: '学校生活' },
  { id: 'w124', word: 'theory', phonetic: '/ˈθɪəri/', meaning: 'n. 理论', example: 'Einstein developed the theory of relativity.', exampleTranslation: '爱因斯坦发展了相对论。', category: '学校生活' },
  { id: 'w125', word: 'experiment', phonetic: '/ɪkˈsperɪmənt/', meaning: 'n. 实验', example: 'We did an experiment in chemistry class.', exampleTranslation: '我们在化学课上做了实验。', category: '学校生活' },
  { id: 'w126', word: 'formula', phonetic: '/ˈfɔːmjələ/', meaning: 'n. 公式', example: 'This formula is used to calculate area.', exampleTranslation: '这个公式用来计算面积。', category: '学校生活' },
  { id: 'w127', word: 'equation', phonetic: '/ɪˈkweɪʒn/', meaning: 'n. 方程式', example: 'Solve this equation for x.', exampleTranslation: '解这个方程式求x。', category: '学校生活' },
  { id: 'w128', word: 'literature', phonetic: '/ˈlɪtrətʃə(r)/', meaning: 'n. 文学', example: 'I enjoy reading classical literature.', exampleTranslation: '我喜欢阅读古典文学。', category: '学校生活' },
  { id: 'w129', word: 'poetry', phonetic: '/ˈpəʊətri/', meaning: 'n. 诗歌', example: 'She writes beautiful poetry.', exampleTranslation: '她写优美的诗歌。', category: '学校生活' },
  { id: 'w130', word: 'grammar', phonetic: '/ˈɡræmə(r)/', meaning: 'n. 语法', example: 'You need to study English grammar.', exampleTranslation: '你需要学习英语语法。', category: '学校生活' },
  // 日常生活（131-160）
  { id: 'w131', word: 'apartment', phonetic: '/əˈpɑːtmənt/', meaning: 'n. 公寓', example: 'I live in a small apartment.', exampleTranslation: '我住在一间小公寓里。', category: '日常生活' },
  { id: 'w132', word: 'furniture', phonetic: '/ˈfɜːnɪtʃə(r)/', meaning: 'n. 家具', example: 'We need to buy some furniture.', exampleTranslation: '我们需要买一些家具。', category: '日常生活' },
  { id: 'w133', word: 'refrigerator', phonetic: '/rɪˈfrɪdʒəreɪtə(r)/', meaning: 'n. 冰箱', example: 'Put the milk in the refrigerator.', exampleTranslation: '把牛奶放进冰箱。', category: '日常生活' },
  { id: 'w134', word: 'microwave', phonetic: '/ˈmaɪkrəweɪv/', meaning: 'n. 微波炉', example: 'Heat the food in the microwave.', exampleTranslation: '用微波炉加热食物。', category: '日常生活' },
  { id: 'w135', word: 'washing', phonetic: '/ˈwɒʃɪŋ/', meaning: 'n. 洗涤', example: 'I need to do the washing.', exampleTranslation: '我需要洗衣服。', category: '日常生活' },
  { id: 'w136', word: 'grocery', phonetic: '/ˈɡrəʊsəri/', meaning: 'n. 杂货；食品', example: 'I went to the grocery store.', exampleTranslation: '我去了杂货店。', category: '日常生活' },
  { id: 'w137', word: 'supermarket', phonetic: '/ˈsuːpəmɑːkɪt/', meaning: 'n. 超市', example: 'I shop at the supermarket every week.', exampleTranslation: '我每周在超市购物。', category: '日常生活' },
  { id: 'w138', word: 'restaurant', phonetic: '/ˈrestrɒnt/', meaning: 'n. 餐厅', example: 'Let\'s eat at a restaurant tonight.', exampleTranslation: '今晚我们去餐厅吃饭吧。', category: '日常生活' },
  { id: 'w139', word: 'cafeteria', phonetic: '/ˌkæfəˈtɪəriə/', meaning: 'n. 自助餐厅', example: 'The cafeteria serves good food.', exampleTranslation: '这家自助餐厅的食物很好。', category: '日常生活' },
  { id: 'w140', word: 'bakery', phonetic: '/ˈbeɪkəri/', meaning: 'n. 面包店', example: 'I bought bread at the bakery.', exampleTranslation: '我在面包店买了面包。', category: '日常生活' },
  { id: 'w141', word: 'butcher', phonetic: '/ˈbʊtʃə(r)/', meaning: 'n. 屠夫；肉店', example: 'The butcher cut the meat.', exampleTranslation: '屠夫切了肉。', category: '日常生活' },
  { id: 'w142', word: 'pharmacy', phonetic: '/ˈfɑːməsi/', meaning: 'n. 药店', example: 'I went to the pharmacy to buy medicine.', exampleTranslation: '我去药店买药。', category: '日常生活' },
  { id: 'w143', word: 'bank', phonetic: '/bæŋk/', meaning: 'n. 银行', example: 'I need to go to the bank.', exampleTranslation: '我需要去银行。', category: '日常生活' },
  { id: 'w144', word: 'hospital', phonetic: '/ˈhɒspɪtl/', meaning: 'n. 医院', example: 'She works at the hospital.', exampleTranslation: '她在医院工作。', category: '日常生活' },
  { id: 'w145', word: 'police', phonetic: '/pəˈliːs/', meaning: 'n. 警察', example: 'Call the police if you need help.', exampleTranslation: '需要帮助时报警。', category: '日常生活' },
  { id: 'w146', word: 'post', phonetic: '/pəʊst/', meaning: 'n. 邮政；职位', example: 'I sent a letter by post.', exampleTranslation: '我通过邮政寄了一封信。', category: '日常生活' },
  { id: 'w147', word: 'station', phonetic: '/ˈsteɪʃn/', meaning: 'n. 车站', example: 'The train station is nearby.', exampleTranslation: '火车站在附近。', category: '日常生活' },
  { id: 'w148', word: 'airport', phonetic: '/ˈeəpɔːt/', meaning: 'n. 机场', example: 'I will meet you at the airport.', exampleTranslation: '我会在机场接你。', category: '日常生活' },
  { id: 'w149', word: 'hotel', phonetic: '/həʊˈtel/', meaning: 'n. 酒店', example: 'We stayed at a nice hotel.', exampleTranslation: '我们住在一家不错的酒店。', category: '日常生活' },
  { id: 'w150', word: 'museum', phonetic: '/mjuˈziːəm/', meaning: 'n. 博物馆', example: 'The museum has many ancient artifacts.', exampleTranslation: '博物馆有很多古代文物。', category: '日常生活' },
  // 人物描述（151-180）
  { id: 'w151', word: 'patient', phonetic: '/ˈpeɪʃnt/', meaning: 'adj. 耐心的；n. 病人', example: 'The doctor is very patient with his patients.', exampleTranslation: '医生对他的病人很有耐心。', category: '人物描述' },
  { id: 'w152', word: 'strict', phonetic: '/strɪkt/', meaning: 'adj. 严格的', example: 'My teacher is strict but fair.', exampleTranslation: '我的老师严格但公正。', category: '人物描述' },
  { id: 'w153', word: 'humorous', phonetic: '/ˈhjuːmərəs/', meaning: 'adj. 幽默的', example: 'He has a humorous personality.', exampleTranslation: '他有幽默的性格。', category: '人物描述' },
  { id: 'w154', word: 'responsible', phonetic: '/rɪˈspɒnsəbl/', meaning: 'adj. 负责任的', example: 'She is a responsible student.', exampleTranslation: '她是一个负责任的学生。', category: '人物描述' },
  { id: 'w155', word: 'reliable', phonetic: '/rɪˈlaɪəbl/', meaning: 'adj. 可靠的', example: 'He is a reliable friend.', exampleTranslation: '他是一个可靠的朋友。', category: '人物描述' },
  { id: 'w156', word: 'independent', phonetic: '/ˌɪndɪˈpendənt/', meaning: 'adj. 独立的', example: 'She is very independent.', exampleTranslation: '她很独立。', category: '人物描述' },
  { id: 'w157', word: 'mature', phonetic: '/məˈtʃʊə(r)/', meaning: 'adj. 成熟的', example: 'He is very mature for his age.', exampleTranslation: '就他的年龄而言，他很成熟。', category: '人物描述' },
  { id: 'w158', word: 'talented', phonetic: '/ˈtæləntɪd/', meaning: 'adj. 有天赋的', example: 'She is a talented musician.', exampleTranslation: '她是一位有天赋的音乐家。', category: '人物描述' },
  { id: 'w159', word: 'hardworking', phonetic: '/ˈhɑːdwɜːkɪŋ/', meaning: 'adj. 勤奋的', example: 'He is a hardworking employee.', exampleTranslation: '他是一位勤奋的员工。', category: '人物描述' },
  { id: 'w160', word: 'polite', phonetic: '/pəˈlaɪt/', meaning: 'adj. 有礼貌的', example: 'It is polite to say thank you.', exampleTranslation: '说谢谢是有礼貌的。', category: '人物描述' },
  { id: 'w161', word: 'rude', phonetic: '/ruːd/', meaning: 'adj. 粗鲁的', example: 'It is rude to interrupt others.', exampleTranslation: '打断别人是粗鲁的。', category: '人物描述' },
  { id: 'w162', word: 'selfish', phonetic: '/ˈselfɪʃ/', meaning: 'adj. 自私的', example: 'Don\'t be so selfish.', exampleTranslation: '不要这么自私。', category: '人物描述' },
  { id: 'w163', word: 'stubborn', phonetic: '/ˈstʌbən/', meaning: 'adj. 固执的', example: 'He is too stubborn to admit his mistake.', exampleTranslation: '他太固执了，不肯承认错误。', category: '人物描述' },
  { id: 'w164', word: 'shy', phonetic: '/ʃaɪ/', meaning: 'adj. 害羞的', example: 'She is shy around strangers.', exampleTranslation: '她在陌生人面前很害羞。', category: '人物描述' },
  { id: 'w165', word: 'outgoing', phonetic: '/ˈaʊtɡəʊɪŋ/', meaning: 'adj. 外向的', example: 'He is very outgoing and makes friends easily.', exampleTranslation: '他很外向，很容易交到朋友。', category: '人物描述' },
  { id: 'w166', word: 'calm', phonetic: '/kɑːm/', meaning: 'adj. 平静的', example: 'Stay calm in an emergency.', exampleTranslation: '紧急情况下保持冷静。', category: '人物描述' },
  { id: 'w167', word: 'curious', phonetic: '/ˈkjʊəriəs/', meaning: 'adj. 好奇的', example: 'Children are naturally curious.', exampleTranslation: '孩子天生好奇。', category: '人物描述' },
  { id: 'w168', word: 'generous', phonetic: '/ˈdʒenərəs/', meaning: 'adj. 慷慨的', example: 'She is generous with her time.', exampleTranslation: '她乐于付出时间。', category: '人物描述' },
  { id: 'w169', word: 'proud', phonetic: '/praʊd/', meaning: 'adj. 骄傲的', example: 'I am proud of my daughter.', exampleTranslation: '我为女儿感到骄傲。', category: '人物描述' },
  { id: 'w170', word: 'embarrassed', phonetic: '/ɪmˈbærəst/', meaning: 'adj. 尴尬的', example: 'I felt embarrassed when I fell.', exampleTranslation: '我摔倒时感到很尴尬。', category: '人物描述' },
  // 自然与环境（171-200）
  { id: 'w171', word: 'forest', phonetic: '/ˈfɒrɪst/', meaning: 'n. 森林', example: 'The forest is home to many animals.', exampleTranslation: '森林是许多动物的家园。', category: '自然与环境' },
  { id: 'w172', word: 'ocean', phonetic: '/ˈəʊʃn/', meaning: 'n. 海洋', example: 'The ocean covers most of the Earth.', exampleTranslation: '海洋覆盖了地球的大部分。', category: '自然与环境' },
  { id: 'w173', word: 'mountain', phonetic: '/ˈmaʊntən/', meaning: 'n. 山', example: 'We climbed the mountain yesterday.', exampleTranslation: '我们昨天爬了山。', category: '自然与环境' },
  { id: 'w174', word: 'river', phonetic: '/ˈrɪvə(r)/', meaning: 'n. 河流', example: 'The river flows through the city.', exampleTranslation: '这条河流经城市。', category: '自然与环境' },
  { id: 'w175', word: 'lake', phonetic: '/leɪk/', meaning: 'n. 湖', example: 'We went fishing at the lake.', exampleTranslation: '我们去湖边钓鱼。', category: '自然与环境' },
  { id: 'w176', word: 'desert', phonetic: '/ˈdezət/', meaning: 'n. 沙漠', example: 'The Sahara is the largest desert.', exampleTranslation: '撒哈拉是最大的沙漠。', category: '自然与环境' },
  { id: 'w177', word: 'island', phonetic: '/ˈaɪlənd/', meaning: 'n. 岛屿', example: 'Hawaii is a beautiful island.', exampleTranslation: '夏威夷是一个美丽的岛屿。', category: '自然与环境' },
  { id: 'w178', word: 'valley', phonetic: '/ˈvæli/', meaning: 'n. 山谷', example: 'The village is in a valley.', exampleTranslation: '村庄在山谷里。', category: '自然与环境' },
  { id: 'w179', word: 'volcano', phonetic: '/vɒlˈkeɪnəʊ/', meaning: 'n. 火山', example: 'The volcano erupted last year.', exampleTranslation: '这座火山去年喷发了。', category: '自然与环境' },
  { id: 'w180', word: 'glacier', phonetic: '/ˈɡlæsiə(r)/', meaning: 'n. 冰川', example: 'Glaciers are melting due to global warming.', exampleTranslation: '由于全球变暖，冰川正在融化。', category: '自然与环境' },
  // 健康（181-210）
  { id: 'w181', word: 'healthy', phonetic: '/ˈhelθi/', meaning: 'adj. 健康的', example: 'Eating vegetables keeps you healthy.', exampleTranslation: '吃蔬菜让你保持健康。', category: '健康' },
  { id: 'w182', word: 'unhealthy', phonetic: '/ʌnˈhelθi/', meaning: 'adj. 不健康的', example: 'Smoking is unhealthy.', exampleTranslation: '吸烟不健康。', category: '健康' },
  { id: 'w183', word: 'medicine', phonetic: '/ˈmedsn/', meaning: 'n. 药', example: 'Take this medicine three times a day.', exampleTranslation: '这药一天吃三次。', category: '健康' },
  { id: 'w184', word: 'doctor', phonetic: '/ˈdɒktə(r)/', meaning: 'n. 医生', example: 'You should see a doctor.', exampleTranslation: '你应该看医生。', category: '健康' },
  { id: 'w185', word: 'nurse', phonetic: '/nɜːs/', meaning: 'n. 护士', example: 'The nurse took my temperature.', exampleTranslation: '护士给我量了体温。', category: '健康' },
  { id: 'w186', word: 'patient', phonetic: '/ˈpeɪʃnt/', meaning: 'n. 病人', example: 'The patient is recovering well.', exampleTranslation: '病人恢复得很好。', category: '健康' },
  { id: 'w187', word: 'clinic', phonetic: '/ˈklɪnɪk/', meaning: 'n. 诊所', example: 'I went to the clinic for a check-up.', exampleTranslation: '我去诊所做检查。', category: '健康' },
  { id: 'w188', word: 'symptom', phonetic: '/ˈsɪmptəm/', meaning: 'n. 症状', example: 'What are your symptoms?', exampleTranslation: '你有什么症状？', category: '健康' },
  { id: 'w189', word: 'diagnosis', phonetic: '/ˌdaɪəɡˈnəʊsɪs/', meaning: 'n. 诊断', example: 'The doctor made a diagnosis.', exampleTranslation: '医生做出了诊断。', category: '健康' },
  { id: 'w190', word: 'prescription', phonetic: '/prɪˈskrɪpʃn/', meaning: 'n. 处方', example: 'The doctor gave me a prescription.', exampleTranslation: '医生给我开了处方。', category: '健康' },
  // 科技（211-240）
  { id: 'w191', word: 'computer', phonetic: '/kəmˈpjuːtə(r)/', meaning: 'n. 电脑', example: 'I use a computer for work.', exampleTranslation: '我用电脑工作。', category: '科技' },
  { id: 'w192', word: 'internet', phonetic: '/ˈɪntənet/', meaning: 'n. 互联网', example: 'The internet connects the world.', exampleTranslation: '互联网连接世界。', category: '科技' },
  { id: 'w193', word: 'website', phonetic: '/ˈwebsaɪt/', meaning: 'n. 网站', example: 'I visited their website.', exampleTranslation: '我访问了他们的网站。', category: '科技' },
  { id: 'w194', word: 'application', phonetic: '/ˌæplɪˈkeɪʃn/', meaning: 'n. 应用程序', example: 'I downloaded a new app.', exampleTranslation: '我下载了一个新应用。', category: '科技' },
  { id: 'w195', word: 'smartphone', phonetic: '/ˈsmɑːtfəʊn/', meaning: 'n. 智能手机', example: 'Almost everyone has a smartphone.', exampleTranslation: '几乎人人都有智能手机。', category: '科技' },
  { id: 'w196', word: 'tablet', phonetic: '/ˈtæblət/', meaning: 'n. 平板电脑', example: 'I read books on my tablet.', exampleTranslation: '我在平板电脑上读书。', category: '科技' },
  { id: 'w197', word: 'laptop', phonetic: '/ˈlæptɒp/', meaning: 'n. 笔记本电脑', example: 'I bought a new laptop.', exampleTranslation: '我买了一台新笔记本电脑。', category: '科技' },
  { id: 'w198', word: 'keyboard', phonetic: '/ˈkiːbɔːd/', meaning: 'n. 键盘', example: 'Type on the keyboard.', exampleTranslation: '在键盘上打字。', category: '科技' },
  { id: 'w199', word: 'mouse', phonetic: '/maʊs/', meaning: 'n. 鼠标', example: 'Click with the mouse.', exampleTranslation: '用鼠标点击。', category: '科技' },
  { id: 'w200', word: 'screen', phonetic: '/skriːn/', meaning: 'n. 屏幕', example: 'The screen is very clear.', exampleTranslation: '屏幕很清晰。', category: '科技' },
  // 情感（241-270）
  { id: 'w201', word: 'love', phonetic: '/lʌv/', meaning: 'n./v. 爱', example: 'I love my family.', exampleTranslation: '我爱我的家人。', category: '情感' },
  { id: 'w202', word: 'hate', phonetic: '/heɪt/', meaning: 'v. 恨', example: 'I hate violence.', exampleTranslation: '我恨暴力。', category: '情感' },
  { id: 'w203', word: 'like', phonetic: '/laɪk/', meaning: 'v. 喜欢', example: 'I like reading.', exampleTranslation: '我喜欢阅读。', category: '情感' },
  { id: 'w204', word: 'dislike', phonetic: '/dɪsˈlaɪk/', meaning: 'v. 不喜欢', example: 'I dislike waiting.', exampleTranslation: '我不喜欢等待。', category: '情感' },
  { id: 'w205', word: 'enjoy', phonetic: '/ɪnˈdʒɔɪ/', meaning: 'v. 享受', example: 'I enjoy playing tennis.', exampleTranslation: '我喜欢打网球。', category: '情感' },
  { id: 'w206', word: 'prefer', phonetic: '/prɪˈfɜː(r)/', meaning: 'v. 更喜欢', example: 'I prefer tea to coffee.', exampleTranslation: '比起咖啡我更喜欢茶。', category: '情感' },
  { id: 'w207', word: 'hope', phonetic: '/həʊp/', meaning: 'n./v. 希望', example: 'I hope you will succeed.', exampleTranslation: '我希望你会成功。', category: '情感' },
  { id: 'w208', word: 'wish', phonetic: '/wɪʃ/', meaning: 'n./v. 愿望', example: 'Make a wish.', exampleTranslation: '许个愿。', category: '情感' },
  { id: 'w209', word: 'dream', phonetic: '/driːm/', meaning: 'n./v. 梦想', example: 'Follow your dream.', exampleTranslation: '追随你的梦想。', category: '情感' },
  { id: 'w210', word: 'fear', phonetic: '/fɪə(r)/', meaning: 'n./v. 害怕', example: 'Don\'t let fear stop you.', exampleTranslation: '不要让恐惧阻止你。', category: '情感' },
  // 社会（271-300）
  { id: 'w211', word: 'government', phonetic: '/ˈɡʌvənmənt/', meaning: 'n. 政府', example: 'The government made a new policy.', exampleTranslation: '政府制定了新政策。', category: '社会' },
  { id: 'w212', word: 'president', phonetic: '/ˈprezɪdənt/', meaning: 'n. 总统；校长', example: 'The president gave a speech.', exampleTranslation: '总统发表了演讲。', category: '社会' },
  { id: 'w213', word: 'minister', phonetic: '/ˈmɪnɪstə(r)/', meaning: 'n. 部长；大臣', example: 'The minister announced new plans.', exampleTranslation: '部长宣布了新计划。', category: '社会' },
  { id: 'w214', word: 'mayor', phonetic: '/meə(r)/', meaning: 'n. 市长', example: 'The mayor visited our school.', exampleTranslation: '市长参观了我们学校。', category: '社会' },
  { id: 'w215', word: 'citizen', phonetic: '/ˈsɪtɪzn/', meaning: 'n. 公民', example: 'Every citizen has rights and duties.', exampleTranslation: '每个公民都有权利和义务。', category: '社会' },
  { id: 'w216', word: 'society', phonetic: '/səˈsaɪəti/', meaning: 'n. 社会', example: 'We live in a diverse society.', exampleTranslation: '我们生活在一个多元化的社会。', category: '社会' },
  { id: 'w217', word: 'economy', phonetic: '/ɪˈkɒnəmi/', meaning: 'n. 经济', example: 'The economy is growing.', exampleTranslation: '经济正在增长。', category: '社会' },
  { id: 'w218', word: 'industry', phonetic: '/ˈɪndəstri/', meaning: 'n. 工业；产业', example: 'Tourism is a major industry.', exampleTranslation: '旅游业是主要产业。', category: '社会' },
  { id: 'w219', word: 'agriculture', phonetic: '/ˈæɡrɪkʌltʃə(r)/', meaning: 'n. 农业', example: 'Agriculture is important for the country.', exampleTranslation: '农业对国家很重要。', category: '社会' },
  { id: 'w220', word: 'trade', phonetic: '/treɪd/', meaning: 'n./v. 贸易', example: 'International trade is increasing.', exampleTranslation: '国际贸易正在增长。', category: '社会' },
  { id: 'w221', word: 'transportation', phonetic: '/ˌtrænspɔːˈteɪʃn/', meaning: 'n. 交通', example: 'Public transportation is convenient.', exampleTranslation: '公共交通很方便。', category: '社会' },
  { id: 'w222', word: 'communication', phonetic: '/kəˌmjuːnɪˈkeɪʃn/', meaning: 'n. 交流；通信', example: 'Communication is important in business.', exampleTranslation: '交流中商业很重要。', category: '社会' },
  { id: 'w223', word: 'education', phonetic: '/ˌedʒuˈkeɪʃn/', meaning: 'n. 教育', example: 'Education is the key to success.', exampleTranslation: '教育是成功的关键。', category: '社会' },
  { id: 'w224', word: 'healthcare', phonetic: '/ˈhelθkeə(r)/', meaning: 'n. 医疗保健', example: 'Healthcare should be accessible to all.', exampleTranslation: '医疗保健应该人人可及。', category: '社会' },
  { id: 'w225', word: 'welfare', phonetic: '/ˈwelfeə(r)/', meaning: 'n. 福利', example: 'The government provides welfare services.', exampleTranslation: '政府提供福利服务。', category: '社会' },
  { id: 'w226', word: 'security', phonetic: '/sɪˈkjʊərəti/', meaning: 'n. 安全', example: 'National security is important.', exampleTranslation: '国家安全很重要。', category: '社会' },
  { id: 'w227', word: 'peace', phonetic: '/piːs/', meaning: 'n. 和平', example: 'World peace is our goal.', exampleTranslation: '世界和平是我们的目标。', category: '社会' },
  { id: 'w228', word: 'war', phonetic: '/wɔː(r)/', meaning: 'n. 战争', example: 'War causes suffering.', exampleTranslation: '战争带来苦难。', category: '社会' },
  { id: 'w229', word: 'poverty', phonetic: '/ˈpɒvəti/', meaning: 'n. 贫困', example: 'We must fight against poverty.', exampleTranslation: '我们必须与贫困作斗争。', category: '社会' },
  { id: 'w230', word: 'crime', phonetic: '/kraɪm/', meaning: 'n. 犯罪', example: 'The crime rate has decreased.', exampleTranslation: '犯罪率下降了。', category: '社会' },
  // 动词（231-260）
  { id: 'w231', word: 'accept', phonetic: '/əkˈsept/', meaning: 'v. 接受', example: 'I accept your apology.', exampleTranslation: '我接受你的道歉。', category: '动词' },
  { id: 'w232', word: 'achieve', phonetic: '/əˈtʃiːv/', meaning: 'v. 实现；达到', example: 'She achieved her goal.', exampleTranslation: '她实现了她的目标。', category: '动词' },
  { id: 'w233', word: 'admit', phonetic: '/ədˈmɪt/', meaning: 'v. 承认', example: 'He admitted his mistake.', exampleTranslation: '他承认了他的错误。', category: '动词' },
  { id: 'w234', word: 'advise', phonetic: '/ədˈvaɪz/', meaning: 'v. 建议', example: 'I advise you to study hard.', exampleTranslation: '我建议你努力学习。', category: '动词' },
  { id: 'w235', word: 'allow', phonetic: '/əˈlaʊ/', meaning: 'v. 允许', example: 'Smoking is not allowed here.', exampleTranslation: '这里不允许吸烟。', category: '动词' },
  { id: 'w236', word: 'announce', phonetic: '/əˈnaʊns/', meaning: 'v. 宣布', example: 'They announced the winner.', exampleTranslation: '他们宣布了获胜者。', category: '动词' },
  { id: 'w237', word: 'apologize', phonetic: '/əˈpɒlədʒaɪz/', meaning: 'v. 道歉', example: 'I apologize for being late.', exampleTranslation: '我为迟到道歉。', category: '动词' },
  { id: 'w238', word: 'appreciate', phonetic: '/əˈpriːʃieɪt/', meaning: 'v. 感激；欣赏', example: 'I appreciate your help.', exampleTranslation: '我感激你的帮助。', category: '动词' },
  { id: 'w239', word: 'argue', phonetic: '/ˈɑːɡjuː/', meaning: 'v. 争论', example: 'They argued about money.', exampleTranslation: '他们为钱争论。', category: '动词' },
  { id: 'w240', word: 'arrange', phonetic: '/əˈreɪndʒ/', meaning: 'v. 安排', example: 'I will arrange a meeting.', exampleTranslation: '我会安排一个会议。', category: '动词' },
  { id: 'w241', word: 'attend', phonetic: '/əˈtend/', meaning: 'v. 参加', example: 'I attended the conference.', exampleTranslation: '我参加了会议。', category: '动词' },
  { id: 'w242', word: 'avoid', phonetic: '/əˈvɔɪd/', meaning: 'v. 避免', example: 'Avoid making the same mistake.', exampleTranslation: '避免犯同样的错误。', category: '动词' },
  { id: 'w243', word: 'believe', phonetic: '/bɪˈliːv/', meaning: 'v. 相信', example: 'I believe in you.', exampleTranslation: '我相信你。', category: '动词' },
  { id: 'w244', word: 'belong', phonetic: '/bɪˈlɒŋ/', meaning: 'v. 属于', example: 'This book belongs to me.', exampleTranslation: '这本书属于我。', category: '动词' },
  { id: 'w245', word: 'borrow', phonetic: '/ˈbɒrəʊ/', meaning: 'v. 借', example: 'Can I borrow your pen?', exampleTranslation: '我可以借你的笔吗？', category: '动词' },
  { id: 'w246', word: 'celebrate', phonetic: '/ˈselɪbreɪt/', meaning: 'v. 庆祝', example: 'We celebrated her birthday.', exampleTranslation: '我们庆祝了她的生日。', category: '动词' },
  { id: 'w247', word: 'choose', phonetic: '/tʃuːz/', meaning: 'v. 选择', example: 'Choose the best answer.', exampleTranslation: '选择最佳答案。', category: '动词' },
  { id: 'w248', word: 'compare', phonetic: '/kəmˈpeə(r)/', meaning: 'v. 比较', example: 'Compare the two pictures.', exampleTranslation: '比较这两张图片。', category: '动词' },
  { id: 'w249', word: 'complain', phonetic: '/kəmˈpleɪn/', meaning: 'v. 抱怨', example: 'She complained about the noise.', exampleTranslation: '她抱怨噪音。', category: '动词' },
  { id: 'w250', word: 'complete', phonetic: '/kəmˈpliːt/', meaning: 'v. 完成', example: 'I completed the task.', exampleTranslation: '我完成了任务。', category: '动词' },
  { id: 'w251', word: 'consider', phonetic: '/kənˈsɪdə(r)/', meaning: 'v. 考虑', example: 'Consider all the options.', exampleTranslation: '考虑所有选项。', category: '动词' },
  { id: 'w252', word: 'continue', phonetic: '/kənˈtɪnjuː/', meaning: 'v. 继续', example: 'Please continue reading.', exampleTranslation: '请继续阅读。', category: '动词' },
  { id: 'w253', word: 'create', phonetic: '/kriˈeɪt/', meaning: 'v. 创造', example: 'Create something new.', exampleTranslation: '创造一些新的东西。', category: '动词' },
  { id: 'w254', word: 'decide', phonetic: '/dɪˈsaɪd/', meaning: 'v. 决定', example: 'I decided to study abroad.', exampleTranslation: '我决定出国留学。', category: '动词' },
  { id: 'w255', word: 'describe', phonetic: '/dɪˈskraɪb/', meaning: 'v. 描述', example: 'Describe what you saw.', exampleTranslation: '描述你所看到的。', category: '动词' },
  { id: 'w256', word: 'discover', phonetic: '/dɪˈskʌvə(r)/', meaning: 'v. 发现', example: 'Columbus discovered America.', exampleTranslation: '哥伦布发现了美洲。', category: '动词' },
  { id: 'w257', word: 'discuss', phonetic: '/dɪˈskʌs/', meaning: 'v. 讨论', example: 'Let\'s discuss the problem.', exampleTranslation: '让我们讨论这个问题。', category: '动词' },
  { id: 'w258', word: 'encourage', phonetic: '/ɪnˈkʌrɪdʒ/', meaning: 'v. 鼓励', example: 'Teachers encourage students to ask questions.', exampleTranslation: '老师鼓励学生提问。', category: '动词' },
  { id: 'w259', word: 'expect', phonetic: '/ɪkˈspekt/', meaning: 'v. 期望', example: 'I expect you to be on time.', exampleTranslation: '我期望你准时。', category: '动词' },
  { id: 'w260', word: 'explain', phonetic: '/ɪkˈspleɪn/', meaning: 'v. 解释', example: 'Can you explain this word?', exampleTranslation: '你能解释这个词吗？', category: '动词' },
  // 形容词（261-290）
  { id: 'w261', word: 'ancient', phonetic: '/ˈeɪnʃənt/', meaning: 'adj. 古代的', example: 'We visited ancient ruins.', exampleTranslation: '我们参观了古代遗迹。', category: '形容词' },
  { id: 'w262', word: 'angry', phonetic: '/ˈæŋɡri/', meaning: 'adj. 生气的', example: 'Don\'t be angry with me.', exampleTranslation: '别生我的气。', category: '形容词' },
  { id: 'w263', word: 'anxious', phonetic: '/ˈæŋkʃəs/', meaning: 'adj. 焦虑的', example: 'I feel anxious about the exam.', exampleTranslation: '我对考试感到焦虑。', category: '形容词' },
  { id: 'w264', word: 'ashamed', phonetic: '/əˈʃeɪmd/', meaning: 'adj. 羞愧的', example: 'I am ashamed of my behavior.', exampleTranslation: '我为我的行为感到羞愧。', category: '形容词' },
  { id: 'w265', word: 'attractive', phonetic: '/əˈtræktɪv/', meaning: 'adj. 有吸引力的', example: 'She is very attractive.', exampleTranslation: '她很有吸引力。', category: '形容词' },
  { id: 'w266', word: 'average', phonetic: '/ˈævərɪdʒ/', meaning: 'adj. 平均的；普通的', example: 'His grades are above average.', exampleTranslation: '他的成绩高于平均水平。', category: '形容词' },
  { id: 'w267', word: 'awful', phonetic: '/ˈɔːfl/', meaning: 'adj. 糟糕的', example: 'The weather was awful.', exampleTranslation: '天气很糟糕。', category: '形容词' },
  { id: 'w268', word: 'basic', phonetic: '/ˈbeɪsɪk/', meaning: 'adj. 基本的', example: 'You need to learn the basics first.', exampleTranslation: '你需要先学习基础知识。', category: '形容词' },
  { id: 'w269', word: 'beautiful', phonetic: '/ˈbjuːtɪfl/', meaning: 'adj. 美丽的', example: 'She has a beautiful voice.', exampleTranslation: '她有美丽的嗓音。', category: '形容词' },
  { id: 'w270', word: 'boring', phonetic: '/ˈbɔːrɪŋ/', meaning: 'adj. 无聊的', example: 'The lecture was boring.', exampleTranslation: '讲座很无聊。', category: '形容词' },
  { id: 'w271', word: 'bright', phonetic: '/braɪt/', meaning: 'adj. 明亮的；聪明的', example: 'The room is bright.', exampleTranslation: '房间很明亮。', category: '形容词' },
  { id: 'w272', word: 'brilliant', phonetic: '/ˈbrɪliənt/', meaning: 'adj. 杰出的；灿烂的', example: 'He is a brilliant scientist.', exampleTranslation: '他是一位杰出的科学家。', category: '形容词' },
  { id: 'w273', word: 'careful', phonetic: '/ˈkeəfl/', meaning: 'adj. 小心的', example: 'Be careful when crossing the street.', exampleTranslation: '过马路时要小心。', category: '形容词' },
  { id: 'w274', word: 'careless', phonetic: '/ˈkeələs/', meaning: 'adj. 粗心的', example: 'He made a careless mistake.', exampleTranslation: '他犯了一个粗心的错误。', category: '形容词' },
  { id: 'w275', word: 'certain', phonetic: '/ˈsɜːtn/', meaning: 'adj. 确定的', example: 'Are you certain about that?', exampleTranslation: '你确定吗？', category: '形容词' },
  { id: 'w276', word: 'challenging', phonetic: '/ˈtʃælɪndʒɪŋ/', meaning: 'adj. 有挑战性的', example: 'This job is challenging.', exampleTranslation: '这份工作有挑战性。', category: '形容词' },
  { id: 'w277', word: 'cheap', phonetic: '/tʃiːp/', meaning: 'adj. 便宜的', example: 'This shirt is very cheap.', exampleTranslation: '这件衬衫很便宜。', category: '形容词' },
  { id: 'w278', word: 'clean', phonetic: '/kliːn/', meaning: 'adj. 干净的', example: 'The room is clean and tidy.', exampleTranslation: '房间干净整洁。', category: '形容词' },
  { id: 'w279', word: 'clear', phonetic: '/klɪə(r)/', meaning: 'adj. 清楚的', example: 'The instructions are clear.', exampleTranslation: '说明很清楚。', category: '形容词' },
  { id: 'w280', word: 'clever', phonetic: '/ˈklevə(r)/', meaning: 'adj. 聪明的', example: 'She is a clever girl.', exampleTranslation: '她是一个聪明的女孩。', category: '形容词' },
  { id: 'w281', word: 'comfortable', phonetic: '/ˈkʌmftəbl/', meaning: 'adj. 舒适的', example: 'This chair is very comfortable.', exampleTranslation: '这把椅子很舒适。', category: '形容词' },
  { id: 'w282', word: 'common', phonetic: '/ˈkɒmən/', meaning: 'adj. 常见的', example: 'This is a common mistake.', exampleTranslation: '这是一个常见的错误。', category: '形容词' },
  { id: 'w283', word: 'complete', phonetic: '/kəmˈpliːt/', meaning: 'adj. 完整的', example: 'The work is complete.', exampleTranslation: '工作完成了。', category: '形容词' },
  { id: 'w284', word: 'complicated', phonetic: '/ˈkɒmplɪkeɪtɪd/', meaning: 'adj. 复杂的', example: 'The problem is complicated.', exampleTranslation: '这个问题很复杂。', category: '形容词' },
  { id: 'w285', word: 'confident', phonetic: '/ˈkɒnfɪdənt/', meaning: 'adj. 自信的', example: 'Be confident in yourself.', exampleTranslation: '对自己要有信心。', category: '形容词' },
  { id: 'w286', word: 'confusing', phonetic: '/kənˈfjuːzɪŋ/', meaning: 'adj. 令人困惑的', example: 'The instructions are confusing.', exampleTranslation: '说明令人困惑。', category: '形容词' },
  { id: 'w287', word: 'conscious', phonetic: '/ˈkɒnʃəs/', meaning: 'adj. 有意识的', example: 'Be conscious of your surroundings.', exampleTranslation: '注意你周围的环境。', category: '形容词' },
  { id: 'w288', word: 'constant', phonetic: '/ˈkɒnstənt/', meaning: 'adj. 不断的', example: 'There is constant noise.', exampleTranslation: '有不断的噪音。', category: '形容词' },
  { id: 'w289', word: 'cool', phonetic: '/kuːl/', meaning: 'adj. 凉爽的；酷的', example: 'The weather is cool today.', exampleTranslation: '今天天气凉爽。', category: '形容词' },
  { id: 'w290', word: 'crazy', phonetic: '/ˈkreɪzi/', meaning: 'adj. 疯狂的', example: 'That idea is crazy!', exampleTranslation: '那个想法太疯狂了！', category: '形容词' }
];

// 语法题目
export const grammarQuestions: GrammarQuestion[] = [
  // 时态
  {
    id: 'g1',
    type: 'choice',
    question: 'She ______ to school every day.',
    options: ['go', 'goes', 'going', 'went'],
    answer: 1,
    explanation: '主语She是第三人称单数，一般现在时动词要加-es，所以选goes。',
    knowledge: '一般现在时'
  },
  {
    id: 'g2',
    type: 'choice',
    question: 'I ______ my homework when my mother came in.',
    options: ['do', 'did', 'was doing', 'am doing'],
    answer: 2,
    explanation: 'when引导的时间状语从句用一般过去时，主句表示过去正在进行的动作，用过去进行时was doing。',
    knowledge: '过去进行时'
  },
  {
    id: 'g3',
    type: 'choice',
    question: 'By the end of last month, we ______ ten English songs.',
    options: ['learned', 'have learned', 'had learned', 'will learn'],
    answer: 2,
    explanation: 'By the end of last month表示"到上月底为止"，是过去完成时的时间标志，表示在过去某一时间之前已经完成的动作。',
    knowledge: '过去完成时'
  },
  {
    id: 'g4',
    type: 'choice',
    question: 'If it ______ tomorrow, we will have a picnic.',
    options: ['won\'t rain', 'doesn\'t rain', 'didn\'t rain', 'hasn\'t rained'],
    answer: 1,
    explanation: 'if引导的条件状语从句，主句用一般将来时，从句用一般现在时表将来，所以选doesn\'t rain。',
    knowledge: '条件状语从句'
  },
  // 语态
  {
    id: 'g5',
    type: 'choice',
    question: 'The book ______ by many students every year.',
    options: ['reads', 'is read', 'was read', 'reading'],
    answer: 1,
    explanation: '书是"被读"的，要用被动语态；every year表示一般现在时，所以选is read。',
    knowledge: '被动语态'
  },
  {
    id: 'g6',
    type: 'choice',
    question: 'The bridge ______ before last winter.',
    options: ['has built', 'had built', 'has been built', 'had been built'],
    answer: 3,
    explanation: '桥是"被建造"的，要用被动语态；before last winter表示在过去某一时间之前完成，用过去完成时的被动语态had been built。',
    knowledge: '过去完成时的被动语态'
  },
  // 从句
  {
    id: 'g7',
    type: 'choice',
    question: 'I don\'t know ______ he will come tomorrow.',
    options: ['that', 'if', 'what', 'which'],
    answer: 1,
    explanation: '宾语从句表示"是否"的含义时，用if或whether引导。',
    knowledge: '宾语从句'
  },
  {
    id: 'g8',
    type: 'choice',
    question: 'This is the book ______ I bought yesterday.',
    options: ['who', 'whom', 'which', 'whose'],
    answer: 2,
    explanation: '定语从句修饰先行词book（物），关系代词用which或that。',
    knowledge: '定语从句'
  },
  // 非谓语动词
  {
    id: 'g9',
    type: 'choice',
    question: 'He enjoys ______ football.',
    options: ['play', 'plays', 'playing', 'to play'],
    answer: 2,
    explanation: 'enjoy后面接动名词作宾语，enjoy doing sth.表示"喜欢做某事"。',
    knowledge: '动名词'
  },
  {
    id: 'g10',
    type: 'choice',
    question: 'I want ______ a doctor when I grow up.',
    options: ['be', 'being', 'to be', 'been'],
    answer: 2,
    explanation: 'want后面接不定式作宾语，want to do sth.表示"想要做某事"。',
    knowledge: '不定式'
  },
  // 形容词和副词
  {
    id: 'g11',
    type: 'choice',
    question: 'This book is ______ than that one.',
    options: ['interesting', 'more interesting', 'most interesting', 'the most interesting'],
    answer: 1,
    explanation: 'than是比较级的标志，interesting是多音节形容词，比较级在前面加more。',
    knowledge: '形容词比较级'
  },
  {
    id: 'g12',
    type: 'choice',
    question: 'He runs ______ of all the boys.',
    options: ['fast', 'faster', 'fastest', 'the fastest'],
    answer: 3,
    explanation: 'of all the boys表示范围，要用最高级；副词最高级前面的the可以省略。',
    knowledge: '副词最高级'
  },
  // 情态动词
  {
    id: 'g13',
    type: 'choice',
    question: '______ I borrow your pen?',
    options: ['Must', 'Need', 'May', 'Should'],
    answer: 2,
    explanation: 'May I...?表示礼貌地请求许可，意为"我可以...吗？"。',
    knowledge: '情态动词may'
  },
  {
    id: 'g14',
    type: 'choice',
    question: 'You ______ play football in the street. It\'s dangerous.',
    options: ['must', 'mustn\'t', 'can', 'can\'t'],
    answer: 1,
    explanation: '根据句意"在街上踢足球很危险"，应该是禁止做某事，用mustn\'t表示"禁止，不许"。',
    knowledge: '情态动词must'
  },
  // 冠词
  {
    id: 'g15',
    type: 'choice',
    question: '______ sun rises in the east.',
    options: ['A', 'An', 'The', '/'],
    answer: 2,
    explanation: '世界上独一无二的事物（太阳、月亮、地球等）前面要用定冠词the。',
    knowledge: '定冠词'
  },
  {
    id: 'g16',
    type: 'choice',
    question: 'I have ______ uncle who lives in Beijing.',
    options: ['a', 'an', 'the', '/'],
    answer: 1,
    explanation: 'uncle以元音音素/ʌ/开头，不定冠词用an。',
    knowledge: '不定冠词'
  },
  // 介词
  {
    id: 'g17',
    type: 'choice',
    question: 'We usually have a meeting ______ Monday morning.',
    options: ['in', 'on', 'at', 'for'],
    answer: 1,
    explanation: '在具体某一天的上午、下午、晚上用介词on。',
    knowledge: '时间介词'
  },
  {
    id: 'g18',
    type: 'choice',
    question: 'The cat is hiding ______ the table.',
    options: ['in', 'on', 'under', 'at'],
    answer: 2,
    explanation: '根据句意"猫躲在桌子下面"，用under表示"在...下面"。',
    knowledge: '方位介词'
  },
  // 代词
  {
    id: 'g19',
    type: 'choice',
    question: '______ of the two answers is correct.',
    options: ['Both', 'Neither', 'All', 'None'],
    answer: 1,
    explanation: 'two answers表示两者，谓语动词is是单数，所以用Neither表示"两者都不"。',
    knowledge: '不定代词'
  },
  {
    id: 'g20',
    type: 'choice',
    question: 'The book is not mine. It belongs to ______ .',
    options: ['he', 'him', 'his', 'himself'],
    answer: 1,
    explanation: 'belong to中的to是介词，后面接人称代词宾格，所以选him。',
    knowledge: '人称代词'
  },
  // 扩充语法题目（21-50）
  { id: 'g21', type: 'choice', question: 'She ______ to the radio when I came in.', options: ['listens', 'listened', 'was listening', 'is listening'], answer: 2, explanation: 'when引导的时间状语从句用一般过去时，主句表示过去正在进行的动作，用过去进行时was listening。', knowledge: '过去进行时' },
  { id: 'g22', type: 'choice', question: 'They ______ in Beijing since 2010.', options: ['live', 'lived', 'have lived', 'are living'], answer: 2, explanation: 'since 2010表示从2010年到现在，是现在完成时的时间标志。', knowledge: '现在完成时' },
  { id: 'g23', type: 'choice', question: 'By the time we got there, the film ______ .', options: ['began', 'has begun', 'had begun', 'begins'], answer: 2, explanation: 'By the time表示"到...时候为止"，从句用一般过去时，主句用过去完成时。', knowledge: '过去完成时' },
  { id: 'g24', type: 'choice', question: 'I ______ my breakfast when the telephone rang.', options: ['have', 'had', 'was having', 'am having'], answer: 2, explanation: 'when引导的时间状语从句用一般过去时，主句表示过去正在进行的动作，用过去进行时。', knowledge: '过去进行时' },
  { id: 'g25', type: 'choice', question: 'The house ______ by the earthquake last year.', options: ['destroys', 'destroyed', 'was destroyed', 'is destroyed'], answer: 2, explanation: '房子是"被摧毁"的，要用被动语态；last year表示一般过去时，所以选was destroyed。', knowledge: '被动语态' },
  { id: 'g26', type: 'choice', question: 'The problem ______ at the meeting tomorrow.', options: ['will discuss', 'will be discussed', 'is discussing', 'discusses'], answer: 1, explanation: '问题是"被讨论"的，要用被动语态；tomorrow表示一般将来时，所以选will be discussed。', knowledge: '将来时的被动语态' },
  { id: 'g27', type: 'choice', question: 'This book is worth ______ .', options: ['read', 'reading', 'to read', 'being read'], answer: 1, explanation: 'be worth doing表示"值得做某事"，主动形式表示被动意义。', knowledge: 'worth的用法' },
  { id: 'g28', type: 'choice', question: 'I have no idea ______ he will come or not.', options: ['that', 'if', 'whether', 'what'], answer: 2, explanation: 'whether...or not表示"是否"，是固定搭配。', knowledge: '宾语从句' },
  { id: 'g29', type: 'choice', question: 'This is the factory ______ I visited last year.', options: ['where', 'which', 'in which', 'at which'], answer: 1, explanation: '定语从句修饰先行词factory（物），关系代词在从句中作宾语，用which或that。', knowledge: '定语从句' },
  { id: 'g30', type: 'choice', question: 'The reason ______ he was late is that he missed the bus.', options: ['why', 'which', 'that', 'for which'], answer: 0, explanation: '定语从句修饰先行词reason，关系副词用why，在从句中作原因状语。', knowledge: '定语从句' },
  { id: 'g31', type: 'choice', question: '______ hard you try, you can\'t finish it in one day.', options: ['Whatever', 'However', 'Whenever', 'Wherever'], answer: 1, explanation: 'however+形容词/副词表示"无论多么..."，引导让步状语从句。', knowledge: '让步状语从句' },
  { id: 'g32', type: 'choice', question: '______ you go, I will go with you.', options: ['Whatever', 'However', 'Whenever', 'Wherever'], answer: 3, explanation: 'wherever表示"无论哪里"，引导让步状语从句。', knowledge: '让步状语从句' },
  { id: 'g33', type: 'choice', question: 'He asked me ______ I could help him.', options: ['that', 'if', 'what', 'which'], answer: 1, explanation: '宾语从句表示"是否"的含义时，用if或whether引导。', knowledge: '宾语从句' },
  { id: 'g34', type: 'choice', question: '______ interesting book it is!', options: ['What', 'What an', 'How', 'How an'], answer: 1, explanation: '感叹句结构：What+a/an+形容词+可数名词单数+主语+谓语！', knowledge: '感叹句' },
  { id: 'g35', type: 'choice', question: '______ fast he runs!', options: ['What', 'What a', 'How', 'How a'], answer: 2, explanation: '感叹句结构：How+形容词/副词+主语+谓语！', knowledge: '感叹句' },
  { id: 'g36', type: 'choice', question: 'Not only he but also I ______ interested in music.', options: ['am', 'is', 'are', 'be'], answer: 0, explanation: 'not only...but also...连接两个主语时，谓语动词与靠近的主语保持一致（就近原则）。', knowledge: '主谓一致' },
  { id: 'g37', type: 'choice', question: 'Either you or he ______ wrong.', options: ['am', 'is', 'are', 'be'], answer: 1, explanation: 'either...or...连接两个主语时，谓语动词与靠近的主语保持一致（就近原则）。', knowledge: '主谓一致' },
  { id: 'g38', type: 'choice', question: 'The number of students in our class ______ 50.', options: ['am', 'is', 'are', 'be'], answer: 1, explanation: 'the number of表示"...的数量"，作主语时谓语动词用单数。', knowledge: '主谓一致' },
  { id: 'g39', type: 'choice', question: 'A number of students ______ playing basketball.', options: ['am', 'is', 'are', 'be'], answer: 2, explanation: 'a number of表示"许多"，修饰可数名词复数，作主语时谓语动词用复数。', knowledge: '主谓一致' },
  { id: 'g40', type: 'choice', question: '______ you are free tomorrow, let\'s go shopping.', options: ['If', 'Unless', 'Although', 'Because'], answer: 0, explanation: 'if表示"如果"，引导条件状语从句。', knowledge: '条件状语从句' },
  { id: 'g41', type: 'choice', question: '______ it rains tomorrow, we will stay at home.', options: ['If', 'Unless', 'Although', 'Because'], answer: 0, explanation: 'if表示"如果"，引导条件状语从句。', knowledge: '条件状语从句' },
  { id: 'g42', type: 'choice', question: '______ he is young, he knows a lot.', options: ['If', 'Unless', 'Although', 'Because'], answer: 2, explanation: 'although表示"虽然"，引导让步状语从句。', knowledge: '让步状语从句' },
  { id: 'g43', type: 'choice', question: 'He didn\'t go to school ______ he was ill.', options: ['if', 'unless', 'although', 'because'], answer: 3, explanation: 'because表示"因为"，引导原因状语从句。', knowledge: '原因状语从句' },
  { id: 'g44', type: 'choice', question: 'I will call you as soon as he ______ .', options: ['arrives', 'arrived', 'will arrive', 'is arriving'], answer: 0, explanation: 'as soon as引导的时间状语从句，主句用一般将来时，从句用一般现在时表将来。', knowledge: '时间状语从句' },
  { id: 'g45', type: 'choice', question: 'It\'s time ______ home.', options: ['go', 'going', 'to go', 'went'], answer: 2, explanation: 'It\'s time to do sth.表示"该做某事了"。', knowledge: '固定句型' },
  { id: 'g46', type: 'choice', question: 'It takes me an hour ______ my homework every day.', options: ['do', 'doing', 'to do', 'did'], answer: 2, explanation: 'It takes sb. some time to do sth.表示"做某事花费某人多长时间"。', knowledge: '固定句型' },
  { id: 'g47', type: 'choice', question: '______ is important to learn English well.', options: ['This', 'That', 'It', 'What'], answer: 2, explanation: 'It is+形容词+to do sth.中，it作形式主语，真正的主语是后面的不定式。', knowledge: 'it的用法' },
  { id: 'g48', type: 'choice', question: 'I found ______ difficult to learn math.', options: ['this', 'that', 'it', 'what'], answer: 2, explanation: 'find it+形容词+to do sth.中，it作形式宾语，真正的宾语是后面的不定式。', knowledge: 'it的用法' },
  { id: 'g49', type: 'choice', question: 'He is ______ honest boy.', options: ['a', 'an', 'the', '/'], answer: 1, explanation: 'honest以元音音素/ɒ/开头，不定冠词用an。', knowledge: '不定冠词' },
  { id: 'g50', type: 'choice', question: '______ Great Wall is one of the wonders of the world.', options: ['A', 'An', 'The', '/'], answer: 2, explanation: '由普通名词构成的专有名词前面要用定冠词the。', knowledge: '定冠词' },
  // ========== 扩充语法题目（51-150）==========
  // 时态（51-70）
  { id: 'g51', type: 'choice', question: 'I ______ English for five years.', options: ['learn', 'learned', 'have learned', 'am learning'], answer: 2, explanation: 'for five years表示一段时间，是现在完成时的标志。', knowledge: '现在完成时' },
  { id: 'g52', type: 'choice', question: 'By next month, I ______ my homework.', options: ['finish', 'will finish', 'will have finished', 'have finished'], answer: 2, explanation: 'By next month表示到将来某个时间为止，用将来完成时。', knowledge: '将来完成时' },
  { id: 'g53', type: 'choice', question: 'Look! The children ______ in the playground.', options: ['play', 'played', 'are playing', 'were playing'], answer: 2, explanation: 'Look!表示正在发生的动作，用现在进行时。', knowledge: '现在进行时' },
  { id: 'g54', type: 'choice', question: 'When I got home, my mother ______ dinner.', options: ['cooks', 'cooked', 'was cooking', 'has cooked'], answer: 2, explanation: 'when引导的时间状语从句用一般过去时，主句表示过去正在进行的动作，用过去进行时。', knowledge: '过去进行时' },
  { id: 'g55', type: 'choice', question: 'I ______ to Beijing three times.', options: ['go', 'went', 'have been', 'had gone'], answer: 2, explanation: 'three times表示次数，用现在完成时have been to表示去过某地。', knowledge: '现在完成时' },
  { id: 'g56', type: 'choice', question: 'The train ______ at 8:00 tomorrow morning.', options: ['leaves', 'left', 'will leave', 'is leaving'], answer: 0, explanation: '表示按计划或时间表将要发生的动作，可用一般现在时表将来。', knowledge: '一般现在时表将来' },
  { id: 'g57', type: 'choice', question: 'She said she ______ to Paris the next day.', options: ['will go', 'would go', 'goes', 'went'], answer: 1, explanation: '主句用一般过去时，宾语从句要用相应的过去时态，will改为would。', knowledge: '间接引语' },
  { id: 'g58', type: 'choice', question: 'I ______ my keys. I can\'t find them anywhere.', options: ['lose', 'lost', 'have lost', 'am losing'], answer: 2, explanation: '表示过去发生的动作对现在造成的影响，用现在完成时。', knowledge: '现在完成时' },
  { id: 'g59', type: 'choice', question: 'While I ______ TV, the telephone rang.', options: ['watch', 'watched', 'was watching', 'am watching'], answer: 2, explanation: 'while引导的时间状语从句表示过去正在进行的动作，用过去进行时。', knowledge: '过去进行时' },
  { id: 'g60', type: 'choice', question: 'He ______ in this school since he came to this city.', options: ['teaches', 'taught', 'has taught', 'is teaching'], answer: 2, explanation: 'since引导的时间状语从句用一般过去时，主句用现在完成时。', knowledge: '现在完成时' },
  { id: 'g61', type: 'choice', question: 'The meeting ______ when I arrived.', options: ['begins', 'began', 'had begun', 'has begun'], answer: 2, explanation: 'arrived是过去的动作，begin发生在arrived之前，即过去的过去，用过去完成时。', knowledge: '过去完成时' },
  { id: 'g62', type: 'choice', question: 'I ______ the book yet.', options: ['don\'t read', 'didn\'t read', 'haven\'t read', 'hadn\'t read'], answer: 2, explanation: 'yet是现在完成时的标志词，用于否定句。', knowledge: '现在完成时' },
  { id: 'g63', type: 'choice', question: '______ you ever ______ to Japan?', options: ['Do; go', 'Did; go', 'Have; been', 'Had; gone'], answer: 2, explanation: 'ever是现在完成时的标志词，have been to表示去过某地。', knowledge: '现在完成时' },
  { id: 'g64', type: 'choice', question: 'How long ______ you ______ here?', options: ['do; live', 'did; live', 'have; lived', 'are; living'], answer: 2, explanation: 'how long询问一段时间，用现在完成时。', knowledge: '现在完成时' },
  { id: 'g65', type: 'choice', question: 'The sun ______ in the east and ______ in the west.', options: ['rises; sets', 'rose; set', 'is rising; setting', 'has risen; set'], answer: 0, explanation: '表示客观真理或自然规律，用一般现在时。', knowledge: '一般现在时' },
  { id: 'g66', type: 'choice', question: 'I ______ a letter when you called me.', options: ['write', 'wrote', 'was writing', 'am writing'], answer: 2, explanation: 'when引导的时间状语从句用一般过去时，主句表示过去正在进行的动作，用过去进行时。', knowledge: '过去进行时' },
  { id: 'g67', type: 'choice', question: 'They ______ each other for ten years.', options: ['know', 'knew', 'have known', 'had known'], answer: 2, explanation: 'for ten years表示一段时间，用现在完成时。', knowledge: '现在完成时' },
  { id: 'g68', type: 'choice', question: 'By the end of last year, we ______ 1000 English words.', options: ['learn', 'learned', 'have learned', 'had learned'], answer: 3, explanation: 'by the end of last year表示到过去某个时间为止，用过去完成时。', knowledge: '过去完成时' },
  { id: 'g69', type: 'choice', question: 'Listen! Someone ______ at the door.', options: ['knocks', 'knocked', 'is knocking', 'was knocking'], answer: 2, explanation: 'Listen!表示正在发生的动作，用现在进行时。', knowledge: '现在进行时' },
  { id: 'g70', type: 'choice', question: 'I ______ my homework before my mother came back.', options: ['finish', 'finished', 'have finished', 'had finished'], answer: 3, explanation: 'came back是过去的动作，finish发生在came back之前，即过去的过去，用过去完成时。', knowledge: '过去完成时' },
  // 语态（71-85）
  { id: 'g71', type: 'choice', question: 'The bridge ______ last year.', options: ['builds', 'built', 'was built', 'is built'], answer: 2, explanation: '桥是"被建造"的，要用被动语态；last year表示一般过去时。', knowledge: '被动语态' },
  { id: 'g72', type: 'choice', question: 'English ______ all over the world.', options: ['speaks', 'spoke', 'is spoken', 'was spoken'], answer: 2, explanation: '英语是"被说"的，要用被动语态；表示客观事实，用一般现在时。', knowledge: '被动语态' },
  { id: 'g73', type: 'choice', question: 'The work ______ by the end of next week.', options: ['finishes', 'will finish', 'will be finished', 'is finished'], answer: 2, explanation: '工作是"被完成"的，要用被动语态；by the end of next week表示将来，用将来时的被动语态。', knowledge: '将来时的被动语态' },
  { id: 'g74', type: 'choice', question: 'The book ______ by many people.', options: ['reads', 'read', 'is read', 'was read'], answer: 2, explanation: '书是"被读"的，要用被动语态；表示客观事实，用一般现在时。', knowledge: '被动语态' },
  { id: 'g75', type: 'choice', question: 'The letter ______ before I arrived.', options: ['sends', 'sent', 'was sent', 'had been sent'], answer: 3, explanation: '信是"被寄"的，要用被动语态；arrived是过去的动作，send发生在arrived之前，用过去完成时的被动语态。', knowledge: '过去完成时的被动语态' },
  { id: 'g76', type: 'choice', question: 'The room ______ every day.', options: ['cleans', 'cleaned', 'is cleaned', 'was cleaned'], answer: 2, explanation: '房间是"被打扫"的，要用被动语态；every day表示一般现在时。', knowledge: '被动语态' },
  { id: 'g77', type: 'choice', question: 'A new hospital ______ in our city next year.', options: ['builds', 'will build', 'will be built', 'is built'], answer: 2, explanation: '医院是"被建造"的，要用被动语态；next year表示将来，用将来时的被动语态。', knowledge: '将来时的被动语态' },
  { id: 'g78', type: 'choice', question: 'The cake ______ by my mother yesterday.', options: ['makes', 'made', 'was made', 'is made'], answer: 2, explanation: '蛋糕是"被做"的，要用被动语态；yesterday表示一般过去时。', knowledge: '被动语态' },
  { id: 'g79', type: 'choice', question: 'The problem ______ at the moment.', options: ['discusses', 'is discussed', 'is being discussed', 'was discussed'], answer: 2, explanation: '问题是"被讨论"的，要用被动语态；at the moment表示现在，用现在进行时的被动语态。', knowledge: '现在进行时的被动语态' },
  { id: 'g80', type: 'choice', question: 'The book ______ into many languages.', options: ['translates', 'translated', 'has been translated', 'had translated'], answer: 2, explanation: '书是"被翻译"的，要用被动语态；表示已经完成的动作，用现在完成时的被动语态。', knowledge: '现在完成时的被动语态' },
  { id: 'g81', type: 'choice', question: 'The window ______ by the boy just now.', options: ['breaks', 'broke', 'was broken', 'is broken'], answer: 2, explanation: '窗户是"被打破"的，要用被动语态；just now表示一般过去时。', knowledge: '被动语态' },
  { id: 'g82', type: 'choice', question: 'The song ______ by many young people.', options: ['likes', 'liked', 'is liked', 'was liked'], answer: 2, explanation: '歌曲是"被喜欢"的，要用被动语态；表示客观事实，用一般现在时。', knowledge: '被动语态' },
  { id: 'g83', type: 'choice', question: 'The meeting ______ when I got there.', options: ['holds', 'held', 'was held', 'had been held'], answer: 3, explanation: '会议是"被举行"的，要用被动语态；got是过去的动作，hold发生在got之前，用过去完成时的被动语态。', knowledge: '过去完成时的被动语态' },
  { id: 'g84', type: 'choice', question: 'The flowers ______ every morning.', options: ['waters', 'watered', 'are watered', 'were watered'], answer: 2, explanation: '花是"被浇水"的，要用被动语态；every morning表示一般现在时。', knowledge: '被动语态' },
  { id: 'g85', type: 'choice', question: 'The report ______ tomorrow afternoon.', options: ['gives', 'will give', 'will be given', 'is given'], answer: 2, explanation: '报告是"被做"的，要用被动语态；tomorrow afternoon表示将来，用将来时的被动语态。', knowledge: '将来时的被动语态' },
  // 非谓语动词（86-100）
  { id: 'g86', type: 'choice', question: 'I enjoy ______ music.', options: ['listen', 'listens', 'listening', 'to listen'], answer: 2, explanation: 'enjoy后接动名词作宾语，enjoy doing sth.表示"喜欢做某事"。', knowledge: '动名词' },
  { id: 'g87', type: 'choice', question: 'He decided ______ abroad.', options: ['go', 'goes', 'going', 'to go'], answer: 3, explanation: 'decide后接不定式作宾语，decide to do sth.表示"决定做某事"。', knowledge: '不定式' },
  { id: 'g88', type: 'choice', question: 'I look forward ______ from you.', options: ['hear', 'hears', 'hearing', 'to hearing'], answer: 3, explanation: 'look forward to中的to是介词，后接动名词，look forward to doing sth.表示"期待做某事"。', knowledge: '动名词' },
  { id: 'g89', type: 'choice', question: 'It\'s no use ______ over spilt milk.', options: ['cry', 'cries', 'crying', 'to cry'], answer: 2, explanation: 'It\'s no use doing sth.是固定句型，表示"做某事没有用"。', knowledge: '动名词' },
  { id: 'g90', type: 'choice', question: 'I want ______ a doctor when I grow up.', options: ['be', 'being', 'to be', 'been'], answer: 2, explanation: 'want后接不定式作宾语，want to do sth.表示"想要做某事"。', knowledge: '不定式' },
  { id: 'g91', type: 'choice', question: '______ hard, you will succeed.', options: ['Work', 'Working', 'To work', 'Worked'], answer: 0, explanation: '祈使句+and+陈述句，祈使句用动词原形开头。', knowledge: '祈使句' },
  { id: 'g92', type: 'choice', question: '______ the exam, he stayed up late.', options: ['Pass', 'Passing', 'To pass', 'Passed'], answer: 2, explanation: '不定式作目的状语，表示"为了通过考试"。', knowledge: '不定式' },
  { id: 'g93', type: 'choice', question: 'I heard someone ______ in the next room.', options: ['sing', 'sings', 'singing', 'to sing'], answer: 2, explanation: 'hear sb. doing sth.表示"听到某人正在做某事"。', knowledge: '现在分词' },
  { id: 'g94', type: 'choice', question: 'The book is worth ______ .', options: ['read', 'reads', 'reading', 'to read'], answer: 2, explanation: 'be worth doing表示"值得做某事"，主动形式表示被动意义。', knowledge: '动名词' },
  { id: 'g95', type: 'choice', question: 'He spent two hours ______ the problem.', options: ['solve', 'solves', 'solving', 'to solve'], answer: 2, explanation: 'spend time (in) doing sth.表示"花费时间做某事"。', knowledge: '动名词' },
  { id: 'g96', type: 'choice', question: '______ by the teacher, the students kept quiet.', options: ['Scold', 'Scolding', 'Scolded', 'To scold'], answer: 2, explanation: '过去分词作原因状语，表示"被老师批评后"。', knowledge: '过去分词' },
  { id: 'g97', type: 'choice', question: 'I can\'t help ______ when I see the funny picture.', options: ['laugh', 'laughs', 'laughing', 'to laugh'], answer: 2, explanation: 'can\'t help doing sth.表示"忍不住做某事"。', knowledge: '动名词' },
  { id: 'g98', type: 'choice', question: 'The problem is difficult ______ .', options: ['solve', 'solves', 'solving', 'to solve'], answer: 3, explanation: '主语+be+形容词+to do是固定句型，用不定式的主动形式表示被动意义。', knowledge: '不定式' },
  { id: 'g99', type: 'choice', question: '______ in the sun is bad for your eyes.', options: ['Read', 'Reading', 'To read', 'Readed'], answer: 1, explanation: '动名词作主语，表示"在阳光下看书"。', knowledge: '动名词' },
  { id: 'g100', type: 'choice', question: 'I have a lot of homework ______ .', options: ['do', 'does', 'doing', 'to do'], answer: 3, explanation: '不定式作后置定语，修饰homework，表示"要做的作业"。', knowledge: '不定式' },
  // 从句（101-120）
  { id: 'g101', type: 'choice', question: 'I don\'t know ______ he will come.', options: ['that', 'if', 'what', 'which'], answer: 1, explanation: '宾语从句表示"是否"的含义时，用if或whether引导。', knowledge: '宾语从句' },
  { id: 'g102', type: 'choice', question: '______ he said is true.', options: ['That', 'What', 'Which', 'Who'], answer: 1, explanation: 'what引导主语从句，在从句中作said的宾语。', knowledge: '主语从句' },
  { id: 'g103', type: 'choice', question: 'This is the book ______ I bought yesterday.', options: ['who', 'whom', 'which', 'whose'], answer: 2, explanation: '定语从句修饰先行词book（物），关系代词在从句中作宾语，用which或that。', knowledge: '定语从句' },
  { id: 'g104', type: 'choice', question: 'The man ______ is talking to my teacher is my father.', options: ['who', 'whom', 'which', 'whose'], answer: 0, explanation: '定语从句修饰先行词man（人），关系代词在从句中作主语，用who或that。', knowledge: '定语从句' },
  { id: 'g105', type: 'choice', question: 'I still remember the day ______ we first met.', options: ['which', 'that', 'when', 'where'], answer: 2, explanation: '定语从句修饰先行词day（时间），关系副词用when，在从句中作时间状语。', knowledge: '定语从句' },
  { id: 'g106', type: 'choice', question: 'This is the school ______ I studied three years ago.', options: ['which', 'that', 'when', 'where'], answer: 3, explanation: '定语从句修饰先行词school（地点），关系副词用where，在从句中作地点状语。', knowledge: '定语从句' },
  { id: 'g107', type: 'choice', question: '______ you study hard, you will pass the exam.', options: ['If', 'Unless', 'Although', 'Because'], answer: 0, explanation: 'if表示"如果"，引导条件状语从句。', knowledge: '条件状语从句' },
  { id: 'g108', type: 'choice', question: '______ it rains tomorrow, we will stay at home.', options: ['If', 'Unless', 'Although', 'Because'], answer: 0, explanation: 'if表示"如果"，引导条件状语从句。', knowledge: '条件状语从句' },
  { id: 'g109', type: 'choice', question: '______ he is young, he knows a lot.', options: ['If', 'Unless', 'Although', 'Because'], answer: 2, explanation: 'although表示"虽然"，引导让步状语从句。', knowledge: '让步状语从句' },
  { id: 'g110', type: 'choice', question: 'He didn\'t go to school ______ he was ill.', options: ['if', 'unless', 'although', 'because'], answer: 3, explanation: 'because表示"因为"，引导原因状语从句。', knowledge: '原因状语从句' },
  { id: 'g111', type: 'choice', question: 'I will call you as soon as he ______ .', options: ['arrives', 'arrived', 'will arrive', 'is arriving'], answer: 0, explanation: 'as soon as引导的时间状语从句，主句用一般将来时，从句用一般现在时表将来。', knowledge: '时间状语从句' },
  { id: 'g112', type: 'choice', question: '______ hard you try, you can\'t finish it in one day.', options: ['Whatever', 'However', 'Whenever', 'Wherever'], answer: 1, explanation: 'however+形容词/副词表示"无论多么..."，引导让步状语从句。', knowledge: '让步状语从句' },
  { id: 'g113', type: 'choice', question: '______ you go, I will go with you.', options: ['Whatever', 'However', 'Whenever', 'Wherever'], answer: 3, explanation: 'wherever表示"无论哪里"，引导让步状语从句。', knowledge: '让步状语从句' },
  { id: 'g114', type: 'choice', question: 'The news ______ he told me was exciting.', options: ['that', 'what', 'which', 'who'], answer: 0, explanation: '定语从句修饰先行词news（物），关系代词在从句中作宾语，用that或which。', knowledge: '定语从句' },
  { id: 'g115', type: 'choice', question: 'I don\'t know ______ to do next.', options: ['how', 'what', 'which', 'where'], answer: 1, explanation: '"what to do"表示"做什么"，what作do的宾语。', knowledge: '疑问词+不定式' },
  { id: 'g116', type: 'choice', question: 'Can you tell me ______ ?', options: ['where is the station', 'where the station is', 'the station is where', 'is where the station'], answer: 1, explanation: '宾语从句要用陈述句语序，即"连接词+主语+谓语"。', knowledge: '宾语从句' },
  { id: 'g117', type: 'choice', question: 'Do you know ______ he lives?', options: ['where', 'what', 'which', 'who'], answer: 0, explanation: 'where引导宾语从句，表示"他住在哪里"。', knowledge: '宾语从句' },
  { id: 'g118', type: 'choice', question: 'The reason ______ he was late was that he missed the bus.', options: ['why', 'which', 'that', 'for which'], answer: 0, explanation: '定语从句修饰先行词reason，关系副词用why，在从句中作原因状语。', knowledge: '定语从句' },
  { id: 'g119', type: 'choice', question: 'Is this the factory ______ you visited last year?', options: ['that', 'where', 'in which', 'at which'], answer: 0, explanation: '定语从句修饰先行词factory（物），关系代词在从句中作宾语，用that或which。', knowledge: '定语从句' },
  { id: 'g120', type: 'choice', question: 'He asked me ______ I could help him.', options: ['that', 'if', 'what', 'which'], answer: 1, explanation: '宾语从句表示"是否"的含义时，用if或whether引导。', knowledge: '宾语从句' },
  // 形容词和副词（121-135）
  { id: 'g121', type: 'choice', question: 'This book is ______ than that one.', options: ['interesting', 'more interesting', 'most interesting', 'the most interesting'], answer: 1, explanation: 'than是比较级的标志，interesting是多音节词，比较级用more interesting。', knowledge: '比较级' },
  { id: 'g122', type: 'choice', question: 'He runs ______ in our class.', options: ['fast', 'faster', 'fastest', 'the fastest'], answer: 3, explanation: 'in our class表示范围，用最高级，副词最高级前的the可以省略。', knowledge: '最高级' },
  { id: 'g123', type: 'choice', question: 'The ______ you work, the ______ progress you will make.', options: ['hard; more', 'harder; more', 'hardest; most', 'hardly; more'], answer: 1, explanation: '"the+比较级，the+比较级"表示"越...，越..."。', knowledge: '比较级' },
  { id: 'g124', type: 'choice', question: 'This is ______ film I have ever seen.', options: ['good', 'better', 'the best', 'best'], answer: 2, explanation: 'I have ever seen表示范围，用最高级，最高级前要加the。', knowledge: '最高级' },
  { id: 'g125', type: 'choice', question: 'He is ______ taller than his brother.', options: ['more', 'much', 'very', 'many'], answer: 1, explanation: 'much可以修饰比较级，表示"...得多"。', knowledge: '比较级' },
  { id: 'g126', type: 'choice', question: 'She speaks English ______ .', options: ['good', 'well', 'better', 'best'], answer: 1, explanation: 'speak是动词，要用副词well修饰。', knowledge: '形容词和副词' },
  { id: 'g127', type: 'choice', question: 'The weather is getting ______ .', options: ['bad', 'worse', 'worst', 'the worst'], answer: 1, explanation: 'get+比较级表示"变得越来越..."。', knowledge: '比较级' },
  { id: 'g128', type: 'choice', question: 'This is ______ interesting book.', options: ['a', 'an', 'the', '/'], answer: 1, explanation: 'interesting以元音音素/ɪ/开头，不定冠词用an。', knowledge: '不定冠词' },
  { id: 'g129', type: 'choice', question: 'He is ______ honest boy.', options: ['a', 'an', 'the', '/'], answer: 1, explanation: 'honest以元音音素/ɒ/开头，不定冠词用an。', knowledge: '不定冠词' },
  { id: 'g130', type: 'choice', question: '______ Great Wall is one of the wonders of the world.', options: ['A', 'An', 'The', '/'], answer: 2, explanation: '由普通名词构成的专有名词前面要用定冠词the。', knowledge: '定冠词' },
  { id: 'g131', type: 'choice', question: 'She is ______ beautiful than her sister.', options: ['more', 'much', 'very', 'many'], answer: 0, explanation: 'beautiful是多音节词，比较级用more beautiful。', knowledge: '比较级' },
  { id: 'g132', type: 'choice', question: 'This is ______ useful book.', options: ['a', 'an', 'the', '/'], answer: 0, explanation: 'useful以辅音音素/j/开头，不定冠词用a。', knowledge: '不定冠词' },
  { id: 'g133', type: 'choice', question: 'He is ______ university student.', options: ['a', 'an', 'the', '/'], answer: 0, explanation: 'university以辅音音素/j/开头，不定冠词用a。', knowledge: '不定冠词' },
  { id: 'g134', type: 'choice', question: '______ sun rises in the east.', options: ['A', 'An', 'The', '/'], answer: 2, explanation: '表示世界上独一无二的事物前要用定冠词the。', knowledge: '定冠词' },
  { id: 'g135', type: 'choice', question: 'She plays the piano ______ .', options: ['good', 'well', 'better', 'best'], answer: 1, explanation: 'play是动词，要用副词well修饰。', knowledge: '形容词和副词' },
  // 情态动词（136-145）
  { id: 'g136', type: 'choice', question: 'You ______ smoke in the classroom.', options: ['must', 'mustn\'t', 'can', 'can\'t'], answer: 1, explanation: 'mustn\'t表示"禁止"，句意为"你不准在教室吸烟"。', knowledge: '情态动词' },
  { id: 'g137', type: 'choice', question: '______ I use your pen?', options: ['Must', 'Need', 'May', 'Should'], answer: 2, explanation: 'may表示"可以"，用于请求许可，句意为"我可以用你的笔吗？"。', knowledge: '情态动词' },
  { id: 'g138', type: 'choice', question: 'You ______ finish your homework today.', options: ['must', 'mustn\'t', 'can\'t', 'needn\'t'], answer: 0, explanation: 'must表示"必须"，句意为"你今天必须完成作业"。', knowledge: '情态动词' },
  { id: 'g139', type: 'choice', question: 'He ______ be at home now.', options: ['must', 'can', 'may', 'should'], answer: 0, explanation: 'must表示肯定推测，句意为"他现在一定在家"。', knowledge: '情态动词' },
  { id: 'g140', type: 'choice', question: 'You ______ worry about it.', options: ['must', 'needn\'t', 'can\'t', 'should'], answer: 1, explanation: 'needn\'t表示"不必"，句意为"你不必担心这件事"。', knowledge: '情态动词' },
  { id: 'g141', type: 'choice', question: '______ you swim?', options: ['Must', 'Can', 'May', 'Should'], answer: 1, explanation: 'can表示"能够"，句意为"你会游泳吗？"。', knowledge: '情态动词' },
  { id: 'g142', type: 'choice', question: 'You ______ eat more vegetables.', options: ['must', 'mustn\'t', 'can\'t', 'needn\'t'], answer: 0, explanation: 'should表示"应该"，句意为"你应该多吃蔬菜"。', knowledge: '情态动词' },
  { id: 'g143', type: 'choice', question: 'It ______ rain tomorrow.', options: ['must', 'can', 'may', 'should'], answer: 2, explanation: 'may表示"可能"，句意为"明天可能会下雨"。', knowledge: '情态动词' },
  { id: 'g144', type: 'choice', question: 'You ______ be quiet in the library.', options: ['must', 'mustn\'t', 'can\'t', 'needn\'t'], answer: 0, explanation: 'must表示"必须"，句意为"你在图书馆必须保持安静"。', knowledge: '情态动词' },
  { id: 'g145', type: 'choice', question: '______ you help me with my homework?', options: ['Must', 'Can', 'May', 'Should'], answer: 1, explanation: 'can表示"能够"，用于请求帮助，句意为"你能帮我做作业吗？"。', knowledge: '情态动词' },
  // 主谓一致（146-150）
  { id: 'g146', type: 'choice', question: 'Not only Tom but also his parents ______ going to the party.', options: ['is', 'are', 'was', 'were'], answer: 1, explanation: 'not only...but also...连接两个主语时，谓语动词与靠近的主语保持一致（就近原则）。', knowledge: '主谓一致' },
  { id: 'g147', type: 'choice', question: 'Either you or I ______ wrong.', options: ['am', 'is', 'are', 'be'], answer: 0, explanation: 'either...or...连接两个主语时，谓语动词与靠近的主语保持一致（就近原则）。', knowledge: '主谓一致' },
  { id: 'g148', type: 'choice', question: 'The number of students in our class ______ 50.', options: ['am', 'is', 'are', 'be'], answer: 1, explanation: 'the number of表示"...的数量"，作主语时谓语动词用单数。', knowledge: '主谓一致' },
  { id: 'g149', type: 'choice', question: 'A number of students ______ playing basketball.', options: ['am', 'is', 'are', 'be'], answer: 2, explanation: 'a number of表示"许多"，修饰可数名词复数，作主语时谓语动词用复数。', knowledge: '主谓一致' },
  { id: 'g150', type: 'choice', question: 'Neither he nor I ______ interested in music.', options: ['am', 'is', 'are', 'be'], answer: 0, explanation: 'neither...nor...连接两个主语时，谓语动词与靠近的主语保持一致（就近原则）。', knowledge: '主谓一致' }
];

// 英语阅读理解
export const englishReadings: EnglishReading[] = [
  {
    id: 'er1',
    title: 'My School Life',
    content: `I am a middle school student. I go to school from Monday to Friday. My school day starts at 8:00 a.m. and ends at 4:30 p.m.

I have six classes every day. My favorite subject is English because I think it is interesting and useful. I also like math, although it is sometimes difficult. My math teacher, Mr. Wang, is very patient and always helps us when we have problems.

At noon, I have lunch in the school cafeteria. The food there is delicious and healthy. I usually have rice, vegetables and some meat. After lunch, I often read books in the library or chat with my friends.

I am a member of the school basketball team. We practice every Tuesday and Thursday afternoon. Playing basketball not only makes me strong but also teaches me teamwork. Last month, we won the second place in the city basketball competition.

I really enjoy my school life. It is busy but colorful.`,
    questions: [
      {
        id: 'er1q1',
        question: 'How many classes does the writer have every day?',
        options: ['Four', 'Five', 'Six', 'Seven'],
        answer: 2,
        explanation: '文中明确提到"I have six classes every day."，所以答案是Six。'
      },
      {
        id: 'er1q2',
        question: 'Why does the writer like English?',
        options: [
          'Because it is easy',
          'Because it is interesting and useful',
          'Because the teacher is nice',
          'Because he wants to go abroad'
        ],
        answer: 1,
        explanation: '文中提到"My favorite subject is English because I think it is interesting and useful."，所以选B。'
      },
      {
        id: 'er1q3',
        question: 'When does the basketball team practice?',
        options: [
          'Every Monday and Wednesday',
          'Every Tuesday and Thursday',
          'Every Friday and Saturday',
          'Every day'
        ],
        answer: 1,
        explanation: '文中提到"We practice every Tuesday and Thursday afternoon."，所以选B。'
      },
      {
        id: 'er1q4',
        question: 'What did the basketball team win last month?',
        options: [
          'The first place',
          'The second place',
          'The third place',
          'Nothing'
        ],
        answer: 1,
        explanation: '文中提到"Last month, we won the second place in the city basketball competition."，所以选B。'
      }
    ],
    vocabulary: [
      { word: 'patient', meaning: '耐心的' },
      { word: 'cafeteria', meaning: '食堂' },
      { word: 'delicious', meaning: '美味的' },
      { word: 'teamwork', meaning: '团队合作' }
    ]
  },
  {
    id: 'er2',
    title: 'Protecting the Environment',
    content: `Our environment is in trouble. Every day, we produce tons of waste and pollute the air and water. If we don't take action now, our planet will become unfit for living.

What can we do to help? First, we should reduce waste. We can use reusable bags instead of plastic bags when shopping. We should also save paper by using both sides of each sheet.

Second, we need to recycle. Paper, glass, plastic and metal can all be recycled. By recycling, we can save natural resources and reduce pollution.

Third, we should save energy. Turn off the lights when leaving a room. Unplug electronic devices when not in use. Use public transportation or ride a bike instead of driving a car.

Finally, we should plant more trees. Trees absorb carbon dioxide and produce oxygen. They also provide homes for birds and other animals.

Remember: small actions can make a big difference. Let's work together to protect our environment for future generations.`,
    questions: [
      {
        id: 'er2q1',
        question: 'What will happen if we don\'t protect the environment?',
        options: [
          'The planet will become unfit for living',
          'We will have more money',
          'Life will become easier',
          'Nothing will happen'
        ],
        answer: 0,
        explanation: '文中提到"If we don\'t take action now, our planet will become unfit for living."，所以选A。'
      },
      {
        id: 'er2q2',
        question: 'Which of the following is NOT mentioned as a way to protect the environment?',
        options: [
          'Reducing waste',
          'Recycling',
          'Saving energy',
          'Buying more things'
        ],
        answer: 3,
        explanation: '文中提到了reduce waste、recycle、save energy和plant more trees，没有提到buying more things，所以选D。'
      },
      {
        id: 'er2q3',
        question: 'Why should we plant more trees?',
        options: [
          'Because trees are beautiful',
          'Because trees absorb CO2 and produce oxygen',
          'Because trees can make money',
          'Because trees can stop rain'
        ],
        answer: 1,
        explanation: '文中提到"Trees absorb carbon dioxide and produce oxygen."，所以选B。'
      },
      {
        id: 'er2q4',
        question: 'What is the main idea of this passage?',
        options: [
          'How to save money',
          'How to protect the environment',
          'How to plant trees',
          'How to use public transportation'
        ],
        answer: 1,
        explanation: '文章主要讲述了环境面临的问题以及我们可以采取的保护环境的措施，所以主旨是How to protect the environment。'
      }
    ],
    vocabulary: [
      { word: 'pollute', meaning: '污染' },
      { word: 'reusable', meaning: '可重复使用的' },
      { word: 'absorb', meaning: '吸收' },
      { word: 'carbon dioxide', meaning: '二氧化碳' }
    ]
  },
  {
    id: 'er3',
    title: 'The Importance of Reading',
    content: `Reading is one of the most important skills we need in life. It opens up a world of knowledge and imagination.

First, reading helps us learn new things. Through books, we can learn about history, science, culture, and many other subjects. We can travel to different times and places without leaving our room. We can learn from great thinkers and writers from all over the world.

Second, reading improves our language skills. When we read, we are exposed to new words and different ways of expressing ideas. This helps us expand our vocabulary and improve our writing. Good readers are often good writers too.

Third, reading develops our thinking skills. It makes us think critically and analyze information. When we read a story, we try to understand the characters' motivations and predict what will happen next. This exercises our brain and makes us smarter.

Finally, reading brings us joy and relaxation. A good book can take us away from our daily worries and stress. It can make us laugh, cry, or feel excited. Reading before bed can even help us sleep better.

So, make reading a habit. Visit your local library, find books that interest you, and start reading today. Remember: the more you read, the more you know.`,
    questions: [
      {
        id: 'er3q1',
        question: 'According to the passage, what can we learn through books?',
        options: [
          'Only history',
          'Only science',
          'History, science, culture and more',
          'Nothing useful'
        ],
        answer: 2,
        explanation: '文中提到"Through books, we can learn about history, science, culture, and many other subjects."，所以选C。'
      },
      {
        id: 'er3q2',
        question: 'How does reading improve our language skills?',
        options: [
          'By making us speak louder',
          'By exposing us to new words and expressions',
          'By teaching us grammar rules only',
          'By making us write faster'
        ],
        answer: 1,
        explanation: '文中提到"When we read, we are exposed to new words and different ways of expressing ideas."，所以选B。'
      },
      {
        id: 'er3q3',
        question: 'Why does reading develop our thinking skills?',
        options: [
          'Because it makes us memorize everything',
          'Because it makes us think critically and analyze information',
          'Because it helps us sleep better',
          'Because it makes us laugh'
        ],
        answer: 1,
        explanation: '文中提到"reading develops our thinking skills. It makes us think critically and analyze information."，所以选B。'
      },
      {
        id: 'er3q4',
        question: 'What is the writer\'s advice at the end of the passage?',
        options: [
          'To stop reading',
          'To read only at bedtime',
          'To make reading a habit',
          'To buy many books'
        ],
        answer: 2,
        explanation: '文中最后一段开头说"So, make reading a habit."，所以选C。'
      }
    ],
    vocabulary: [
      { word: 'imagination', meaning: '想象力' },
      { word: 'expand', meaning: '扩展' },
      { word: 'critically', meaning: '批判性地' },
      { word: 'motivation', meaning: '动机' }
    ]
  },
  // 扩充阅读理解（4-10）
  {
    id: 'er4',
    title: 'A Visit to the Museum',
    content: `Last Sunday, our class went to the City Museum for a visit. We took the school bus at 8:00 a.m. and arrived there an hour later.

The museum is a large building with three floors. On the first floor, there is an exhibition about the history of our city. We saw many old photos and documents that showed how our city has changed over the past 100 years. On the second floor, there were various artworks from local artists. I was particularly interested in the oil paintings of the countryside. They were so beautiful and lifelike.

The third floor was my favorite. It was a science and technology exhibition. There were many interactive displays where we could try different scientific experiments. I learned a lot about physics and chemistry in a fun way. The robot demonstration was amazing. Those smart robots could dance, play chess, and even draw pictures.

We left the museum at 4:00 p.m. Although we were tired, everyone was happy. It was really an educational and enjoyable trip. I hope to visit the museum again soon.`,
    questions: [
      {
        id: 'er4q1',
        question: 'How did the students go to the museum?',
        options: ['By bus', 'By car', 'By train', 'On foot'],
        answer: 0,
        explanation: '文中提到"We took the school bus at 8:00 a.m."，所以是乘校车去的。'
      },
      {
        id: 'er4q2',
        question: 'What was on the first floor of the museum?',
        options: ['Artworks', 'Science exhibition', 'History exhibition', 'Robot demonstration'],
        answer: 2,
        explanation: '文中提到"On the first floor, there is an exhibition about the history of our city."'
      },
      {
        id: 'er4q3',
        question: 'What could the robots do according to the passage?',
        options: ['Only dance', 'Only play chess', 'Dance, play chess and draw pictures', 'Only draw pictures'],
        answer: 2,
        explanation: '文中提到"Those smart robots could dance, play chess, and even draw pictures."'
      },
      {
        id: 'er4q4',
        question: 'How long did the students stay at the museum?',
        options: ['About 5 hours', 'About 6 hours', 'About 7 hours', 'About 8 hours'],
        answer: 2,
        explanation: '他们9点到达，下午4点离开，大约待了7个小时。'
      }
    ],
    vocabulary: [
      { word: 'exhibition', meaning: '展览' },
      { word: 'document', meaning: '文件' },
      { word: 'interactive', meaning: '互动的' },
      { word: 'demonstration', meaning: '演示' }
    ]
  },
  {
    id: 'er5',
    title: 'My Favorite Season',
    content: `Among the four seasons, spring is my favorite. I love spring for many reasons.

First, the weather in spring is pleasant. It is not too hot or too cold. The temperature is just right for outdoor activities. I enjoy taking walks in the park and feeling the gentle breeze on my face.

Second, spring is a season of new life. Trees turn green and flowers bloom everywhere. The world becomes colorful and beautiful. I especially like cherry blossoms. When they are in full bloom, they look like pink clouds. It is such a beautiful sight.

Third, spring is a good time for sports. After the cold winter, people are eager to go outside and exercise. I often play basketball with my friends after school. It feels great to run and jump in the warm sunshine.

Finally, spring represents hope and new beginnings. It reminds us that life is full of possibilities. Whenever I feel down, I look at the blooming flowers and feel hopeful again.

In conclusion, spring is a wonderful season that brings joy and hope to everyone.`,
    questions: [
      {
        id: 'er5q1',
        question: 'What is the writer\'s favorite season?',
        options: ['Summer', 'Autumn', 'Winter', 'Spring'],
        answer: 3,
        explanation: '文章开头明确说"spring is my favorite"。'
      },
      {
        id: 'er5q2',
        question: 'Why does the writer like the weather in spring?',
        options: ['It is very hot', 'It is very cold', 'It is pleasant and just right', 'It rains a lot'],
        answer: 2,
        explanation: '文中提到"the weather in spring is pleasant. It is not too hot or too cold. The temperature is just right"。'
      },
      {
        id: 'er5q3',
        question: 'What flowers does the writer especially like?',
        options: ['Roses', 'Cherry blossoms', 'Sunflowers', 'Tulips'],
        answer: 1,
        explanation: '文中提到"I especially like cherry blossoms"。'
      },
      {
        id: 'er5q4',
        question: 'What does spring represent according to the writer?',
        options: ['End of life', 'Hope and new beginnings', 'Sadness', 'Cold weather'],
        answer: 1,
        explanation: '文中提到"spring represents hope and new beginnings"。'
      }
    ],
    vocabulary: [
      { word: 'pleasant', meaning: '宜人的' },
      { word: 'bloom', meaning: '开花' },
      { word: 'eager', meaning: '渴望的' },
      { word: 'possibility', meaning: '可能性' }
    ]
  },
  {
    id: 'er6',
    title: 'How to Keep Healthy',
    content: `Health is very important to everyone. Here are some tips on how to keep healthy.

First, eat a balanced diet. You should eat plenty of vegetables and fruits every day. They are rich in vitamins and fiber. Try to eat less junk food like hamburgers and fried chicken. They contain too much fat and salt, which are bad for your health.

Second, exercise regularly. You should do at least 30 minutes of exercise every day. You can run, swim, play basketball, or do any other sports you enjoy. Exercise helps you stay fit and strong. It can also improve your mood and reduce stress.

Third, get enough sleep. Teenagers need about 8 to 10 hours of sleep every night. Good sleep helps your body recover and your brain work better. Try to go to bed early and avoid using electronic devices before sleep.

Fourth, drink plenty of water. Water is essential for your body. It helps remove waste and keep your skin healthy. You should drink at least 8 glasses of water every day.

Finally, maintain a positive attitude. A happy mind leads to a healthy body. Try to stay positive even when facing difficulties.

Follow these tips, and you will live a healthier life.`,
    questions: [
      {
        id: 'er6q1',
        question: 'What should you eat plenty of every day according to the passage?',
        options: ['Junk food', 'Vegetables and fruits', 'Fried chicken', 'Hamburgers'],
        answer: 1,
        explanation: '文中提到"You should eat plenty of vegetables and fruits every day"。'
      },
      {
        id: 'er6q2',
        question: 'How long should you exercise every day?',
        options: ['At least 15 minutes', 'At least 30 minutes', 'At least 45 minutes', 'At least 60 minutes'],
        answer: 1,
        explanation: '文中提到"You should do at least 30 minutes of exercise every day"。'
      },
      {
        id: 'er6q3',
        question: 'How many hours of sleep do teenagers need every night?',
        options: ['6 to 8 hours', '7 to 9 hours', '8 to 10 hours', '10 to 12 hours'],
        answer: 2,
        explanation: '文中提到"Teenagers need about 8 to 10 hours of sleep every night"。'
      },
      {
        id: 'er6q4',
        question: 'What is the main idea of this passage?',
        options: ['How to study well', 'How to keep healthy', 'How to make friends', 'How to save money'],
        answer: 1,
        explanation: '文章主要讲述了如何保持健康的方法。'
      }
    ],
    vocabulary: [
      { word: 'balanced', meaning: '均衡的' },
      { word: 'vitamin', meaning: '维生素' },
      { word: 'fiber', meaning: '纤维' },
      { word: 'essential', meaning: '必不可少的' }
    ]
  },
  {
    id: 'er7',
    title: 'The Story of Thomas Edison',
    content: `Thomas Edison was one of the greatest inventors in history. He was born in 1847 in the United States. During his lifetime, he invented many things that changed the world.

Edison\'s most famous invention was the light bulb. Before the light bulb, people used candles and oil lamps for light. These were dangerous and not very bright. Edison spent years trying to find the right material for the filament. He tested thousands of materials before he found one that worked. Finally, in 1879, he succeeded in creating a practical light bulb.

Another important invention was the phonograph, which could record and play back sound. This was the beginning of the music recording industry. Edison also improved the telephone and the telegraph.

What made Edison so successful? First, he was very curious and always asked questions. Second, he was not afraid of failure. He once said, "I have not failed. I\'ve just found 10,000 ways that won\'t work." Third, he worked very hard. He often worked 18 hours a day.

Edison held 1,093 patents in the United States. His inventions have had a huge impact on modern life. He died in 1931, but his legacy continues to inspire people around the world.`,
    questions: [
      {
        id: 'er7q1',
        question: 'When was Thomas Edison born?',
        options: ['1847', '1879', '1931', '1897'],
        answer: 0,
        explanation: '文中提到"He was born in 1847"。'
      },
      {
        id: 'er7q2',
        question: 'What was Edison\'s most famous invention?',
        options: ['The telephone', 'The telegraph', 'The light bulb', 'The phonograph'],
        answer: 2,
        explanation: '文中提到"Edison\'s most famous invention was the light bulb"。'
      },
      {
        id: 'er7q3',
        question: 'What did Edison say about failure?',
        options: ['"Failure is terrible"', '"I have not failed. I\'ve just found 10,000 ways that won\'t work"', '"Never fail"', '"Failure is the end"'],
        answer: 1,
        explanation: '文中提到"I have not failed. I\'ve just found 10,000 ways that won\'t work"。'
      },
      {
        id: 'er7q4',
        question: 'How many patents did Edison hold in the United States?',
        options: ['109', '1,093', '10,000', '1,903'],
        answer: 1,
        explanation: '文中提到"Edison held 1,093 patents in the United States"。'
      }
    ],
    vocabulary: [
      { word: 'inventor', meaning: '发明家' },
      { word: 'filament', meaning: '灯丝' },
      { word: 'phonograph', meaning: '留声机' },
      { word: 'patent', meaning: '专利' }
    ]
  },
  // 继续扩充阅读理解（8-20）
  {
    id: 'er8',
    title: 'A Letter to My Friend',
    content: `Dear Li Ming,

I hope this letter finds you well. I am writing to tell you about my summer vacation plans.

This summer, I am going to visit Beijing with my parents. We will stay there for a week. First, we plan to visit the Great Wall. I have always wanted to see it with my own eyes. It is one of the greatest wonders of the world. Then, we will go to the Palace Museum. I am very interested in Chinese history, so I am excited to see the ancient buildings and treasures there.

We also plan to try Beijing Roast Duck. Everyone says it is delicious. I can't wait to taste it! Besides, we will walk around the Hutongs to experience the traditional Beijing lifestyle.

After the trip, I will start learning to play the guitar. I think music is wonderful and I want to be able to play my favorite songs.

What are your plans for the summer? Please write back and tell me.

Best wishes,
Wang Tao`,
    questions: [
      {
        id: 'er8q1',
        question: 'Where is Wang Tao going this summer?',
        options: ['Shanghai', 'Beijing', 'Guangzhou', 'Xi\'an'],
        answer: 1,
        explanation: '信中提到"This summer, I am going to visit Beijing with my parents."'
      },
      {
        id: 'er8q2',
        question: 'Which place is NOT mentioned in Wang Tao\'s plan?',
        options: ['The Great Wall', 'The Palace Museum', 'The Summer Palace', 'Hutongs'],
        answer: 2,
        explanation: '信中提到了the Great Wall、the Palace Museum和Hutongs，没有提到the Summer Palace。'
      },
      {
        id: 'er8q3',
        question: 'What food does Wang Tao want to try in Beijing?',
        options: ['Beijing Roast Duck', 'Hot pot', 'Dumplings', 'Noodles'],
        answer: 0,
        explanation: '信中提到"We also plan to try Beijing Roast Duck."'
      },
      {
        id: 'er8q4',
        question: 'What will Wang Tao do after the trip?',
        options: ['Learn to swim', 'Learn to play the guitar', 'Learn to dance', 'Learn to paint'],
        answer: 1,
        explanation: '信中提到"After the trip, I will start learning to play the guitar."'
      }
    ],
    vocabulary: [
      { word: 'vacation', meaning: '假期' },
      { word: 'ancient', meaning: '古老的' },
      { word: 'treasure', meaning: '珍宝' },
      { word: 'lifestyle', meaning: '生活方式' }
    ]
  },
  {
    id: 'er9',
    title: 'The Internet in Our Life',
    content: `The Internet has become an important part of our daily life. It has changed the way we live, work, and study.

First, the Internet makes communication easier. We can use email, instant messaging apps, and video calls to stay in touch with friends and family, no matter where they are. Social media platforms allow us to share our life moments with others.

Second, the Internet provides us with a wealth of information. We can search for anything we want to know. Online libraries and educational websites help us learn new things. Students can find study materials and even take online courses.

Third, online shopping has become very popular. We can buy almost anything on the Internet without leaving home. It saves time and often offers better prices.

However, we should use the Internet wisely. Spending too much time online can affect our health and studies. We should also be careful about our personal information and avoid meeting online friends alone.

In conclusion, the Internet is a powerful tool that brings both benefits and challenges. We should make good use of it while protecting ourselves.`,
    questions: [
      {
        id: 'er9q1',
        question: 'What does the Internet make easier according to the passage?',
        options: ['Cooking', 'Communication', 'Driving', 'Sleeping'],
        answer: 1,
        explanation: '文中提到"the Internet makes communication easier"。'
      },
      {
        id: 'er9q2',
        question: 'What can students do on the Internet?',
        options: ['Only play games', 'Only watch videos', 'Find study materials and take online courses', 'Only chat with friends'],
        answer: 2,
        explanation: '文中提到"Students can find study materials and even take online courses."。'
      },
      {
        id: 'er9q3',
        question: 'Why has online shopping become popular?',
        options: ['It is more expensive', 'It saves time and offers better prices', 'It is more difficult', 'It takes more time'],
        answer: 1,
        explanation: '文中提到"It saves time and often offers better prices."。'
      },
      {
        id: 'er9q4',
        question: 'What warning does the writer give about using the Internet?',
        options: ['We should never use it', 'We should use it all day', 'We should be careful about personal information', 'We should meet all online friends'],
        answer: 2,
        explanation: '文中提到"We should also be careful about our personal information"。'
      }
    ],
    vocabulary: [
      { word: 'instant', meaning: '即时的' },
      { word: 'platform', meaning: '平台' },
      { word: 'wealth', meaning: '大量；财富' },
      { word: 'challenge', meaning: '挑战' }
    ]
  },
  {
    id: 'er10',
    title: 'My Hobby - Collecting Stamps',
    content: `Everyone has hobbies, and my hobby is collecting stamps. I started collecting stamps when I was eight years old. Now I have more than 500 stamps from different countries.

My father gave me my first stamp album on my eighth birthday. It was a beautiful album with pictures of animals on the cover. My first stamp was from China. It had a picture of the Giant Panda on it. I thought it was so lovely that I decided to collect more stamps.

Stamp collecting is very interesting. Each stamp tells a story. Some stamps show beautiful scenery, some show famous people, and others show important historical events. Through stamps, I have learned a lot about different countries and their cultures.

I usually get stamps from letters and postcards. Sometimes my relatives and friends give me stamps when they travel abroad. I also exchange stamps with other collectors at school.

Stamp collecting has taught me patience and organization. I need to sort my stamps carefully and keep them in good condition. It also helps me learn geography and history in a fun way.

I really enjoy my hobby. It brings me joy and knowledge. I will continue collecting stamps for many years to come.`,
    questions: [
      {
        id: 'er10q1',
        question: 'When did the writer start collecting stamps?',
        options: ['At age 6', 'At age 7', 'At age 8', 'At age 9'],
        answer: 2,
        explanation: '文中提到"I started collecting stamps when I was eight years old."。'
      },
      {
        id: 'er10q2',
        question: 'What was on the writer\'s first stamp?',
        options: ['A tiger', 'A lion', 'A Giant Panda', 'An elephant'],
        answer: 2,
        explanation: '文中提到"My first stamp was from China. It had a picture of the Giant Panda on it."。'
      },
      {
        id: 'er10q3',
        question: 'How does the writer usually get stamps?',
        options: ['Only buy them', 'From letters and postcards', 'Only from friends', 'Only from shops'],
        answer: 1,
        explanation: '文中提到"I usually get stamps from letters and postcards."。'
      },
      {
        id: 'er10q4',
        question: 'What has stamp collecting taught the writer?',
        options: ['Only geography', 'Only history', 'Patience and organization', 'Only art'],
        answer: 2,
        explanation: '文中提到"Stamp collecting has taught me patience and organization."。'
      }
    ],
    vocabulary: [
      { word: 'album', meaning: '相册；集邮册' },
      { word: 'scenery', meaning: '风景' },
      { word: 'relative', meaning: '亲戚' },
      { word: 'condition', meaning: '状况' }
    ]
  },
  {
    id: 'er11',
    title: 'A Kind Stranger',
    content: `Last Friday afternoon, I was walking home from school when it suddenly started to rain heavily. I didn't have an umbrella with me, so I had to run to find a place to shelter.

I stood under a tree, but the rain was so heavy that I still got wet. I was cold and worried because I had a lot of homework to do and didn't want to get sick.

Just then, an old lady came over with an umbrella. She smiled at me and said, "Young man, you will catch a cold if you stay here. My house is just around the corner. Come with me and wait for the rain to stop."

I was a little hesitant at first because my parents always told me not to go with strangers. But the lady looked kind and sincere. I decided to trust her.

We walked to her house together. It was a small but cozy home. She gave me a towel to dry myself and a cup of hot tea. We talked while waiting for the rain to stop. She told me stories about her grandchildren who were about my age.

About an hour later, the rain stopped. I thanked her sincerely and went home. I will never forget her kindness. She taught me that there are still good people in this world.`,
    questions: [
      {
        id: 'er11q1',
        question: 'Why did the writer get wet?',
        options: ['He fell into a river', 'He had no umbrella when it rained heavily', 'He played in the rain', 'He forgot his raincoat'],
        answer: 1,
        explanation: '文中提到"I didn\'t have an umbrella with me"和"I still got wet"。'
      },
      {
        id: 'er11q2',
        question: 'What did the old lady offer to do?',
        options: ['Give him money', 'Take him to her house to wait for the rain to stop', 'Buy him an umbrella', 'Drive him home'],
        answer: 1,
        explanation: '文中提到"Come with me and wait for the rain to stop."。'
      },
      {
        id: 'er11q3',
        question: 'Why was the writer hesitant at first?',
        options: ['He didn\'t like the lady', 'His parents told him not to go with strangers', 'He wanted to stay in the rain', 'He was in a hurry'],
        answer: 1,
        explanation: '文中提到"my parents always told me not to go with strangers"。'
      },
      {
        id: 'er11q4',
        question: 'What did the writer learn from this experience?',
        options: ['Not to trust anyone', 'To always carry an umbrella', 'There are still good people in the world', 'To avoid strangers'],
        answer: 2,
        explanation: '文中最后提到"She taught me that there are still good people in this world."。'
      }
    ],
    vocabulary: [
      { word: 'shelter', meaning: '躲避处' },
      { word: 'hesitant', meaning: '犹豫的' },
      { word: 'sincere', meaning: '真诚的' },
      { word: 'cozy', meaning: '舒适的' }
    ]
  },
  {
    id: 'er12',
    title: 'Learning a New Language',
    content: `Learning a new language can be challenging but also very rewarding. I have been learning English for five years, and I would like to share some tips that have helped me.

First, practice every day. Language learning requires consistency. Even if you only have 15 minutes a day, use that time to review vocabulary or listen to English songs. Regular practice is more effective than cramming once a week.

Second, don't be afraid of making mistakes. Many students feel embarrassed when they make errors, but mistakes are actually good opportunities to learn. When someone corrects you, remember the correction and try not to make the same mistake again.

Third, immerse yourself in the language. Watch English movies, read English books, and listen to English podcasts. The more you expose yourself to the language, the more natural it will become.

Fourth, find a language partner. Practicing with a native speaker or someone who is also learning can be very helpful. You can help each other and make learning more fun.

Finally, be patient. Learning a language takes time. Don't get discouraged if you don't see progress immediately. Keep practicing, and you will improve.

Remember: the journey of learning a language is as important as the destination. Enjoy the process!`,
    questions: [
      {
        id: 'er12q1',
        question: 'How long has the writer been learning English?',
        options: ['Two years', 'Three years', 'Five years', 'Ten years'],
        answer: 2,
        explanation: '文中提到"I have been learning English for five years"。'
      },
      {
        id: 'er12q2',
        question: 'What does the writer suggest about making mistakes?',
        options: ['Avoid making mistakes', 'Be afraid of mistakes', 'Mistakes are good opportunities to learn', 'Never speak if you might make mistakes'],
        answer: 2,
        explanation: '文中提到"mistakes are actually good opportunities to learn"。'
      },
      {
        id: 'er12q3',
        question: 'What does "immerse yourself in the language" mean?',
        options: ['Study grammar only', 'Surround yourself with the language', 'Avoid speaking', 'Only read textbooks'],
        answer: 1,
        explanation: '文中提到"Watch English movies, read English books, and listen to English podcasts"，意思是用各种方式接触这门语言。'
      },
      {
        id: 'er12q4',
        question: 'What is the writer\'s final advice?',
        options: ['Give up if it\'s hard', 'Be patient', 'Study only on weekends', 'Don\'t practice every day'],
        answer: 1,
        explanation: '文中提到"Finally, be patient. Learning a language takes time."。'
      }
    ],
    vocabulary: [
      { word: 'rewarding', meaning: '有回报的' },
      { word: 'consistency', meaning: '坚持；一致性' },
      { word: 'cramming', meaning: '临时抱佛脚' },
      { word: 'immerse', meaning: '沉浸' }
    ]
  },
  {
    id: 'er13',
    title: 'A Day at the Zoo',
    content: `Last Saturday, my family and I went to the city zoo. It was a sunny day, perfect for an outdoor activity.

When we arrived, we first visited the panda house. The giant pandas were so cute! They were eating bamboo and rolling around. I could have watched them for hours. My little sister was especially excited because pandas are her favorite animals.

Next, we went to see the elephants. They were enormous! One elephant was spraying water with its trunk. A zookeeper was telling visitors about elephant habits. We learned that elephants are very intelligent animals with excellent memories.

After that, we watched a dolphin show. The dolphins were amazing. They could jump high out of the water, spin in the air, and even play ball with their trainers. The show was both entertaining and educational.

At noon, we had lunch at a restaurant in the zoo. I had a hamburger and some juice. After lunch, we visited the monkey area. The monkeys were very active, swinging from tree to tree and playing with each other.

Before leaving, we stopped at the gift shop. I bought a panda keychain as a souvenir. It was a wonderful day. I not only saw many interesting animals but also learned a lot about wildlife protection.`,
    questions: [
      {
        id: 'er13q1',
        question: 'What was the weather like last Saturday?',
        options: ['Rainy', 'Cloudy', 'Sunny', 'Snowy'],
        answer: 2,
        explanation: '文中提到"It was a sunny day"。'
      },
      {
        id: 'er13q2',
        question: 'What were the pandas doing when the writer saw them?',
        options: ['Sleeping', 'Eating bamboo and rolling around', 'Playing with balls', 'Swimming'],
        answer: 1,
        explanation: '文中提到"They were eating bamboo and rolling around."。'
      },
      {
        id: 'er13q3',
        question: 'What did the writer learn about elephants?',
        options: ['They are small animals', 'They are not intelligent', 'They are intelligent with excellent memories', 'They cannot remember anything'],
        answer: 2,
        explanation: '文中提到"elephants are very intelligent animals with excellent memories"。'
      },
      {
        id: 'er13q4',
        question: 'What did the writer buy at the gift shop?',
        options: ['A toy elephant', 'A panda keychain', 'A book about dolphins', 'A T-shirt'],
        answer: 1,
        explanation: '文中提到"I bought a panda keychain as a souvenir."。'
      }
    ],
    vocabulary: [
      { word: 'enormous', meaning: '巨大的' },
      { word: 'spray', meaning: '喷洒' },
      { word: 'trunk', meaning: '象鼻' },
      { word: 'souvenir', meaning: '纪念品' }
    ]
  },
  {
    id: 'er14',
    title: 'The Benefits of Team Sports',
    content: `Playing team sports is one of the best activities for young people. It offers many benefits that go beyond physical health.

First, team sports help us stay physically fit. Regular exercise strengthens our muscles, improves our cardiovascular health, and helps us maintain a healthy weight. When we play sports like basketball, soccer, or volleyball, we get a full-body workout while having fun.

Second, team sports teach us important life skills. We learn how to work with others towards a common goal. We understand that everyone's contribution matters and that we can achieve more together than alone. This teamwork skill is valuable in school projects and future careers.

Third, playing on a team helps us develop communication skills. We need to talk to our teammates during games, discuss strategies, and give each other encouragement. Good communication is essential for success in any team activity.

Fourth, team sports build character. We learn to win with humility and lose with grace. We understand that failure is part of learning and that hard work leads to improvement. These lessons help us become better people.

Finally, team sports provide opportunities to make friends. The bonds formed through shared experiences on the field often last a lifetime.

I encourage everyone to join a team sport. It will make you healthier, happier, and more confident.`,
    questions: [
      {
        id: 'er14q1',
        question: 'What is the main topic of this passage?',
        options: ['Individual sports', 'Team sports benefits', 'Healthy eating', 'Academic study'],
        answer: 1,
        explanation: '文章主要讲述了团队运动的多种好处。'
      },
      {
        id: 'er14q2',
        question: 'What life skill do team sports teach?',
        options: ['Working alone', 'Teamwork', 'Avoiding challenges', 'Ignoring others'],
        answer: 1,
        explanation: '文中提到"We learn how to work with others towards a common goal"和"This teamwork skill"。'
      },
      {
        id: 'er14q3',
        question: 'What does the writer say about failure?',
        options: ['Failure is terrible', 'Failure should be avoided', 'Failure is part of learning', 'Failure means giving up'],
        answer: 2,
        explanation: '文中提到"We understand that failure is part of learning"。'
      },
      {
        id: 'er14q4',
        question: 'What is the writer\'s final suggestion?',
        options: ['Study more', 'Join a team sport', 'Watch sports on TV', 'Play video games'],
        answer: 1,
        explanation: '文中最后说"I encourage everyone to join a team sport."。'
      }
    ],
    vocabulary: [
      { word: 'cardiovascular', meaning: '心血管的' },
      { word: 'contribution', meaning: '贡献' },
      { word: 'strategy', meaning: '策略' },
      { word: 'humility', meaning: '谦逊' }
    ]
  },
  {
    id: 'er15',
    title: 'My Dream Job',
    content: `Everyone has dreams, and my dream is to become a doctor. I want to help people and make a difference in their lives.

I first became interested in medicine when I was ten years old. My grandmother was very sick, and she was in the hospital for a long time. The doctors and nurses took such good care of her. They were kind, patient, and professional. Thanks to their help, my grandmother recovered. From that day on, I decided that I wanted to be a doctor too.

Being a doctor is not easy. It requires many years of study and hard work. First, I need to do well in school, especially in science subjects like biology and chemistry. Then, I will need to go to medical school and complete years of training. But I am willing to work hard for my dream.

I know that doctors have a lot of responsibility. They need to make important decisions that affect people's lives. They often work long hours and deal with stressful situations. However, the reward of saving lives and helping people recover from illness makes it all worthwhile.

I also want to be a doctor who treats patients with kindness and respect. I believe that good communication and a caring attitude are just as important as medical knowledge.

I will continue to work hard towards my dream. I believe that with determination and effort, I can become a good doctor one day.`,
    questions: [
      {
        id: 'er15q1',
        question: 'What is the writer\'s dream job?',
        options: ['Teacher', 'Doctor', 'Engineer', 'Scientist'],
        answer: 1,
        explanation: '文中开头提到"my dream is to become a doctor"。'
      },
      {
        id: 'er15q2',
        question: 'Why did the writer want to become a doctor?',
        options: ['To make a lot of money', 'Because doctors helped his/her grandmother recover', 'Because it is easy', 'Because of the long working hours'],
        answer: 1,
        explanation: '文中提到医生护士照顾奶奶，奶奶康复后，作者决定要成为医生。'
      },
      {
        id: 'er15q3',
        question: 'What subjects does the writer need to do well in?',
        options: ['Only math', 'Only English', 'Science subjects like biology and chemistry', 'Only history'],
        answer: 2,
        explanation: '文中提到"especially in science subjects like biology and chemistry"。'
      },
      {
        id: 'er15q4',
        question: 'What does the writer believe is important for a doctor?',
        options: ['Only medical knowledge', 'Only working long hours', 'Kindness, respect, and good communication', 'Only making money'],
        answer: 2,
        explanation: '文中提到"I believe that good communication and a caring attitude are just as important as medical knowledge."。'
      }
    ],
    vocabulary: [
      { word: 'recover', meaning: '康复' },
      { word: 'responsibility', meaning: '责任' },
      { word: 'worthwhile', meaning: '值得的' },
      { word: 'determination', meaning: '决心' }
    ]
  },
  {
    id: 'er16',
    title: 'A Trip to the Countryside',
    content: `Last month, my family and I visited my grandparents in the countryside. It was a refreshing change from city life.

My grandparents live in a small village surrounded by green hills and clear streams. Their house is a traditional farmhouse with a large yard. In the yard, they grow vegetables and keep some chickens.

Every morning, I woke up to the sound of birds singing instead of car horns. The air was so fresh and clean. I could see the blue sky and white clouds clearly. It was very different from the busy, noisy city where I live.

During the day, I helped my grandparents with farm work. I fed the chickens, watered the vegetables, and picked some fresh fruit from the trees. It was hard work, but I enjoyed it. I learned that food doesn't just come from supermarkets - it takes a lot of effort to grow.

In the evening, we had dinner together. My grandmother cooked delicious dishes using fresh vegetables from her garden. Everything tasted so good! After dinner, we sat outside and looked at the stars. There were so many stars visible in the countryside, unlike in the city where lights make them hard to see.

The trip made me appreciate the simple things in life. I hope to visit my grandparents again soon.`,
    questions: [
      {
        id: 'er16q1',
        question: 'Where do the writer\'s grandparents live?',
        options: ['In a big city', 'In the countryside', 'By the sea', 'In the mountains'],
        answer: 1,
        explanation: '文中提到"my grandparents in the countryside"。'
      },
      {
        id: 'er16q2',
        question: 'What did the writer wake up to in the countryside?',
        options: ['Car horns', 'Birds singing', 'Alarm clock', 'Music'],
        answer: 1,
        explanation: '文中提到"I woke up to the sound of birds singing instead of car horns"。'
      },
      {
        id: 'er16q3',
        question: 'What did the writer learn from the farm work?',
        options: ['Food is easy to get', 'Food only comes from supermarkets', 'It takes effort to grow food', 'Farming is not important'],
        answer: 2,
        explanation: '文中提到"I learned that food doesn\'t just come from supermarkets - it takes a lot of effort to grow."。'
      },
      {
        id: 'er16q4',
        question: 'Why could the writer see many stars?',
        options: ['The city lights were too bright', 'There were no city lights to block the view', 'The stars were bigger', 'It was a special night'],
        answer: 1,
        explanation: '文中提到"unlike in the city where lights make them hard to see"，说明乡村没有城市灯光的干扰。'
      }
    ],
    vocabulary: [
      { word: 'refreshing', meaning: '令人耳目一新的' },
      { word: 'traditional', meaning: '传统的' },
      { word: 'surround', meaning: '环绕' },
      { word: 'appreciate', meaning: '欣赏；感激' }
    ]
  },
  {
    id: 'er17',
    title: 'The History of Paper',
    content: `Paper is something we use every day, but do you know how it was invented? The history of paper is fascinating.

Before paper was invented, people wrote on many different materials. The ancient Egyptians wrote on papyrus, a material made from plants. The ancient Chinese wrote on bamboo slips or silk. However, these materials were either too heavy or too expensive.

Paper was invented in China around 2,000 years ago during the Han Dynasty. A man named Cai Lun is credited with inventing paper. He made paper from tree bark, old rags, and other plant fibers. This new material was light, cheap, and easy to write on.

The invention of paper was revolutionary. It made writing and reading more accessible to ordinary people. Knowledge could be recorded and spread more easily. Books became more common, and education improved.

The technology of papermaking slowly spread to other parts of the world. It reached Korea and Japan first, then the Arab world, and eventually Europe. By the 14th century, paper mills existed in many European countries.

Today, paper is still important, though we also use digital technology. However, we should remember to use paper wisely and recycle it to protect our environment. Millions of trees are cut down every year to make paper, so conservation is essential.

The invention of paper is one of the most important contributions to human civilization.`,
    questions: [
      {
        id: 'er17q1',
        question: 'What did ancient Egyptians write on before paper?',
        options: ['Bamboo', 'Silk', 'Papyrus', 'Stone'],
        answer: 2,
        explanation: '文中提到"The ancient Egyptians wrote on papyrus"。'
      },
      {
        id: 'er17q2',
        question: 'Who is credited with inventing paper?',
        options: ['Confucius', 'Cai Lun', 'Marco Polo', 'Gutenberg'],
        answer: 1,
        explanation: '文中提到"A man named Cai Lun is credited with inventing paper."。'
      },
      {
        id: 'er17q3',
        question: 'What materials did Cai Lun use to make paper?',
        options: ['Only silk', 'Tree bark, old rags, and plant fibers', 'Only bamboo', 'Only stone'],
        answer: 1,
        explanation: '文中提到"He made paper from tree bark, old rags, and other plant fibers."。'
      },
      {
        id: 'er17q4',
        question: 'Why is paper conservation important?',
        options: ['Paper is too expensive', 'Millions of trees are cut down to make paper', 'Paper is not useful', 'Digital technology is not available'],
        answer: 1,
        explanation: '文中提到"Millions of trees are cut down every year to make paper, so conservation is essential."。'
      }
    ],
    vocabulary: [
      { word: 'fascinating', meaning: '迷人的' },
      { word: 'revolutionary', meaning: '革命性的' },
      { word: 'accessible', meaning: '可获得的' },
      { word: 'civilization', meaning: '文明' }
    ]
  },
  {
    id: 'er18',
    title: 'Volunteering Experience',
    content: `Last summer vacation, I had a meaningful experience volunteering at a local animal shelter. It was an eye-opening experience that taught me many valuable lessons.

I decided to volunteer because I love animals and wanted to help those in need. The shelter takes care of abandoned and injured animals, mostly cats and dogs. Many of these animals were once pets but were left on the streets by their owners.

My main tasks included feeding the animals, cleaning their cages, and playing with them. I also helped with bathing the dogs and brushing the cats. It was hard work, especially in the hot summer, but seeing the animals happy made it all worthwhile.

There was a small dog named Lucky who touched my heart. He was very scared of people when he first arrived at the shelter. He would hide in the corner of his cage and shake. I spent extra time with him every day, talking to him gently and giving him treats. Slowly, he started to trust me. By the end of my volunteer period, he would run to me when I approached his cage. It was a wonderful feeling to see his transformation.

This experience taught me the importance of responsibility and compassion. These animals depend on humans for their survival. We should treat all living creatures with kindness and respect.

I plan to continue volunteering at the shelter during my free time. It brings me joy to help these innocent animals.`,
    questions: [
      {
        id: 'er18q1',
        question: 'Where did the writer volunteer?',
        options: ['At a hospital', 'At a school', 'At an animal shelter', 'At a library'],
        answer: 2,
        explanation: '文中提到"volunteering at a local animal shelter"。'
      },
      {
        id: 'er18q2',
        question: 'What was one of the writer\'s tasks?',
        options: ['Teaching classes', 'Feeding the animals', 'Building houses', 'Selling tickets'],
        answer: 1,
        explanation: '文中提到"My main tasks included feeding the animals"。'
      },
      {
        id: 'er18q3',
        question: 'How was Lucky when he first arrived?',
        options: ['Very friendly', 'Scared of people', 'Very active', 'Aggressive'],
        answer: 1,
        explanation: '文中提到"He was very scared of people when he first arrived"。'
      },
      {
        id: 'er18q4',
        question: 'What did the writer learn from this experience?',
        options: ['Animals are not important', 'The importance of responsibility and compassion', 'Volunteering is a waste of time', 'Animals don\'t need help'],
        answer: 1,
        explanation: '文中提到"This experience taught me the importance of responsibility and compassion."。'
      }
    ],
    vocabulary: [
      { word: 'abandoned', meaning: '被遗弃的' },
      { word: 'injured', meaning: '受伤的' },
      { word: 'transformation', meaning: '转变' },
      { word: 'compassion', meaning: '同情心' }
    ]
  },
  {
    id: 'er19',
    title: 'Traditional Chinese Festivals',
    content: `China has many traditional festivals that have been celebrated for thousands of years. These festivals are an important part of Chinese culture.

The Spring Festival, also known as Chinese New Year, is the most important festival in China. It usually falls in January or February. Families get together to celebrate. People eat dumplings, set off fireworks, and give red envelopes with money to children. The festival marks the beginning of a new year and represents hope and new beginnings.

The Dragon Boat Festival is celebrated on the fifth day of the fifth lunar month. It honors the ancient poet Qu Yuan. People eat zongzi (sticky rice dumplings) and hold dragon boat races. The festival is also associated with health and warding off diseases.

The Mid-Autumn Festival falls on the 15th day of the eighth lunar month when the moon is at its fullest. Families gather to admire the full moon and eat mooncakes. The round moon and round mooncakes symbolize family reunion and completeness.

The Qingming Festival, or Tomb Sweeping Day, is a time to remember ancestors. Families visit the graves of their loved ones, clean the tombstones, and offer food and flowers. It is a day to show respect to the deceased.

These traditional festivals help preserve Chinese culture and strengthen family bonds. They remind us of our history and values. In modern times, some traditions have changed, but the spirit of these festivals remains. It is important for young people to learn about and carry on these traditions.`,
    questions: [
      {
        id: 'er19q1',
        question: 'What is the most important festival in China?',
        options: ['Dragon Boat Festival', 'Mid-Autumn Festival', 'Spring Festival', 'Qingming Festival'],
        answer: 2,
        explanation: '文中提到"The Spring Festival, also known as Chinese New Year, is the most important festival in China."。'
      },
      {
        id: 'er19q2',
        question: 'What do people eat during the Dragon Boat Festival?',
        options: ['Dumplings', 'Mooncakes', 'Zongzi', 'Noodles'],
        answer: 2,
        explanation: '文中提到"People eat zongzi (sticky rice dumplings)"。'
      },
      {
        id: 'er19q3',
        question: 'What does the full moon symbolize during the Mid-Autumn Festival?',
        options: ['Separation', 'Family reunion and completeness', 'Sadness', 'Wealth'],
        answer: 1,
        explanation: '文中提到"The round moon and round mooncakes symbolize family reunion and completeness."。'
      },
      {
        id: 'er19q4',
        question: 'What do people do during the Qingming Festival?',
        options: ['Have parties', 'Visit graves and remember ancestors', 'Set off fireworks', 'Eat special food only'],
        answer: 1,
        explanation: '文中提到"Families visit the graves of their loved ones, clean the tombstones, and offer food and flowers."。'
      }
    ],
    vocabulary: [
      { word: 'represent', meaning: '代表' },
      { word: 'ward off', meaning: '避开；防止' },
      { word: 'symbolize', meaning: '象征' },
      { word: 'deceased', meaning: '已故的' }
    ]
  },
  {
    id: 'er20',
    title: 'How to Manage Your Time',
    content: `Time management is an important skill for students. With good time management, you can get more done and still have time for fun. Here are some tips to help you manage your time better.

First, make a schedule. Write down all your tasks and activities for the day or week. Include schoolwork, hobbies, and free time. Having a schedule helps you see what needs to be done and plan accordingly.

Second, prioritize your tasks. Not all tasks are equally important. Identify which tasks are urgent and important, and do those first. Less important tasks can wait. This way, you won't waste time on things that don't matter.

Third, avoid procrastination. Putting off work until the last minute causes stress and often leads to poor results. When you have a task to do, start working on it right away. Break large tasks into smaller, manageable parts so they don't seem overwhelming.

Fourth, eliminate distractions. When you're studying, turn off your phone or put it in another room. Don't check social media or play games until your work is done. Find a quiet place where you can focus.

Fifth, take regular breaks. Your brain needs rest to work well. Study for 45-50 minutes, then take a 10-minute break. Get up, stretch, or have a snack. You'll return to your work refreshed and more productive.

Finally, review your day. Before going to bed, think about what you accomplished and what you could do better tomorrow. This helps you improve your time management skills over time.

Remember: Time is precious. Once it's gone, you can't get it back. Use your time wisely!`,
    questions: [
      {
        id: 'er20q1',
        question: 'What is the first tip for time management?',
        options: ['Take breaks', 'Make a schedule', 'Avoid procrastination', 'Eliminate distractions'],
        answer: 1,
        explanation: '文中提到"First, make a schedule."。'
      },
      {
        id: 'er20q2',
        question: 'What should you do with urgent and important tasks?',
        options: ['Do them first', 'Do them last', 'Ignore them', 'Ask someone else to do them'],
        answer: 0,
        explanation: '文中提到"Identify which tasks are urgent and important, and do those first."。'
      },
      {
        id: 'er20q3',
        question: 'Why should you avoid procrastination?',
        options: ['It causes stress and poor results', 'It is fun', 'It saves time', 'It helps you relax'],
        answer: 0,
        explanation: '文中提到"Putting off work until the last minute causes stress and often leads to poor results."。'
      },
      {
        id: 'er20q4',
        question: 'How long should you study before taking a break?',
        options: ['10 minutes', '30 minutes', '45-50 minutes', '2 hours'],
        answer: 2,
        explanation: '文中提到"Study for 45-50 minutes, then take a 10-minute break."。'
      }
    ],
    vocabulary: [
      { word: 'prioritize', meaning: '确定优先顺序' },
      { word: 'procrastination', meaning: '拖延' },
      { word: 'overwhelming', meaning: '压倒性的' },
      { word: 'precious', meaning: '珍贵的' }
    ]
  }
];

export const englishCategories = [
  { id: 'vocabulary', name: '单词背诵', description: '初中核心词汇', icon: '📚' },
  { id: 'grammar', name: '语法练习', description: '语法选择题', icon: '✏️' },
  { id: 'reading', name: '阅读理解', description: '英语阅读训练', icon: '📖' }
];
