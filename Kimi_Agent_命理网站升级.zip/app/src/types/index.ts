// 用户类型
export interface User {
  name: string;
  grade: string;
  avatar?: string;
}

// 学习进度
export interface Progress {
  math: number;
  chinese: number;
  english: number;
  total: number;
}

// 数学题目
export interface MathQuestion {
  id: string;
  type: 'transition' | 'algebra' | 'geometry' | 'word';
  difficulty: 'easy' | 'medium' | 'hard';
  question: string;
  options?: string[];
  answer: string | number;
  explanation: string;
  knowledge: string;
}

// 语文古诗词
export interface Poem {
  id: string;
  title: string;
  author: string;
  dynasty: string;
  content: string[];
  translation: string;
  appreciation: string;
  keySentences: string[];
}

// 阅读理解
export interface Reading {
  id: string;
  title: string;
  author: string;
  content: string;
  questions: ReadingQuestion[];
}

export interface ReadingQuestion {
  id: string;
  question: string;
  options: string[];
  answer: number;
  explanation: string;
}

// 英语单词
export interface Word {
  id: string;
  word: string;
  phonetic: string;
  meaning: string;
  example: string;
  exampleTranslation: string;
  category: string;
}

// 英语语法题
export interface GrammarQuestion {
  id: string;
  type: 'choice' | 'fill' | 'correction';
  question: string;
  options?: string[];
  answer: string | number;
  explanation: string;
  knowledge: string;
}

// 英语阅读
export interface EnglishReading {
  id: string;
  title: string;
  content: string;
  questions: ReadingQuestion[];
  vocabulary: { word: string; meaning: string }[];
}

// 学习记录
export interface StudyRecord {
  subject: 'math' | 'chinese' | 'english';
  type: string;
  itemId: string;
  correct: boolean;
  timestamp: number;
}

// 错题记录
export interface WrongAnswer {
  question: MathQuestion;
  userAnswer: string | number;
  timestamp: number;
}
