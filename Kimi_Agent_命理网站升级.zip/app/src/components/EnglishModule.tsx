import { useState, useEffect } from 'react';
import { Languages, Volume2, CheckCircle, XCircle, Lightbulb, ArrowRight, BookOpen, Trophy, RotateCcw, Eye, EyeOff } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { words, grammarQuestions, englishReadings } from '@/data';
import type { EnglishReading } from '@/types';

interface EnglishModuleProps {
  onProgressUpdate: (progress: number) => void;
}

export function EnglishModule({ onProgressUpdate }: EnglishModuleProps) {
  const [activeTab, setActiveTab] = useState('vocabulary');
  
  // Vocabulary state
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [showWordMeaning, setShowWordMeaning] = useState(false);
  const [learnedWords, setLearnedWords] = useState<string[]>([]);
  const [wordCategory, setWordCategory] = useState<string>('all');

  // Grammar state
  const [currentGrammarIndex, setCurrentGrammarIndex] = useState(0);
  const [selectedGrammarAnswer, setSelectedGrammarAnswer] = useState<number | null>(null);
  const [showGrammarResult, setShowGrammarResult] = useState(false);
  const [completedGrammar, setCompletedGrammar] = useState<string[]>([]);
  const [correctGrammarCount, setCorrectGrammarCount] = useState(0);

  // Reading state
  const [selectedReading, setSelectedReading] = useState<EnglishReading | null>(null);
  const [readingAnswers, setReadingAnswers] = useState<Record<string, number>>({});
  const [showReadingResults, setShowReadingResults] = useState(false);
  const [completedReadings, setCompletedReadings] = useState<string[]>([]);

  const filteredWords = wordCategory === 'all' 
    ? words 
    : words.filter(w => w.category === wordCategory);

  const currentWord = filteredWords[currentWordIndex];
  const currentGrammar = grammarQuestions[currentGrammarIndex];

  // Word functions
  const nextWord = () => {
    setCurrentWordIndex((prev) => (prev + 1) % filteredWords.length);
    setShowWordMeaning(false);
  };

  const prevWord = () => {
    setCurrentWordIndex((prev) => (prev - 1 + filteredWords.length) % filteredWords.length);
    setShowWordMeaning(false);
  };

  const markWordLearned = () => {
    if (!learnedWords.includes(currentWord.id)) {
      setLearnedWords([...learnedWords, currentWord.id]);
      toast.success('已标记为已学习！');
      updateVocabProgress();
    }
  };

  const updateVocabProgress = () => {
    const progress = Math.min(100, Math.floor((learnedWords.length + 1) / words.length * 35));
    onProgressUpdate(progress);
  };

  // Grammar functions
  const checkGrammarAnswer = () => {
    if (selectedGrammarAnswer === null) return;

    const correct = selectedGrammarAnswer === currentGrammar.answer;
    setShowGrammarResult(true);

    if (!completedGrammar.includes(currentGrammar.id)) {
      setCompletedGrammar([...completedGrammar, currentGrammar.id]);
      if (correct) {
        setCorrectGrammarCount(correctGrammarCount + 1);
        toast.success('回答正确！');
      } else {
        toast.error('回答错误，再看看解析吧！');
      }
      updateGrammarProgress();
    }
  };

  const nextGrammar = () => {
    setCurrentGrammarIndex((prev) => (prev + 1) % grammarQuestions.length);
    setSelectedGrammarAnswer(null);
    setShowGrammarResult(false);
  };

  const updateGrammarProgress = () => {
    const progress = Math.min(100, 35 + Math.floor((completedGrammar.length + 1) / grammarQuestions.length * 35));
    onProgressUpdate(progress);
  };

  // Reading functions
  const handleReadingAnswer = (questionId: string, answer: number) => {
    setReadingAnswers({ ...readingAnswers, [questionId]: answer });
  };

  const submitReading = () => {
    if (!selectedReading) return;

    const allAnswered = selectedReading.questions.every(q => 
      readingAnswers[q.id] !== undefined
    );

    if (!allAnswered) {
      toast.error('请先回答所有问题！');
      return;
    }

    setShowReadingResults(true);

    if (!completedReadings.includes(selectedReading.id)) {
      setCompletedReadings([...completedReadings, selectedReading.id]);
      const correctCount = selectedReading.questions.filter(q => 
        readingAnswers[q.id] === q.answer
      ).length;
      toast.success(`完成阅读！答对 ${correctCount}/${selectedReading.questions.length} 题`);
      updateReadingProgress();
    }
  };

  const updateReadingProgress = () => {
    const progress = Math.min(100, 70 + Math.floor((completedReadings.length + 1) / englishReadings.length * 30));
    onProgressUpdate(progress);
  };

  const resetReading = () => {
    setShowReadingResults(false);
    setReadingAnswers({});
  };

  const playWordAudio = (word: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.lang = 'en-US';
      speechSynthesis.speak(utterance);
    } else {
      toast.error('您的浏览器不支持语音播放');
    }
  };

  // Calculate total progress
  useEffect(() => {
    const vocabProgress = Math.floor(learnedWords.length / words.length * 35);
    const grammarProgress = Math.floor(completedGrammar.length / grammarQuestions.length * 35);
    const readingProgress = Math.floor(completedReadings.length / englishReadings.length * 30);
    onProgressUpdate(Math.min(100, vocabProgress + grammarProgress + readingProgress));
  }, [learnedWords, completedGrammar, completedReadings]);

  // Reading Detail View
  if (selectedReading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Button variant="outline" onClick={() => setSelectedReading(null)} className="mb-6">
            ← 返回列表
          </Button>

          <Card className="mb-6">
            <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
              <div className="flex items-center justify-between">
                <div>
                  <Badge className="mb-2">英语阅读</Badge>
                  <CardTitle className="text-xl">{selectedReading.title}</CardTitle>
                </div>
                {completedReadings.includes(selectedReading.id) && (
                  <Badge className="bg-green-100 text-green-700">已完成</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {/* Vocabulary */}
              <div className="mb-6 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-bold text-sm mb-2 text-blue-700">重点词汇</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedReading.vocabulary.map((vocab, idx) => (
                    <div key={idx} className="bg-white px-3 py-1 rounded-full text-sm">
                      <span className="font-medium">{vocab.word}</span>
                      <span className="text-gray-500 ml-1">{vocab.meaning}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reading Content */}
              <div className="prose max-w-none mb-8">
                {selectedReading.content.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="text-gray-700 leading-relaxed mb-4">
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* Questions */}
              <div className="border-t pt-6">
                <h3 className="font-bold text-lg mb-4">阅读理解题</h3>
                <div className="space-y-6">
                  {selectedReading.questions.map((question, qIdx) => (
                    <div key={question.id} className="bg-gray-50 rounded-lg p-4">
                      <p className="font-medium mb-3">
                        {qIdx + 1}. {question.question}
                      </p>
                      <div className="space-y-2">
                        {question.options.map((option, oIdx) => {
                          const isSelected = readingAnswers[question.id] === oIdx;
                          const isCorrect = question.answer === oIdx;
                          const showCorrect = showReadingResults && isCorrect;
                          const showWrong = showReadingResults && isSelected && !isCorrect;

                          return (
                            <button
                              key={oIdx}
                              onClick={() => !showReadingResults && handleReadingAnswer(question.id, oIdx)}
                              disabled={showReadingResults}
                              className={`w-full p-3 rounded-lg border-2 text-left transition-all ${
                                showCorrect
                                  ? 'border-green-500 bg-green-50'
                                  : showWrong
                                    ? 'border-red-500 bg-red-50'
                                    : isSelected
                                      ? 'border-blue-500 bg-blue-50'
                                      : 'border-gray-200 hover:border-blue-300'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <span className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-sm">
                                  {String.fromCharCode(65 + oIdx)}
                                </span>
                                <span>{option}</span>
                                {showCorrect && <CheckCircle className="w-5 h-5 text-green-500 ml-auto" />}
                                {showWrong && <XCircle className="w-5 h-5 text-red-500 ml-auto" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                      {showReadingResults && (
                        <div className="mt-3 p-3 bg-yellow-50 rounded-lg">
                          <p className="text-sm text-gray-700">
                            <span className="font-medium">解析：</span>
                            {question.explanation}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {!showReadingResults ? (
                  <Button onClick={submitReading} className="w-full mt-6">
                    提交答案
                  </Button>
                ) : (
                  <div className="flex gap-3 mt-6">
                    <Button variant="outline" onClick={resetReading} className="flex items-center gap-2">
                      <RotateCcw className="w-4 h-4" />
                      重新答题
                    </Button>
                    <Button onClick={() => setSelectedReading(null)} className="flex-1">
                      返回列表
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg flex items-center justify-center">
            <Languages className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">英语学习</h1>
            <p className="text-gray-500">词汇 · 语法 · 阅读</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-lg grid-cols-3 mb-8">
            <TabsTrigger value="vocabulary">单词背诵</TabsTrigger>
            <TabsTrigger value="grammar">语法练习</TabsTrigger>
            <TabsTrigger value="reading">阅读理解</TabsTrigger>
          </TabsList>

          {/* Vocabulary Tab */}
          <TabsContent value="vocabulary">
            <div className="max-w-2xl mx-auto">
              {/* Category Filter */}
              <div className="flex flex-wrap gap-2 mb-6">
                <Button
                  variant={wordCategory === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => { setWordCategory('all'); setCurrentWordIndex(0); }}
                >
                  全部
                </Button>
                {['学校生活', '日常生活', '人物描述', '自然与环境', '健康', '科技', '情感', '社会'].map(cat => (
                  <Button
                    key={cat}
                    variant={wordCategory === cat ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => { setWordCategory(cat); setCurrentWordIndex(0); }}
                  >
                    {cat}
                  </Button>
                ))}
              </div>

              {/* Word Card */}
              <Card className="mb-6">
                <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
                  <div className="flex items-center justify-between">
                    <Badge>{currentWord.category}</Badge>
                    <span className="text-sm text-gray-500">
                      {currentWordIndex + 1} / {filteredWords.length}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <h2 className="text-4xl font-bold text-gray-800 mb-2">{currentWord.word}</h2>
                    <div className="flex items-center justify-center gap-3 text-gray-500">
                      <span className="text-lg">{currentWord.phonetic}</span>
                      <button 
                        onClick={() => playWordAudio(currentWord.word)}
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                      >
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  <div className={`transition-all duration-300 ${showWordMeaning ? 'opacity-100' : 'opacity-0 h-0 overflow-hidden'}`}>
                    <div className="p-4 bg-green-50 rounded-lg mb-4">
                      <p className="text-xl font-medium text-green-800 mb-2">{currentWord.meaning}</p>
                      <div className="border-t border-green-200 pt-3 mt-3">
                        <p className="text-gray-700 italic">{currentWord.example}</p>
                        <p className="text-gray-500 text-sm mt-1">{currentWord.exampleTranslation}</p>
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    onClick={() => setShowWordMeaning(!showWordMeaning)}
                    className="mb-4"
                  >
                    {showWordMeaning ? <><EyeOff className="w-4 h-4 mr-2" /> 隐藏释义</> : <><Eye className="w-4 h-4 mr-2" /> 显示释义</>}
                  </Button>

                  <div className="flex gap-3 justify-center">
                    <Button variant="outline" onClick={prevWord}>上一个</Button>
                    <Button 
                      onClick={markWordLearned}
                      disabled={learnedWords.includes(currentWord.id)}
                      variant={learnedWords.includes(currentWord.id) ? 'outline' : 'default'}
                    >
                      {learnedWords.includes(currentWord.id) ? (
                        <><CheckCircle className="w-4 h-4 mr-2" /> 已学习</>
                      ) : (
                        '标记为已学习'
                      )}
                    </Button>
                    <Button variant="outline" onClick={nextWord}>下一个</Button>
                  </div>
                </CardContent>
              </Card>

              {/* Progress */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-500">学习进度</span>
                    <span className="text-sm font-medium">{learnedWords.length} / {words.length}</span>
                  </div>
                  <Progress value={(learnedWords.length / words.length) * 100} className="h-2" />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Grammar Tab */}
          <TabsContent value="grammar">
            <div className="max-w-3xl mx-auto">
              <Card className="mb-6">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <div className="flex items-center justify-between">
                    <Badge className="text-purple-600">{currentGrammar.knowledge}</Badge>
                    <span className="text-sm text-gray-500">
                      {currentGrammarIndex + 1} / {grammarQuestions.length}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <h3 className="text-xl font-medium mb-6">{currentGrammar.question}</h3>

                  <div className="space-y-3">
                    {currentGrammar.options?.map((option, idx) => (
                      <button
                        key={idx}
                        onClick={() => !showGrammarResult && setSelectedGrammarAnswer(idx)}
                        disabled={showGrammarResult}
                        className={`w-full p-4 rounded-lg border-2 text-left transition-all ${
                          selectedGrammarAnswer === idx
                            ? showGrammarResult
                              ? idx === currentGrammar.answer
                                ? 'border-green-500 bg-green-50'
                                : 'border-red-500 bg-red-50'
                              : 'border-purple-500 bg-purple-50'
                            : showGrammarResult && idx === currentGrammar.answer
                              ? 'border-green-500 bg-green-50'
                              : 'border-gray-200 hover:border-purple-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center font-medium text-gray-600">
                            {String.fromCharCode(65 + idx)}
                          </span>
                          <span>{option}</span>
                          {showGrammarResult && idx === currentGrammar.answer && (
                            <CheckCircle className="w-5 h-5 text-green-500 ml-auto" />
                          )}
                          {showGrammarResult && selectedGrammarAnswer === idx && idx !== currentGrammar.answer && (
                            <XCircle className="w-5 h-5 text-red-500 ml-auto" />
                          )}
                        </div>
                      </button>
                    ))}
                  </div>

                  <div className="flex gap-3 mt-6">
                    {!showGrammarResult ? (
                      <Button 
                        onClick={checkGrammarAnswer}
                        disabled={selectedGrammarAnswer === null}
                        className="flex-1"
                      >
                        提交答案
                      </Button>
                    ) : (
                      <>
                        <div className="flex-1 p-4 bg-yellow-50 rounded-lg">
                          <div className="flex items-center gap-2 mb-1">
                            <Lightbulb className="w-4 h-4 text-yellow-600" />
                            <span className="font-medium text-yellow-700">解析</span>
                          </div>
                          <p className="text-sm text-gray-700">{currentGrammar.explanation}</p>
                        </div>
                        <Button onClick={nextGrammar} className="flex items-center gap-2">
                          下一题
                          <ArrowRight className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Progress */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-500">练习进度</span>
                    <span className="text-sm font-medium">
                      {correctGrammarCount}/{completedGrammar.length} 正确
                    </span>
                  </div>
                  <Progress value={(completedGrammar.length / grammarQuestions.length) * 100} className="h-2" />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Reading Tab */}
          <TabsContent value="reading">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {englishReadings.map((reading) => (
                <Card 
                  key={reading.id}
                  className="cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => setSelectedReading(reading)}
                >
                  <CardHeader className="bg-gradient-to-br from-teal-50 to-cyan-50">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg">{reading.title}</CardTitle>
                      {completedReadings.includes(reading.id) && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="text-gray-600 text-sm line-clamp-3 mb-3">
                      {reading.content.substring(0, 100)}...
                    </p>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{reading.questions.length}道题</Badge>
                      <div className="flex items-center gap-1 text-teal-600 text-sm">
                        <BookOpen className="w-4 h-4" />
                        <span>开始阅读</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Overall Progress */}
        <Card className="mt-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Trophy className="w-8 h-8 text-yellow-500" />
                <div>
                  <p className="font-bold">英语学习进度</p>
                  <p className="text-sm text-gray-500">
                    单词 {learnedWords.length}/{words.length} · 
                    语法 {completedGrammar.length}/{grammarQuestions.length} · 
                    阅读 {completedReadings.length}/{englishReadings.length}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
