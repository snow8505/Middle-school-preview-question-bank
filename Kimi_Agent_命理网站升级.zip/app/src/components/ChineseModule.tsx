import { useState } from 'react';
import { BookOpen, BookMarked, ChevronRight, Lightbulb, CheckCircle, XCircle, RotateCcw, Trophy } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { poems, laosheReadings } from '@/data';
import type { Poem, Reading } from '@/types';

interface ChineseModuleProps {
  onProgressUpdate: (progress: number) => void;
}

export function ChineseModule({ onProgressUpdate }: ChineseModuleProps) {
  const [activeTab, setActiveTab] = useState('poem');
  const [selectedPoem, setSelectedPoem] = useState<Poem | null>(null);
  const [selectedReading, setSelectedReading] = useState<Reading | null>(null);
  const [readingAnswers, setReadingAnswers] = useState<Record<string, number>>({});
  const [showReadingResults, setShowReadingResults] = useState<Record<string, boolean>>({});
  const [completedReadings, setCompletedReadings] = useState<string[]>([]);
  const [learnedPoems, setLearnedPoems] = useState<string[]>([]);

  const handlePoemLearned = (poemId: string) => {
    if (!learnedPoems.includes(poemId)) {
      setLearnedPoems([...learnedPoems, poemId]);
      toast.success('已标记为学习完成！');
      const progress = Math.min(100, Math.floor((learnedPoems.length + 1) / poems.length * 50));
      onProgressUpdate(progress);
    }
  };

  const handleReadingAnswer = (readingId: string, questionId: string, answer: number) => {
    setReadingAnswers({ ...readingAnswers, [`${readingId}-${questionId}`]: answer });
  };

  const submitReading = (reading: Reading) => {
    const allAnswered = reading.questions.every(q => 
      readingAnswers[`${reading.id}-${q.id}`] !== undefined
    );

    if (!allAnswered) {
      toast.error('请先回答所有问题！');
      return;
    }

    setShowReadingResults({ ...showReadingResults, [reading.id]: true });

    if (!completedReadings.includes(reading.id)) {
      setCompletedReadings([...completedReadings, reading.id]);
      const correctCount = reading.questions.filter(q => 
        readingAnswers[`${reading.id}-${q.id}`] === q.answer
      ).length;
      toast.success(`完成阅读！答对 ${correctCount}/${reading.questions.length} 题`);
      
      const progress = Math.min(100, 50 + Math.floor((completedReadings.length + 1) / laosheReadings.length * 50));
      onProgressUpdate(progress);
    }
  };

  const resetReading = (readingId: string) => {
    const newResults = { ...showReadingResults };
    delete newResults[readingId];
    setShowReadingResults(newResults);
    toast.info('可以重新答题了！');
  };

  // Poem Detail View
  if (selectedPoem) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 max-w-3xl">
          <Button variant="outline" onClick={() => setSelectedPoem(null)} className="mb-6">
            ← 返回列表
          </Button>

          <Card className="mb-6">
            <CardHeader className="bg-gradient-to-r from-red-50 to-orange-50">
              <div className="flex items-center justify-between">
                <div>
                  <Badge className="mb-2">{selectedPoem.dynasty}</Badge>
                  <CardTitle className="text-2xl">{selectedPoem.title}</CardTitle>
                  <p className="text-gray-600 mt-1">{selectedPoem.author}</p>
                </div>
                <Button
                  onClick={() => handlePoemLearned(selectedPoem.id)}
                  disabled={learnedPoems.includes(selectedPoem.id)}
                  variant={learnedPoems.includes(selectedPoem.id) ? 'outline' : 'default'}
                >
                  {learnedPoems.includes(selectedPoem.id) ? (
                    <><CheckCircle className="w-4 h-4 mr-2" /> 已学习</>
                  ) : (
                    '标记为已学习'
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {/* Poem Content */}
              <div className="text-center py-8 bg-gray-50 rounded-lg mb-6">
                {selectedPoem.content.map((line, idx) => (
                  <p key={idx} className="text-xl leading-loose font-medium text-gray-800">
                    {line}
                  </p>
                ))}
              </div>

              {/* Key Sentences */}
              <div className="mb-6">
                <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
                  <BookMarked className="w-5 h-5 text-red-500" />
                  名句赏析
                </h3>
                <div className="space-y-2">
                  {selectedPoem.keySentences.map((sentence, idx) => (
                    <div key={idx} className="p-3 bg-red-50 border-l-4 border-red-400 rounded">
                      <p className="text-lg font-medium text-red-800">{sentence}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Translation */}
              <div className="mb-6">
                <h3 className="font-bold text-lg mb-3">译文</h3>
                <p className="text-gray-700 leading-relaxed">{selectedPoem.translation}</p>
              </div>

              {/* Appreciation */}
              <div>
                <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-500" />
                  赏析
                </h3>
                <p className="text-gray-700 leading-relaxed">{selectedPoem.appreciation}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Reading Detail View
  if (selectedReading) {
    const showResults = showReadingResults[selectedReading.id];

    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Button variant="outline" onClick={() => setSelectedReading(null)} className="mb-6">
            ← 返回列表
          </Button>

          <Card className="mb-6">
            <CardHeader className="bg-gradient-to-r from-amber-50 to-yellow-50">
              <div className="flex items-center justify-between">
                <div>
                  <Badge className="mb-2">老舍作品</Badge>
                  <CardTitle className="text-xl">{selectedReading.title}</CardTitle>
                  <p className="text-gray-600 mt-1">作者：{selectedReading.author}</p>
                </div>
                {completedReadings.includes(selectedReading.id) && (
                  <Badge className="bg-green-100 text-green-700">已完成</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {/* Reading Content */}
              <div className="prose max-w-none mb-8">
                {selectedReading.content.split('\n\n').map((paragraph, idx) => (
                  <p key={idx} className="text-gray-700 leading-relaxed mb-4 indent-8">
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* Questions */}
              <div className="border-t pt-6">
                <h3 className="font-bold text-lg mb-4">阅读理解题</h3>
                <div className="space-y-6">
                  {selectedReading.questions.map((question, qIdx) => (
                    <div key={question.id} className="bg-gray-50 rounded-lg p-4">
                      <p className="font-medium mb-3">
                        {qIdx + 1}. {question.question}
                      </p>
                      <div className="space-y-2">
                        {question.options.map((option, oIdx) => {
                          const isSelected = readingAnswers[`${selectedReading.id}-${question.id}`] === oIdx;
                          const isCorrect = question.answer === oIdx;
                          const showCorrect = showResults && isCorrect;
                          const showWrong = showResults && isSelected && !isCorrect;

                          return (
                            <button
                              key={oIdx}
                              onClick={() => !showResults && handleReadingAnswer(selectedReading.id, question.id, oIdx)}
                              disabled={showResults}
                              className={`w-full p-3 rounded-lg border-2 text-left transition-all ${
                                showCorrect
                                  ? 'border-green-500 bg-green-50'
                                  : showWrong
                                    ? 'border-red-500 bg-red-50'
                                    : isSelected
                                      ? 'border-blue-500 bg-blue-50'
                                      : 'border-gray-200 hover:border-blue-300'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <span className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-sm">
                                  {String.fromCharCode(65 + oIdx)}
                                </span>
                                <span>{option}</span>
                                {showCorrect && <CheckCircle className="w-5 h-5 text-green-500 ml-auto" />}
                                {showWrong && <XCircle className="w-5 h-5 text-red-500 ml-auto" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                      {showResults && (
                        <div className="mt-3 p-3 bg-yellow-50 rounded-lg">
                          <p className="text-sm text-gray-700">
                            <span className="font-medium">解析：</span>
                            {question.explanation}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Submit Button */}
                {!showResults ? (
                  <Button 
                    onClick={() => submitReading(selectedReading)}
                    className="w-full mt-6"
                  >
                    提交答案
                  </Button>
                ) : (
                  <div className="flex gap-3 mt-6">
                    <Button 
                      variant="outline" 
                      onClick={() => resetReading(selectedReading.id)}
                      className="flex items-center gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      重新答题
                    </Button>
                    <Button onClick={() => setSelectedReading(null)} className="flex-1">
                      返回列表
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Main List View
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">语文学习</h1>
            <p className="text-gray-500">古诗词背诵与阅读理解</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md grid-cols-2 mb-8">
            <TabsTrigger value="poem">古诗词</TabsTrigger>
            <TabsTrigger value="reading">阅读理解</TabsTrigger>
          </TabsList>

          <TabsContent value="poem">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {poems.map((poem) => (
                <Card 
                  key={poem.id}
                  className="cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => setSelectedPoem(poem)}
                >
                  <CardHeader className="bg-gradient-to-br from-red-50 to-orange-50">
                    <div className="flex items-start justify-between">
                      <Badge>{poem.dynasty}</Badge>
                      {learnedPoems.includes(poem.id) && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                    </div>
                    <CardTitle className="text-lg mt-2">{poem.title}</CardTitle>
                    <p className="text-sm text-gray-500">{poem.author}</p>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="text-gray-600 text-sm line-clamp-2">
                      {poem.content[0]}...
                    </p>
                    <div className="flex items-center gap-1 mt-3 text-red-600 text-sm">
                      <span>查看详情</span>
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="reading">
            <div className="space-y-6">
              {laosheReadings.map((reading) => (
                <Card 
                  key={reading.id}
                  className="cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => setSelectedReading(reading)}
                >
                  <CardHeader className="bg-gradient-to-br from-amber-50 to-yellow-50">
                    <div className="flex items-start justify-between">
                      <div>
                        <Badge className="mb-2">老舍作品</Badge>
                        <CardTitle className="text-lg">{reading.title}</CardTitle>
                        <p className="text-sm text-gray-500">作者：{reading.author}</p>
                      </div>
                      {completedReadings.includes(reading.id) && (
                        <Badge className="bg-green-100 text-green-700">已完成</Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-gray-600 text-sm">
                        {reading.questions.length}道阅读理解题
                      </p>
                      <div className="flex items-center gap-1 text-amber-600 text-sm">
                        <span>开始练习</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Progress */}
        <Card className="mt-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Trophy className="w-8 h-8 text-yellow-500" />
                <div>
                  <p className="font-bold">学习进度</p>
                  <p className="text-sm text-gray-500">
                    古诗词 {learnedPoems.length}/{poems.length} · 
                    阅读 {completedReadings.length}/{laosheReadings.length}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold text-red-600">
                  {Math.floor((learnedPoems.length / poems.length * 50) + 
                    (completedReadings.length / laosheReadings.length * 50))}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
