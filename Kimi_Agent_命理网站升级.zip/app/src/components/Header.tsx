import { useState } from 'react';
import { BookOpen, User, Trophy, BarChart3, Home } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface HeaderProps {
  userName: string;
  progress: {
    math: number;
    chinese: number;
    english: number;
    total: number;
  };
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Header({ userName, progress, currentPage, onNavigate }: HeaderProps) {
  const [showUserDialog, setShowUserDialog] = useState(false);

  const navItems = [
    { id: 'home', name: '首页', icon: Home },
    { id: 'math', name: '数学', icon: BookOpen },
    { id: 'chinese', name: '语文', icon: BookOpen },
    { id: 'english', name: '英语', icon: BookOpen },
  ];

  return (
    <header className="bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 text-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">北京小升初</h1>
              <p className="text-xs text-blue-100">学习平台</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    currentPage === item.id
                      ? 'bg-white/20 text-white'
                      : 'text-blue-100 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{item.name}</span>
                </button>
              );
            })}
          </nav>

          {/* User Info */}
          <div className="flex items-center gap-3">
            <Dialog open={showUserDialog} onOpenChange={setShowUserDialog}>
              <DialogTrigger asChild>
                <button className="flex items-center gap-2 bg-white/10 hover:bg-white/20 rounded-full pl-2 pr-4 py-1.5 transition-colors">
                  <Avatar className="w-8 h-8 bg-white">
                    <AvatarFallback className="text-blue-600 text-sm font-bold">
                      {userName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium hidden sm:inline">{userName}</span>
                </button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <User className="w-5 h-5" />
                    学习进度
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-6 py-4">
                  <div className="flex items-center gap-4">
                    <Avatar className="w-16 h-16 bg-blue-100">
                      <AvatarFallback className="text-blue-600 text-2xl font-bold">
                        {userName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-bold text-lg">{userName}</h3>
                      <p className="text-gray-500 text-sm">六年级学生</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">数学</span>
                        <span className="text-sm text-gray-500">{progress.math}%</span>
                      </div>
                      <Progress value={progress.math} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">语文</span>
                        <span className="text-sm text-gray-500">{progress.chinese}%</span>
                      </div>
                      <Progress value={progress.chinese} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">英语</span>
                        <span className="text-sm text-gray-500">{progress.english}%</span>
                      </div>
                      <Progress value={progress.english} className="h-2" />
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg p-4 border border-yellow-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Trophy className="w-5 h-5 text-yellow-500" />
                      <span className="font-bold text-yellow-700">总进度</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <Progress value={progress.total} className="h-3" />
                      </div>
                      <span className="text-2xl font-bold text-yellow-600">{progress.total}%</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-blue-50 rounded-lg p-3 text-center">
                      <BarChart3 className="w-6 h-6 text-blue-500 mx-auto mb-1" />
                      <p className="text-xs text-gray-500">已完成题目</p>
                      <p className="text-xl font-bold text-blue-600">
                        {Math.floor(progress.total * 2)}
                      </p>
                    </div>
                    <div className="bg-green-50 rounded-lg p-3 text-center">
                      <Trophy className="w-6 h-6 text-green-500 mx-auto mb-1" />
                      <p className="text-xs text-gray-500">正确率</p>
                      <p className="text-xl font-bold text-green-600">
                        {Math.min(95, 70 + Math.floor(progress.total / 5))}%
                      </p>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Mobile Navigation */}
        <nav className="flex md:hidden items-center justify-between mt-3 pt-3 border-t border-white/20">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                  currentPage === item.id
                    ? 'bg-white/20 text-white'
                    : 'text-blue-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{item.name}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
