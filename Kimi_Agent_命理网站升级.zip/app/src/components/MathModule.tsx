import { useState, useEffect } from 'react';
import { Calculator, CheckCircle, XCircle, Lightbulb, ArrowRight, Trophy, Target, BookOpen, RotateCcw, ChevronLeft, BarChart3, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { mathQuestions, mathCategories, getRandomQuestions } from '@/data';
import type { MathQuestion } from '@/types';

interface WrongAnswer {
  question: MathQuestion;
  userAnswer: string | number;
  timestamp: number;
}

interface MathModuleProps {
  onProgressUpdate: (progress: number) => void;
}

const QUESTIONS_PER_SESSION = 8;
const WRONG_ANSWERS_KEY = 'math_wrong_answers';

export function MathModule({ onProgressUpdate }: MathModuleProps) {
  const [view, setView] = useState<'menu' | 'quiz' | 'completed' | 'wrongbook'>('menu');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [questions, setQuestions] = useState<MathQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [userInput, setUserInput] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [sessionStats, setSessionStats] = useState({ correct: 0, wrong: 0 });
  const [wrongAnswers, setWrongAnswers] = useState<WrongAnswer[]>([]);
  const [sessionWrongQuestions, setSessionWrongQuestions] = useState<MathQuestion[]>([]);

  // Load wrong answers from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(WRONG_ANSWERS_KEY);
    if (saved) {
      setWrongAnswers(JSON.parse(saved));
    }
  }, []);

  // Save wrong answers to localStorage
  const saveWrongAnswers = (answers: WrongAnswer[]) => {
    setWrongAnswers(answers);
    localStorage.setItem(WRONG_ANSWERS_KEY, JSON.stringify(answers));
  };

  const startQuiz = (category: string | null = null) => {
    setSelectedCategory(category);
    
    let selectedQuestions: MathQuestion[];
    if (category) {
      const categoryQuestions = mathQuestions.filter(q => q.type === category);
      selectedQuestions = [...categoryQuestions].sort(() => Math.random() - 0.5).slice(0, QUESTIONS_PER_SESSION);
    } else {
      selectedQuestions = getRandomQuestions(QUESTIONS_PER_SESSION);
    }
    
    setQuestions(selectedQuestions);
    setCurrentIndex(0);
    setSessionStats({ correct: 0, wrong: 0 });
    setSessionWrongQuestions([]);
    setView('quiz');
    resetQuestionState();
  };

  const resetQuestionState = () => {
    setSelectedAnswer(null);
    setUserInput('');
    setShowResult(false);
    setIsCorrect(false);
    setShowExplanation(false);
  };

  const currentQuestion = questions[currentIndex];

  const checkAnswer = () => {
    if (!currentQuestion) return;

    let correct = false;
    let userAns: string | number = '';

    if (currentQuestion.options) {
      correct = selectedAnswer === currentQuestion.answer;
      userAns = selectedAnswer !== null ? currentQuestion.options[selectedAnswer] : '未选择';
    } else {
      const userAnsStr = userInput.trim().toLowerCase().replace(/\s/g, '');
      const correctAnsStr = String(currentQuestion.answer).toLowerCase().replace(/\s/g, '');
      correct = userAnsStr === correctAnsStr;
      userAns = userInput;
    }

    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      setSessionStats(prev => ({ ...prev, correct: prev.correct + 1 }));
      toast.success('回答正确！');
    } else {
      setSessionStats(prev => ({ ...prev, wrong: prev.wrong + 1 }));
      setSessionWrongQuestions(prev => [...prev, currentQuestion]);
      
      // Add to wrong answers book
      const newWrongAnswer: WrongAnswer = {
        question: currentQuestion,
        userAnswer: userAns,
        timestamp: Date.now()
      };
      saveWrongAnswers([newWrongAnswer, ...wrongAnswers].slice(0, 50)); // Keep max 50
      
      toast.error('回答错误，已加入错题本！');
    }
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      resetQuestionState();
    } else {
      // Quiz completed
      setView('completed');
      // Update overall progress
      const totalAnswered = parseInt(localStorage.getItem('math_total_answered') || '0') + sessionStats.correct + (isCorrect ? 1 : 0);
      localStorage.setItem('math_total_answered', totalAnswered.toString());
      onProgressUpdate(Math.min(100, Math.floor(totalAnswered / 5)));
    }
  };

  const clearWrongAnswers = () => {
    if (confirm('确定要清空所有错题吗？')) {
      saveWrongAnswers([]);
      toast.success('错题本已清空');
    }
  };

  const removeWrongAnswer = (index: number) => {
    const newAnswers = wrongAnswers.filter((_, i) => i !== index);
    saveWrongAnswers(newAnswers);
    toast.success('已删除');
  };

  // Menu View
  if (view === 'menu') {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">数学练习</h1>
                <p className="text-gray-500">分班考试题型 · 随机抽题 · 错题记录</p>
              </div>
            </div>
            <Button variant="outline" onClick={() => setView('wrongbook')} className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              错题本 ({wrongAnswers.length})
            </Button>
          </div>

          {/* Quick Start */}
          <Card className="mb-8 bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <h2 className="text-2xl font-bold mb-2">快速开始</h2>
                  <p className="text-blue-100">随机抽取8道题，来自各个知识点</p>
                </div>
                <Button 
                  size="lg" 
                  onClick={() => startQuiz(null)}
                  className="bg-white text-blue-600 hover:bg-blue-50"
                >
                  <Target className="w-5 h-5 mr-2" />
                  开始练习
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Categories */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mathCategories.map((category) => {
              const questionCount = mathQuestions.filter(q => q.type === category.id).length;
              return (
                <Card 
                  key={category.id}
                  className="cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1"
                  onClick={() => startQuiz(category.id)}
                >
                  <CardHeader className="bg-gradient-to-br from-blue-50 to-cyan-50">
                    <div className="text-4xl mb-2">{category.icon}</div>
                    <CardTitle>{category.name}</CardTitle>
                    <p className="text-sm text-gray-500">{category.description}</p>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">题目数量</span>
                      <Badge variant="secondary">{questionCount}题</Badge>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Stats */}
          <Card className="mt-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Trophy className="w-8 h-8 text-yellow-500" />
                  <div>
                    <p className="font-bold">题库统计</p>
                    <p className="text-sm text-gray-500">共 {mathQuestions.length} 道题目</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-blue-600">{wrongAnswers.length}</p>
                  <p className="text-sm text-gray-500">错题记录</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Wrong Book View
  if (view === 'wrongbook') {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="flex items-center justify-between mb-6">
            <Button variant="outline" onClick={() => setView('menu')} className="flex items-center gap-2">
              <ChevronLeft className="w-4 h-4" />
              返回
            </Button>
            <h1 className="text-xl font-bold">错题本</h1>
            {wrongAnswers.length > 0 && (
              <Button variant="destructive" size="sm" onClick={clearWrongAnswers}>
                <Trash2 className="w-4 h-4 mr-2" />
                清空
              </Button>
            )}
          </div>

          {wrongAnswers.length === 0 ? (
            <Card className="text-center py-16">
              <CardContent>
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-xl font-bold mb-2">太棒了！</h2>
                <p className="text-gray-500">你还没有错题，继续保持！</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {wrongAnswers.map((item, idx) => (
                <Card key={idx} className="overflow-hidden">
                  <CardHeader className="bg-red-50 py-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-red-600">{item.question.knowledge}</Badge>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => removeWrongAnswer(idx)}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <p className="font-medium mb-3">{item.question.question}</p>
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">你的答案：</span>
                        <span className="text-red-600 font-medium">{item.userAnswer}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">正确答案：</span>
                        <span className="text-green-600 font-medium">
                          {item.question.options 
                            ? item.question.options[item.question.answer as number]
                            : item.question.answer}
                        </span>
                      </div>
                    </div>
                    <div className="mt-3 p-3 bg-yellow-50 rounded-lg text-sm">
                      <span className="font-medium text-yellow-700">解析：</span>
                      <span className="text-gray-700">{item.question.explanation}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Completed View
  if (view === 'completed') {
    const accuracy = Math.round((sessionStats.correct / QUESTIONS_PER_SESSION) * 100);
    
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card className="text-center py-12">
            <CardContent>
              <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trophy className="w-12 h-12 text-white" />
              </div>
              
              <h1 className="text-3xl font-bold mb-2">练习完成！</h1>
              <p className="text-gray-500 mb-8">本次练习 {QUESTIONS_PER_SESSION} 题已完成</p>
              
              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className="p-4 bg-green-50 rounded-lg">
                  <p className="text-3xl font-bold text-green-600">{sessionStats.correct}</p>
                  <p className="text-sm text-gray-500">正确</p>
                </div>
                <div className="p-4 bg-red-50 rounded-lg">
                  <p className="text-3xl font-bold text-red-600">{sessionStats.wrong}</p>
                  <p className="text-sm text-gray-500">错误</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-3xl font-bold text-blue-600">{accuracy}%</p>
                  <p className="text-sm text-gray-500">正确率</p>
                </div>
              </div>

              {sessionWrongQuestions.length > 0 && (
                <div className="mb-8 p-4 bg-yellow-50 rounded-lg text-left">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-5 h-5 text-yellow-600" />
                    <span className="font-medium text-yellow-700">本次错题</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    你有 {sessionWrongQuestions.length} 道错题已加入错题本，记得复习哦！
                  </p>
                </div>
              )}
              
              <div className="flex gap-3 justify-center">
                <Button variant="outline" onClick={() => setView('menu')}>
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  返回菜单
                </Button>
                <Button onClick={() => startQuiz(selectedCategory)}>
                  <RotateCcw className="w-4 h-4 mr-2" />
                  再来一组
                </Button>
                {wrongAnswers.length > 0 && (
                  <Button variant="secondary" onClick={() => setView('wrongbook')}>
                    <BookOpen className="w-4 h-4 mr-2" />
                    查看错题
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Quiz View
  if (!currentQuestion) return null;

  const categoryName = selectedCategory 
    ? mathCategories.find(c => c.id === selectedCategory)?.name 
    : '综合练习';

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 max-w-3xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="outline" onClick={() => setView('menu')}>
            ← 退出
          </Button>
          <Badge className="text-lg px-4 py-1">{categoryName}</Badge>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <span className="font-medium">{currentIndex + 1}/{questions.length}</span>
          </div>
        </div>

        {/* Progress Bar */}
        <Progress 
          value={((currentIndex) / questions.length) * 100} 
          className="h-2 mb-6"
        />

        {/* Question Card */}
        <Card className="mb-6">
          <CardHeader className="bg-gradient-to-r from-blue-50 to-cyan-50">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline">
                {currentQuestion.difficulty === 'easy' ? '简单' : 
                 currentQuestion.difficulty === 'medium' ? '中等' : '困难'}
              </Badge>
              <Badge variant="outline" className="text-blue-600">
                {currentQuestion.knowledge}
              </Badge>
            </div>
            <CardTitle className="text-xl leading-relaxed">
              {currentQuestion.question}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {/* Options or Input */}
            {currentQuestion.options ? (
              <div className="space-y-3">
                {currentQuestion.options.map((option, idx) => (
                  <button
                    key={idx}
                    onClick={() => !showResult && setSelectedAnswer(idx)}
                    disabled={showResult}
                    className={`w-full p-4 rounded-lg border-2 text-left transition-all ${
                      selectedAnswer === idx
                        ? showResult
                          ? idx === currentQuestion.answer
                            ? 'border-green-500 bg-green-50'
                            : 'border-red-500 bg-red-50'
                          : 'border-blue-500 bg-blue-50'
                        : showResult && idx === currentQuestion.answer
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center font-medium text-gray-600">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{option}</span>
                      {showResult && idx === currentQuestion.answer && (
                        <CheckCircle className="w-5 h-5 text-green-500 ml-auto" />
                      )}
                      {showResult && selectedAnswer === idx && idx !== currentQuestion.answer && (
                        <XCircle className="w-5 h-5 text-red-500 ml-auto" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                <input
                  type="text"
                  value={userInput}
                  onChange={(e) => !showResult && setUserInput(e.target.value)}
                  disabled={showResult}
                  placeholder="请输入答案..."
                  className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none"
                />
                {showResult && (
                  <div className={`p-4 rounded-lg ${isCorrect ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                    <div className="flex items-center gap-2">
                      {isCorrect ? <CheckCircle className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                      <span className="font-medium">
                        {isCorrect ? '回答正确！' : `正确答案：${currentQuestion.answer}`}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 mt-6">
              {!showResult ? (
                <Button 
                  onClick={checkAnswer}
                  disabled={currentQuestion.options ? selectedAnswer === null : !userInput}
                  className="flex-1"
                >
                  提交答案
                </Button>
              ) : (
                <>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowExplanation(!showExplanation)}
                    className="flex items-center gap-2"
                  >
                    <Lightbulb className="w-4 h-4" />
                    {showExplanation ? '隐藏解析' : '查看解析'}
                  </Button>
                  <Button onClick={nextQuestion} className="flex-1 flex items-center gap-2">
                    {currentIndex < questions.length - 1 ? (
                      <>
                        下一题
                        <ArrowRight className="w-4 h-4" />
                      </>
                    ) : (
                      '完成练习'
                    )}
                  </Button>
                </>
              )}
            </div>

            {/* Explanation */}
            {showExplanation && (
              <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Lightbulb className="w-5 h-5 text-yellow-600" />
                  <span className="font-medium text-yellow-700">解析</span>
                </div>
                <p className="text-gray-700">{currentQuestion.explanation}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Session Stats */}
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span>本次练习</span>
          <div className="flex gap-4">
            <span className="text-green-600">✓ {sessionStats.correct + (showResult && isCorrect ? 1 : 0)}</span>
            <span className="text-red-600">✗ {sessionStats.wrong + (showResult && !isCorrect ? 1 : 0)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
