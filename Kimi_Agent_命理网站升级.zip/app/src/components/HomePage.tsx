import { useState } from 'react';
import { BookOpen, Calculator, Languages, Trophy, Target, TrendingUp, Star, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

interface HomePageProps {
  userName: string;
  progress: {
    math: number;
    chinese: number;
    english: number;
    total: number;
  };
  onNavigate: (page: string) => void;
}

export function HomePage({ userName, progress, onNavigate }: HomePageProps) {
  const [dailyGoal] = useState({ current: 15, target: 20 });

  const subjects = [
    {
      id: 'math',
      name: '数学',
      description: '小学过渡中学刷题',
      icon: Calculator,
      color: 'from-blue-500 to-cyan-500',
      bgColor: 'bg-blue-50',
      progress: progress.math,
      totalQuestions: 50,
      completedQuestions: Math.floor(progress.math / 2),
      features: ['小学知识巩固', '代数入门', '几何基础', '应用题训练']
    },
    {
      id: 'chinese',
      name: '语文',
      description: '古诗词与阅读理解',
      icon: BookOpen,
      color: 'from-red-500 to-orange-500',
      bgColor: 'bg-red-50',
      progress: progress.chinese,
      totalQuestions: 40,
      completedQuestions: Math.floor(progress.chinese / 2.5),
      features: ['初中古诗词', '老舍作品阅读', '文言文基础', '写作技巧']
    },
    {
      id: 'english',
      name: '英语',
      description: '词汇语法与阅读',
      icon: Languages,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50',
      progress: progress.english,
      totalQuestions: 60,
      completedQuestions: Math.floor(progress.english / 1.67),
      features: ['初中词汇', '语法练习', '阅读理解', '听力训练']
    }
  ];

  const achievements = [
    { name: '数学新星', description: '完成10道数学题', unlocked: progress.math >= 20 },
    { name: '诗词达人', description: '背诵5首古诗词', unlocked: progress.chinese >= 25 },
    { name: '单词高手', description: '掌握20个单词', unlocked: progress.english >= 30 },
    { name: '学习标兵', description: '总进度达到50%', unlocked: progress.total >= 50 },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-500 to-indigo-600 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex-1">
              <Badge className="bg-white/20 text-white mb-4">👋 欢迎回来</Badge>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">
                {userName}，你好！
              </h1>
              <p className="text-blue-100 mb-6">
                今天是学习的好日子，继续加油，为小升初做好准备！
              </p>
              <div className="flex flex-wrap gap-3">
                <Button 
                  onClick={() => onNavigate('math')}
                  className="bg-white text-blue-600 hover:bg-blue-50"
                >
                  <Calculator className="w-4 h-4 mr-2" />
                  开始数学练习
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('english')}
                  className="border-white text-white hover:bg-white/10"
                >
                  <Languages className="w-4 h-4 mr-2" />
                  背诵单词
                </Button>
              </div>
            </div>

            {/* Daily Goal Card */}
            <Card className="w-full md:w-80 bg-white/10 backdrop-blur border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-blue-100 text-sm">今日目标</p>
                    <p className="text-2xl font-bold">{dailyGoal.current}/{dailyGoal.target}</p>
                  </div>
                </div>
                <Progress 
                  value={(dailyGoal.current / dailyGoal.target) * 100} 
                  className="h-3 bg-white/20"
                />
                <p className="text-blue-100 text-sm mt-3">
                  还差 {dailyGoal.target - dailyGoal.current} 题完成今日目标
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Subjects Grid */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-2 mb-6">
          <BookOpen className="w-5 h-5 text-blue-600" />
          <h2 className="text-xl font-bold">学科学习</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {subjects.map((subject) => {
            const Icon = subject.icon;
            return (
              <Card 
                key={subject.id}
                className="cursor-pointer hover:shadow-lg transition-shadow group"
                onClick={() => onNavigate(subject.id)}
              >
                <CardHeader className={`${subject.bgColor} rounded-t-lg`}>
                  <div className="flex items-start justify-between">
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${subject.color} flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <Badge variant="secondary">
                      {subject.completedQuestions}/{subject.totalQuestions}题
                    </Badge>
                  </div>
                  <CardTitle className="mt-4">{subject.name}</CardTitle>
                  <p className="text-gray-500 text-sm">{subject.description}</p>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm text-gray-500">学习进度</span>
                      <span className="text-sm font-medium">{subject.progress}%</span>
                    </div>
                    <Progress value={subject.progress} className="h-2" />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {subject.features.map((feature, idx) => (
                      <span 
                        key={idx}
                        className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Stats & Achievements */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Learning Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                学习统计
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <Clock className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-blue-600">12.5</p>
                  <p className="text-sm text-gray-500">学习小时</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <BookOpen className="w-6 h-6 text-green-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-green-600">
                    {Math.floor(progress.total * 2)}
                  </p>
                  <p className="text-sm text-gray-500">完成题目</p>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <Star className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-yellow-600">
                    {Math.min(95, 70 + Math.floor(progress.total / 5))}%
                  </p>
                  <p className="text-sm text-gray-500">正确率</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <Trophy className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-purple-600">
                    {achievements.filter(a => a.unlocked).length}
                  </p>
                  <p className="text-sm text-gray-500">获得成就</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-600" />
                成就徽章
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {achievements.map((achievement, idx) => (
                  <div 
                    key={idx}
                    className={`flex items-center gap-3 p-3 rounded-lg ${
                      achievement.unlocked 
                        ? 'bg-yellow-50 border border-yellow-200' 
                        : 'bg-gray-50 opacity-60'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      achievement.unlocked ? 'bg-yellow-400' : 'bg-gray-300'
                    }`}>
                      <Trophy className={`w-5 h-5 ${
                        achievement.unlocked ? 'text-white' : 'text-gray-500'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${
                        achievement.unlocked ? 'text-yellow-700' : 'text-gray-500'
                      }`}>
                        {achievement.name}
                      </p>
                      <p className="text-sm text-gray-500">{achievement.description}</p>
                    </div>
                    {achievement.unlocked && (
                      <Badge className="bg-yellow-400 text-yellow-800">已解锁</Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
